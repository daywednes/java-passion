package com.example.helloandroid;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class HelloAndroid extends Activity {

	private static final String TAG = "HelloAndroid---->";

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		Log.v(TAG, "onCreate() is called");

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main2);

		// Create Button object from layout definition file.
		Button button1 = (Button) findViewById(R.id.Button01);
		
		// Event listener for the button
		OnClickListener listener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				Button b = (Button)v;
				b.setText("JavaPassion.com is awesome!");
				b.setBackgroundColor(Color.YELLOW);
			}
		};
		
		// Register event listener to the button
		button1.setOnClickListener(listener);
	}
}