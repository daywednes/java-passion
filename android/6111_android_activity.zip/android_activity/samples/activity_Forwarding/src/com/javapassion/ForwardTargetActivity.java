/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

// Need the following import to get access to the app resources, since this
// class is in a sub-package.
import com.javapassion.R;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

/**
 * Example of removing yourself from the history stack after forwarding to
 * another activity.
 */
public class ForwardTargetActivity extends Activity {
	private static final String TAG = "ForwardTargetActivity---->";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.v(TAG, "onStart() called");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.forward_target);
	}
	
	//
	// Dummy life-cycle call-back methods.  Added here to see the
	// log messages.
	//
	@Override
	public void onStart() {
		Log.v(TAG, "onStart() called");
		super.onStart();
	}

	@Override
	public void onRestart() {
		Log.v(TAG, "onRestart() called");
		super.onRestart();
	}

	@Override
	public void onResume() {
		Log.v(TAG, "onResume() called");
		super.onResume();
	}

	@Override
	public void onPause() {
		Log.v(TAG, "onPause() called");
		super.onPause();
	}

	@Override
	public void onStop() {
		Log.v(TAG, "onStop() called");
		super.onStop();
	}

	@Override
	public void onDestroy() {
		Log.v(TAG, "onDestroy() called");
		super.onDestroy();
	}
}
