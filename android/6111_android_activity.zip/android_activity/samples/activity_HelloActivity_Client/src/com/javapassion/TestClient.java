package com.javapassion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TestClient extends Activity implements View.OnClickListener {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		View loginButton = findViewById(R.id.button1);
		loginButton.setOnClickListener(this);
	}

	public void onClick(View v) {
        // Access the SomeActivity of the activity_HelloActivity_Server 		// application.
		Intent intent = new Intent();
		intent.setClassName("com.mypackage", // Package name
				"com.mypackage.SomeActivity"); // Activity name
		startActivity(intent);
	}

}
