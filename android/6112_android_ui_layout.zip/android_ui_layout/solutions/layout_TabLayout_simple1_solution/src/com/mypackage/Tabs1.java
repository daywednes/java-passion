/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mypackage;

import android.app.TabActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

/**
 * An example of tabs that uses labels (
 * {@link TabSpec#setIndicator(CharSequence)}) for its indicators and views by
 * id from a layout file ({@link TabSpec#setContent(int)}).
 */
public class Tabs1 extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TabHost tabHost = getTabHost();

		// Inflate a new view hierarchy from the specified xml resource.
		LayoutInflater.from(this).inflate(R.layout.tabs1, // layout resource
		        tabHost.getTabContentView(), // Get FrameLayout
		        true);

		// Initialize a TabSpec for each tab and add it to the TabHost
		TabHost.TabSpec spec; // Reusable TabSpec for each tab

		spec = tabHost.newTabSpec("tab1").setIndicator("tab1")
		        .setContent(R.id.view1);
		tabHost.addTab(spec);

		spec = tabHost.newTabSpec("tab2").setIndicator("tab2")
		        .setContent(R.id.view2);
		tabHost.addTab(spec);

		spec = tabHost.newTabSpec("tab3").setIndicator("tab3")
		        .setContent(R.id.view3);
		tabHost.addTab(spec);

		// Add a new tab
		spec = tabHost.newTabSpec("tab4").setIndicator("mytab4")
		        .setContent(R.id.view4);
		tabHost.addTab(spec);

	}
}
