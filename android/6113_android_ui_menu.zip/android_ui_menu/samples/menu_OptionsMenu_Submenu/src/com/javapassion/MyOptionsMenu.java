package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.SubMenu;
import android.view.MenuItem;
import android.widget.Toast;

public class MyOptionsMenu extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    // Creates the menu items by overriding onCreateOptionsMenu()
    // method of Activity class.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	boolean result = super.onCreateOptionsMenu(menu);
    	
    	// Create submenu "File"
    	SubMenu fileMenu = menu.addSubMenu("File");
    	fileMenu.add("New");
    	fileMenu.add("Open File");
    	fileMenu.add("Close");
    	fileMenu.add("Close All");
    	
    	// Create submenu "Edit"
    	SubMenu editMenu = menu.addSubMenu("Edit");
    	editMenu.add("Undo Typing");
    	editMenu.add("Redo");
    	editMenu.add("Cut");
    	  
    	return result;
    }

    
    // Handles item selections
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {  	
		Toast.makeText(
				MyOptionsMenu.this,		// Qualify 'this" with Activity class
				"You selected menu item #" + String.valueOf(item.getItemId()),		
				Toast.LENGTH_LONG).show();	// Make sure you call show() method
    	return true;
    }
}