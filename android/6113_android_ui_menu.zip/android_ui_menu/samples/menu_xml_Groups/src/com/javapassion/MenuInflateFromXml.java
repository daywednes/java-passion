/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

/**
 * Demonstrates inflating menus from XML. Hit the menu button. 
 * To choose another, back out of the activity and start over.
 */
public class MenuInflateFromXml extends Activity {

	private Menu mMenu;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Hold on to this
		mMenu = menu;

		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.groups, menu);

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		// For "Groups": Toggle visibility of grouped menu items with
		// nongrouped menu items
		case R.id.browser_visibility:
			// The refresh item is part of the browser group
			final boolean shouldShowBrowser = !mMenu.findItem(R.id.refresh)
			        .isVisible();
			mMenu.setGroupVisible(R.id.browser, shouldShowBrowser);
			break;

		case R.id.email_visibility:
			// The reply item is part of the email group
			final boolean shouldShowEmail = !mMenu.findItem(R.id.reply)
			        .isVisible();
			mMenu.setGroupVisible(R.id.email, shouldShowEmail);
			break;

		// Generic catch all for all the other menu resources
		default:
			// Don't toast text when a submenu is clicked
			if (!item.hasSubMenu()) {
				Toast.makeText(this, item.getTitle(), Toast.LENGTH_LONG).show();
				return true;
			}
			break;
		}

		return false;
	}

}
