/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class Main extends Activity  {
	
	private TextView txtStatus;
	private RefreshHandler mRedrawHandler = new RefreshHandler();
   
	class RefreshHandler extends Handler {
		
		// Override handleMessage so what we can use this Handler 
		// to handle our messages to it
        @Override
        public void handleMessage(Message msg) {
        	Main.this.updateUI();
        }

        // Declare a sleep function to delay another execute 
        // of this handler with the function sendMessageDelayed
        public void sleep(long delayMillis) {
        	this.removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    };
    
    private void updateUI(){
    	int currentInt = Integer.parseInt((String) txtStatus.getText()) + 10;
        if(currentInt <= 100){
        	mRedrawHandler.sleep(1000);
        	txtStatus.setText(String.valueOf(currentInt));
        }
    }

	
	@Override 
	public void onCreate(Bundle icicle) { 
	    super.onCreate(icicle); 
	    setContentView(R.layout.main);
	    this.txtStatus = (TextView) this.findViewById(R.id.txtStatus);
	    updateUI();
	}	
}