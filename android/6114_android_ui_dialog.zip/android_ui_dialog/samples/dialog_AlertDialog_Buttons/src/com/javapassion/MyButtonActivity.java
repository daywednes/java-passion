package com.javapassion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MyButtonActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);

		// Register event handler to the Button View object
		myButton.setOnClickListener(new Button.OnClickListener() {

			// When clicked display an AlertDialog
			@Override
			public void onClick(View v) {
				
				AlertDialog.Builder builder = new AlertDialog.Builder(
						MyButtonActivity.this);
				
				builder.setMessage("Are you sure you want to exit?");
				
				// When Yes button is selected, exit the application
				// and home screen will be displayed.
				builder.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								MyButtonActivity.this.finish();
							}
						});
				
				// When No button is selected, cancel the dialog
				// and return to the original screen.
				builder.setNegativeButton("No",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								dialog.cancel();
							}
						});
				
				builder.create();
				builder.show();

			}
		});

	}
}