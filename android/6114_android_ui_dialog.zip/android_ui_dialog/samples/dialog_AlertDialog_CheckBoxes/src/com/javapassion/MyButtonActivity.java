package com.javapassion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MyButtonActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);

		// Register event handler to the Button View object
		myButton.setOnClickListener(new Button.OnClickListener() {

			// When clicked display an AlertDialog with a list of multiple-choice 
			// items (checkboxes) 
			@Override
			public void onClick(View v) {
				
				final CharSequence[] items = {"Red", "Green", "Blue"};

				AlertDialog.Builder builder = new AlertDialog.Builder(MyButtonActivity.this);
				builder.setTitle("Pick a color");

				// When a selection is made, display a toast message indicating what color
				// was selected.
				builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
				    public void onClick(DialogInterface dialog, int item) {
				        Toast.makeText(getApplicationContext(), 
				        		"You picked " + items[item], Toast.LENGTH_SHORT).show();
				    }
				});


				builder.create();
				builder.show();

			}
		});

	}
}