package com.javapassion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MyButtonActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);

		// Register event handler to the Button View object
		myButton.setOnClickListener(new Button.OnClickListener() {

			// When clicked display an AlertDialog with a list of selectable items.
			@Override
			public void onClick(View v) {
				
				final CharSequence[] items = {"Red", "Green", "Blue", "Yellow", "Orange"};

				AlertDialog.Builder builder = new AlertDialog.Builder(MyButtonActivity.this);
				
				// Add a title to the dialog with setTitle(CharSequence). Then, add a list 
				// of selectable items with setItems(), which accepts the array of items to 
				// display and a DialogInterface.OnClickListener that defines the action to 
				// take when the user selects an item.
				builder.setTitle("Pick a color");
				builder.setItems(items, new DialogInterface.OnClickListener() {
				    public void onClick(DialogInterface dialog, int item) {
				        Toast.makeText(getApplicationContext(), 
				        		"You picked " + items[item], 
				        		Toast.LENGTH_SHORT).show();
				    }
				});

				builder.create();
				builder.show();

			}
		});

	}
}