package com.javapassion;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

// If you want a customized design for a dialog, you can create your own layout 
// for the dialog window with layout and widget elements. After you've defined 
// your layout, pass the root View object or layout resource ID to setContentView(View).

public class MyButtonActivity extends Activity {
	
    static final int CUSTOM_DIALOG1 = 1;
    static final int CUSTOM_DIALOG2 = 2;
    Button button1, button2;
    
	/** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Setup the button that starts the progress dialog
        button1 = (Button) findViewById(R.id.myButton1);
        button1.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v) {
            	// Show dialog managed by this activity
                showDialog(CUSTOM_DIALOG1);
            }
        }); 
        
        // Setup the button that starts the progress dialog
        button2 = (Button) findViewById(R.id.myButton2);
        button2.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v) {
            	// Show dialog managed by this activity
                showDialog(CUSTOM_DIALOG2);
            }
        }); 
    }
   
    // A dialog is always created and displayed as a part of an Activity. You should 
    // normally create dialogs from within your Activity's onCreateDialog(int) 
    // callback method. When you use this callback, the Android system automatically 
    // manages the state of each dialog and hooks them to the Activity, effectively 
    // making it the "owner" of each dialog. As such, each dialog inherits certain 
    // properties from the Activity. For example, when a dialog is open, the Menu 
    // key reveals the options menu defined for the Activity and the volume keys 
    // modify the audio stream used by the Activity.
    
    // Callback for creating dialogs that are managed (saved and restored) 
    // for you by the activity. 
    protected Dialog onCreateDialog(int id) {
    	Dialog dialog;
    	TextView text;
    	ImageView image;
    	
        switch(id) {
        case CUSTOM_DIALOG1:
        	
        	//Using the following code causes WindowManager.BadTokenException.
        	//Other people experience the same problem.
        	//http://stackoverflow.com/questions/1561803/android-progressdialog-show-crashes-with-getapplicationcontext
        	//Context mContext = getApplicationContext();
        	//Dialog dialog = new Dialog(mContext);
    		dialog = new Dialog(this);

    		// Set your custom layout as the dialog's content view with 
    		// setContentView(int), passing it the layout resource ID. 
    		dialog.setContentView(R.layout.custom_dialog1);
    		dialog.setTitle("Custom Dialog 1");

    		// Now that the Dialog has a defined layout, you can capture View 
    		// objects from the layout with findViewById(int) and modify their content.
    		text = (TextView) dialog.findViewById(R.id.text);
    		text.setText("Hello, this is a custom dialog 1!");
    		image = (ImageView) dialog.findViewById(R.id.image);
    		image.setImageResource(R.drawable.duke1);

            return dialog;
            
        case CUSTOM_DIALOG2:
    		dialog = new Dialog(this);

    		// Set your custom layout as the dialog's content view with 
    		// setContentView(int), passing it the layout resource ID. 
    		dialog.setContentView(R.layout.custom_dialog2);
    		dialog.setTitle("Custom Dialog 2");

    		// Now that the Dialog has a defined layout, you can capture View 
    		// objects from the layout with findViewById(int) and modify their content.
    		text = (TextView) dialog.findViewById(R.id.text);
    		text.setText("Hello, this is a custom dialog 2!");
    		image = (ImageView) dialog.findViewById(R.id.image);
    		image.setImageResource(R.drawable.duke2);

            return dialog;
        default:
            return null;
        }
    }

}