package com.javapassion;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MyButtonActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);

		// Create event handler for the Button View object
		Button.OnClickListener listener = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				ProgressDialog progressDialog;
				progressDialog = new ProgressDialog(MyButtonActivity.this);
				progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				progressDialog.setMessage("Loading...");
				
				// Sets whether this dialog is cancelable with the BACK key. 
				progressDialog.setCancelable(true);	
				progressDialog.show();

			}
		};
		
		// Register event handler to the Button View object
		myButton.setOnClickListener(listener);

	}
}