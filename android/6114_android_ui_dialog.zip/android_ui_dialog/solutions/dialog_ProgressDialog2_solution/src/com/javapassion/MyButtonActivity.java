package com.javapassion;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MyButtonActivity extends Activity {

	static final int PROGRESS_DIALOG = 0;
	static final int PROGRESS_DIALOG_SPINNER = 1;
	Button button;
	ProgressDialog progressDialog;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);
		final Button myButton2 = (Button) findViewById(R.id.myButton2);

		// Create event handler for the Button View object
		Button.OnClickListener listener = new Button.OnClickListener() {

			// When clicked display a AlertDialog with a list of
			// selectable items.
			@Override
			public void onClick(View v) {

				// Show dialog managed by this activity
				showDialog(PROGRESS_DIALOG);

			}
		};

		// Register event handler to the Button View object
		myButton.setOnClickListener(listener);
		
		// Create event handler for the Button View object
		Button.OnClickListener listener2 = new Button.OnClickListener() {

			// When clicked display a AlertDialog with a list of
			// selectable items.
			@Override
			public void onClick(View v) {

				// Show dialog managed by this activity
				showDialog(PROGRESS_DIALOG_SPINNER);

			}
		};

		// Register event handler to the Button View object
		myButton2.setOnClickListener(listener2);

	}

	// Callback for creating dialogs that are managed (saved and restored)
	// for you by the activity.
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case PROGRESS_DIALOG:
			progressDialog = new ProgressDialog(MyButtonActivity.this);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			progressDialog.setMessage("Loading...");
			return progressDialog;
		case PROGRESS_DIALOG_SPINNER:
			progressDialog = new ProgressDialog(MyButtonActivity.this);
			progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			progressDialog.setMessage("Loading...");
			return progressDialog;
		default:
			return null;
		}
	}
}