/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

// Need the following import to get access to the app resources, since this
// class is in a sub-package.
import com.javapassion.R;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.SystemClock;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/**
 * This demonstrates how you can schedule an alarm that causes a service to be
 * started. This is useful when you want to schedule alarms that initiate
 * long-running operations, such as retrieving recent e-mails.
 */
public class AlarmController extends Activity {

	PendingIntent pendingIntent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.alarm_service);

		// Watch for button clicks.
		Button button = (Button) findViewById(R.id.start_alarm);
		button.setOnClickListener(mStartAlarmListener);
		button = (Button) findViewById(R.id.stop_alarm);
		button.setOnClickListener(mStopAlarmListener);
	}

	// Event listener for "Start alarm service" button
	private OnClickListener mStartAlarmListener = new OnClickListener() {
		public void onClick(View v) {
			// Create an Intent that will launch our service, to be
			// scheduled with the alarm manager.
			Intent intent = new Intent(AlarmController.this, AlarmService.class);
			pendingIntent = PendingIntent.getService(AlarmController.this, // context
					0, // request code
					intent, // intent
					0); // flags

			long firstTime = SystemClock.elapsedRealtime();
			firstTime += 15*1000;

			// Schedule the alarm!
			AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
			am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, // type
					firstTime, // triggerAtTime
					15 * 1000, // interval
					pendingIntent); // PendingIntent operation

			// Tell the user about what we did.
			Toast.makeText(AlarmController.this, R.string.repeating_scheduled,
					Toast.LENGTH_LONG).show();
		}
	};

	// Event listener for "Stop alarm service" button
	private OnClickListener mStopAlarmListener = new OnClickListener() {
		public void onClick(View v) {
			// And cancel the alarm.
			AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
			am.cancel(pendingIntent);

			// Tell the user about what we did.
			Toast.makeText(AlarmController.this,
					R.string.repeating_unscheduled, Toast.LENGTH_LONG).show();

		}
	};
}
