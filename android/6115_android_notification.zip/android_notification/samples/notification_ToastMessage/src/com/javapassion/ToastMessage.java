package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ToastMessage extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get Button View object
		final Button myButton = (Button) findViewById(R.id.myButton);

		// Register event handler to the Button View object
		myButton.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				Toast.makeText(
						ToastMessage.this,		// Qualify 'this" with Activity class
						R.string.toast_message,		// Get string resource to display
						Toast.LENGTH_LONG).show();	// Make sure you call show() method

			}
		});

	}
}