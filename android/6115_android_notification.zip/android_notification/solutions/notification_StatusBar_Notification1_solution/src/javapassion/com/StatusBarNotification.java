package javapassion.com;

import javapassion.com.R;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class StatusBarNotification extends Activity {

	private NotificationManager mNotificationManager;
	private int SIMPLE_NOTFICATION_ID = 01;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Get a reference to the NotificationManager: 
		mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		
		// Instantiate the Notification.  Use an instance of the Notification class to 
		// define the properties of your status bar notification, such as the status bar icon, 
		// the expanded message, and extra settings such as a sound to play.
		final Notification mNotification = new Notification(R.drawable.android,
		        "New Alert, Pull me down to see Notification details!", 
		        System.currentTimeMillis());

		Button startButton = (Button) findViewById(R.id.notifyButton);
		Button cancelButton = (Button) findViewById(R.id.cancelButton);

		// Start notification
		startButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

				// Define the Notification's expanded message (notification detail) 
				// and Intent.
				Context context = getApplicationContext();
				CharSequence contentTitle = "Notification Details.";
				CharSequence contentText = "Go to Dial screen by clicking me";
				
				Intent notifyIntent = new Intent(Intent.ACTION_DIAL);
				Uri uri = Uri.parse("tel:123-567-1234");
				notifyIntent.setData(uri);
				
				PendingIntent mPendingIntent = PendingIntent.getActivity(
				        StatusBarNotification.this, 0, notifyIntent,
				        android.content.Intent.FLAG_ACTIVITY_NEW_TASK);

				mNotification.setLatestEventInfo(context, contentTitle,
				        contentText, mPendingIntent);
				
				// Pass the Notification to the NotificationManager
				// When you want to send your status bar notification, pass the Notification 
				// object to the NotificationManager with notify(int, Notification). The first 
				// parameter is the unique ID for the Notification and the second is the 
				// Notification object. The ID uniquely identifies the Notification from 
				// within your application. This is necessary if you need to update the 
				// Notification or (if your application manages different kinds of Notifications) 
				// select the appropriate action when the user returns to your application 
				// via the Intent defined in the Notification.
				mNotificationManager.notify(SIMPLE_NOTFICATION_ID,
				        mNotification);
			}
		});

		// Cancel notification.  
		// To clear the status bar notification when the user selects it from the 
		// Notifications window, add the "FLAG_AUTO_CANCEL" flag to your Notification 
		// object. You can also clear it manually with cancel(int), passing it the notification ID, 
		// or clear all your Notifications with cancelAll().
		cancelButton.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				mNotificationManager.cancel(SIMPLE_NOTFICATION_ID);
			}
		});
	}
}