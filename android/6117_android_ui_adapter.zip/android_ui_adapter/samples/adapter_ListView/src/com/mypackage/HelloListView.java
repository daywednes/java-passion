package com.mypackage;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class HelloListView extends Activity {
	
    // Note that using a hard-coded string array is not the best design practice.
    // One is used in this tutorial for simplicity, in order to demonstrate the
    // ListView widget. The better practice is to reference a string array defined
    // by an external resource, such as with a <string-array> resource in your project
    // res/values/strings.xml file.
    static final String[] COUNTRIES = new String[] {
        "Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra",
        "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina",
        "Yemen", "Yugoslavia", "Zambia", "Zimbabwe"
      };
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Since HelloListView extends Activity (instead of ListActivity),
        // we have to create ListView object ourselves.
        ListView lv =(ListView)findViewById(R.id.listview);
        
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
        		this, 					// Application context
        		R.layout.list_item, 	// layout description for each list item
        		COUNTRIES);	
        
        lv.setAdapter(arrayAdapter);        
    
    }
       
}