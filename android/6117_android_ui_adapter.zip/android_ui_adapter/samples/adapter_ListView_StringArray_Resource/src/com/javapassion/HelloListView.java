package com.javapassion;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class HelloListView extends ListActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Notice that this does not load a layout file for the Activity (which you 
        // usually do with setContentView(int)). Instead, setListAdapter(ListAdapter) 
        // automatically adds a ListView to fill the entire screen of the ListActivity.
        // This method takes an ArrayAdapter, which manages the array of list items that 
        // will be placed into the ListView. The ArrayAdapter constructor takes the 
        // application Context, the layout description for each list item, and a List 
        // of objects to insert in the ListView.
        
        // Use string resources instead of hard-coded string literals.  
        String[] countries = getResources().getStringArray(R.array.worldcup2010_countries_array);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
        		this, 					// Application context
        		R.layout.list_item, 	// layout description for each list item
        		countries);				// String array of countries defined
        setListAdapter(arrayAdapter);

        // The setOnItemClickListener(OnItemClickListener) method defines the on-click 
        // listener for each item. When an item in the ListView is clicked, the 
        // onItemClick() method is called and a Toast message is displayed, using the 
        // text from the clicked item.
        ListView lv = getListView();
        lv.setOnItemClickListener(new OnItemClickListener() {
          public void onItemClick(AdapterView<?> parent, View view,
              int position, long id) {
            // When clicked, show a toast with the TextView text
            Toast.makeText(getApplicationContext(), "You selected " + ((TextView) view).getText() + " as winner of 2010 Worldcup",
                Toast.LENGTH_SHORT).show();
          }
        });
        
        // The setTextFilterEnabled(boolean) method turns on text filtering for the 
        // ListView, so that when the user begins typing, the list will be filtered.
        lv.setTextFilterEnabled(true);

    }
    
}