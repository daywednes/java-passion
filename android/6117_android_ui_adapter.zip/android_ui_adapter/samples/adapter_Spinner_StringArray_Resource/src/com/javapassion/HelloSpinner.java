package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class HelloSpinner extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {      
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, 
                R.array.planets_array, 		// Array resource
                android.R.layout.simple_spinner_item);
        
        // Use Android's built-in layout object android.R.layout.simple_spinner_dropdown_item
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        
        spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
    }
    
    // Create a nested class that implements AdapterView.OnItemSelectedListener. 
    // This will provide a callback method that will notify your application when 
    // an item has been selected from the Spinner. 
    // The AdapterView.OnItemSelectedListener requires the onItemSelected() and 
    // onNothingSelected() callback methods. The former is called when an item from 
    // the AdapterView is selected, in which case, a short Toast message displays 
    // the selected text; and the latter is called when a selection disappears from 
    // the AdapterView, which doesn't happen in this case, so it's ignored.
    public class MyOnItemSelectedListener implements OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent,
            View view, int pos, long id) {
          Toast.makeText(parent.getContext(), "The planet is " +
              parent.getItemAtPosition(pos).toString(), Toast.LENGTH_LONG).show();
        }

        public void onNothingSelected(AdapterView parent) {
          // Do nothing.
        }
    }
    
}