package com.mypackage;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class HelloGallery extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // This starts by setting the main.xml layout as the content view and then 
        // capturing the Gallery from the layout with findViewById(int). 
        setContentView(R.layout.main);
        Gallery g = (Gallery) findViewById(R.id.gallery);
        
        // A custom BaseAdapter called ImageAdapter is instantiated and applied 
        // to the Gallery with setAdapter(). (The ImageAdapter class is defined 
        // later in this source file.) 
        g.setAdapter(new ImageAdapter(this));

        // Then an anonymous AdapterView.OnItemClickListener is instantiated. 
        // The onItemClick(AdapterView, View, int, long) callback method receives the 
        // AdapterView where the click occurred, the specific View that received the 
        // click, the position of the View clicked (zero-based), and the row ID 
        // of the item clicked (if applicable).
        // In this example, all that's needed is the position of the click to show 
        // a Toast message that says the position of the item, using makeText(Context, 
        // CharSequence, int) and show() (in a real world scenario, this ID could be 
        // used to get the full sized image for some other task). 
        g.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Toast.makeText(HelloGallery.this, "" + position, Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    public class ImageAdapter extends BaseAdapter {
        int mGalleryItemBackground;
        private Context mContext;

        // An array of IDs that reference the images saved in the drawable resources 
        // directory (res/drawable/).
        private Integer[] mImageIds = {
                R.drawable.sample_1,
                R.drawable.sample_2,
                R.drawable.sample_3,
                R.drawable.sample_4,
                R.drawable.sample_5,
                R.drawable.sample_6,
                R.drawable.sample_7
        };

        // Next is the class constructor, where the Context for an ImageAdapter instance 
        // is defined and the styleable resource defined in res/values/attrs.xml is acquired and 
        // saved to a local field. At the end of the constructor, recycle() is called on the 
        // TypedArray so it can be re-used by the system.
        public ImageAdapter(Context c) {
            mContext = c;
            TypedArray a = obtainStyledAttributes(R.styleable.HelloGallery);
            mGalleryItemBackground = a.getResourceId(
                    R.styleable.HelloGallery_android_galleryItemBackground, 0);
            a.recycle();
        }

        // The methods getCount(), getItem(int), and getItemId(int) are methods that must be 
        // implemented for simple queries on the Adapter.
        public int getCount() {
            return mImageIds.length;
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }
        
        // The method does the work to apply an image to an {@link android.widget.ImageView 
        // that will be embedded in the Gallery. In this method, the member Context is used 
        // to create a new ImageView. The ImageView is prepared by applying an image from 
        // the local array of drawable resources, setting the Gallery.LayoutParams height 
        // and width for the image, setting the scale to fit the ImageView dimensions, and 
        // then finally setting the background to use the styleable attribute acquired in 
        // the constructor.
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView i = new ImageView(mContext);

            i.setImageResource(mImageIds[position]);
            i.setLayoutParams(new Gallery.LayoutParams(150, 100));
            i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            i.setBackgroundResource(mGalleryItemBackground);
            return i;
        }
    }
}