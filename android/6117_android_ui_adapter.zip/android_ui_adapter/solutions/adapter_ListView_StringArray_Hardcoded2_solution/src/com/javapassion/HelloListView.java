package com.javapassion;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

// ListActivity displays a list of items by binding to a data source such as an array 
// or Cursor, and exposes event handlers when the user selects an item. 
// ListActivity hosts a ListView object that can be bound to different data sources, 
// typically either an array or a Cursor holding query results. 
public class HelloListView extends ListActivity {

	// Note that using a hard-coded string array is not the best design
	// practice.
	// One is used in this tutorial for simplicity, in order to demonstrate the
	// ListView widget. The better practice is to reference a string array
	// defined
	// by an external resource, such as with a <string-array> resource in your
	// project
	// res/values/strings.xml file.
	static final String[] COUNTRIES = new String[] { "Afghanistan", "Albania",
	        "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla",
	        "Antarctica", "Antigua and Barbuda", "Argentina", "Yemen",
	        "Yugoslavia", "Zambia", "Zimbabwe" };

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Notice that this does not load a layout file for the Activity (which
		// you
		// usually do with setContentView(int)). Instead,
		// setListAdapter(ListAdapter)
		// automatically adds a ListView to fill the entire screen of the
		// ListActivity.
		// This method takes an ArrayAdapter, which manages the array of list
		// items that
		// will be placed into the ListView. The ArrayAdapter constructor takes
		// the
		// application Context, the layout description for each list item, and a
		// List
		// of objects to insert in the ListView.
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, // Application
																		   // context
		        R.layout.list_item, // layout description for each list item
		        COUNTRIES); // String array of countries defined

		setListAdapter(arrayAdapter); // setListAdaptor(..) is a method of
									  // ListActivity

		// The setOnItemClickListener(OnItemClickListener) method defines the
		// on-click
		// listener for each item. When an item in the ListView is clicked, the
		// onItemClick() method is called and a Toast message is displayed,
		// using the
		// text from the clicked item.
		ListView lv = getListView();
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,
			        int position, long id) {
				// When clicked, show a toast with the TextView text
				Toast.makeText(getApplicationContext(),
				        ((TextView) view).getText() + " is selected",
				        Toast.LENGTH_SHORT).show();

				String country = ((TextView) view).getText().toString();
				if (country.equalsIgnoreCase("Argentina")) {
					Intent intent = new Intent(Intent.ACTION_VIEW);
					Uri uri = Uri
					        .parse("http://en.wikipedia.org/wiki/Argentina");
					intent.setData(uri);
					startActivity(intent);
				}

			}
		});
	}
}