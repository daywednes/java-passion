/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class HelloL10N extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// assign flag.png to the button, loading correct flag image for current
		// locale
		Button b;
		(b = (Button) findViewById(R.id.flag_button))
		        .setBackgroundDrawable(this.getResources().getDrawable(
		                R.drawable.flag));

		// build dialog box to display when user clicks the flag
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(R.string.dialog_text)
		        .setCancelable(false)
		        .setTitle(R.string.dialog_title)
		        .setPositiveButton("Done",
		                new DialogInterface.OnClickListener() {
			                public void onClick(DialogInterface dialog, int id) {
				                dialog.dismiss();
			                }
		                });
		final AlertDialog alert = builder.create();

		// set click listener on the flag to show the dialog box
		b.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				alert.show();
			}
		});
	}

}
