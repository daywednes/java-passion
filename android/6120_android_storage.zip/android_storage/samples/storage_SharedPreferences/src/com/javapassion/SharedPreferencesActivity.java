package com.javapassion;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class SharedPreferencesActivity extends Activity {

	public static final String PREFS_NAME = "MyPrefsFile";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Create Button objects from layout definition file.
		Button buttonAddRow = (Button) findViewById(R.id.button2);
		Button buttonUpdateRows = (Button) findViewById(R.id.button3);

		// Event handler - when this button is clicked, save new entries
		// to Shared preferences.
		buttonAddRow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// We need an Editor object to make preference changes.
				// All objects are from android.context.Context
				SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
				SharedPreferences.Editor editor = settings.edit();
				editor.putString("My prefered sport", "Football");
				editor.putInt("My prefered number", 7);

				// Commit the edits!
				editor.commit();

				Toast.makeText(getApplicationContext(),
						"New preference is added", Toast.LENGTH_LONG).show();
			}
		});

		// Event handler - when this button is clicked, retrieve and
		// display shared preferences.
		buttonUpdateRows.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Get SharedPreferences object
				SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
				
				// Get 3 specific preference values
				String myPreferedSport = settings.getString("My prefered sport",
						"Whatever default");
				Integer myPreferedInt = settings.getInt("My prefered integer number", 10);
				Long myPreferedLong = settings.getLong("My prefered long number", 20);
				
				// Display them as Toast messages
				Toast.makeText(
						getApplicationContext(),
						"My prefered sport is " + myPreferedSport + "\n" +
						"My prefered integer number is " + myPreferedInt + "\n" +
					    "My prefered long number is " + myPreferedLong,
						Toast.LENGTH_LONG).show();
			}
		});
	}
}