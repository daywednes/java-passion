package com.javapassion;

import com.javapassion.R;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class DatabaseActivity extends Activity {
	
	private static final String DATABASE_NAME = "myDB.db";
	private static final String DATABASE_TABLE_NAME = "COUNTRY";
	private static final String DATABASE_CREATE_TABLE = 
		"create table if not exists " + DATABASE_TABLE_NAME + 
		" (_id integer primary key autoincrement, " +
		" country_name text not null, " +
		" capital_city text not null)";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Create Button objects from layout definition file. 
        Button buttonCreateTable = (Button)findViewById(R.id.button1);
        Button buttonAddRow    = (Button)findViewById(R.id.button2);
        Button buttonUpdateRows  = (Button)findViewById(R.id.button3);
        Button buttonNumberOfRows  = (Button)findViewById(R.id.button4);
        Button butShowAllRows   = (Button)findViewById(R.id.button5);
        Button buttonDeleteRows = (Button)findViewById(R.id.button6);
        
        // Event handler - when this button is clicked, create database (if it does
        // not exist yet) and database table (if it does not exist yet).
        buttonCreateTable.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Open a new private SQLiteDatabase associated with this Context's application 
				// package. Create database if it doesn't exist.
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);
				
				// Create database table called "COUNTRY"
				myDB.execSQL(DATABASE_CREATE_TABLE);
				
				myDB.close();				
				Toast.makeText(getApplicationContext(), 
						DATABASE_TABLE_NAME + " table is created if it does not exist", 
						Toast.LENGTH_SHORT).show();
			}      	
        });
        
        // Event handler - when this button is clicked, add a new row to the database table.
        buttonAddRow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {	
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);
				
				// Create a new row (hard-coded value for the simplicity of the exercise)
				// and insert it into the table.
				ContentValues newRow = new ContentValues();
				newRow.put("country_name", "U.S.A.");          // hard-coded for simplicity
				newRow.put("capital_city", "Washington D.C."); // hard-coded for simplicity
				myDB.insert(DATABASE_TABLE_NAME, null, newRow);	
				
				myDB.close();				
				Toast.makeText(getApplicationContext(), 
						newRow.get("country_name") + ":" + newRow.get("capital_city") +
						" is added", Toast.LENGTH_LONG).show();
			}       	
        });
        
        // Event handler - when this button is clicked, update rows
        buttonUpdateRows.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {	
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);
				
				// Create a new row and insert it into the database.
				ContentValues newValues = new ContentValues();
				newValues.put("country_name", "U.S.A.");         // hard-coded for simplicity
				newValues.put("capital_city", "D.C."); 			 // hard-coded for simplicity
				
				// Create whereClause
				String whereClause = "country_name=?";
				String[] whereArgs = new String[] {"U.S.A."};
				
				myDB.update(DATABASE_TABLE_NAME, newValues, whereClause, whereArgs);
				
				myDB.close();				
				Toast.makeText(getApplicationContext(), 
						"Capitical city is updated", Toast.LENGTH_LONG).show();
			}       	
        });
        
        // Event handler - when this button is clicked, retrieve all rows and get the total 
        // number of rows retrieved.
        buttonNumberOfRows.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {				
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);				
				
				// Select columns to retrieve in the form of String array
				String[] resultColumns = new String[] {"_id"};				
				Cursor allRows = myDB.query(DATABASE_TABLE_NAME, 
						resultColumns, 
						null, null, null, null, null, null);				
				Integer c = allRows.getCount();				
				myDB.close();				
				Toast.makeText(getApplicationContext(), "Number of rows: " + 
						c.toString(), Toast.LENGTH_LONG).show();
			}    	
        });
        
        // Event handler - when this button is clicked, retrieve all rows and and display
        // as a single Toast message.  (Typically you would use ListView to display retrieved
        // rows.  But for the simplicity of the exercise, we just create a single text 
        // message from the rows and display it as a Toast message.)
        butShowAllRows.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {			
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);
				
				// Select columns to retrieve in the form of String array
				String[] resultColumns = new String[] {"_id", "country_name", "capital_city"};
				Cursor cursor = myDB.query(DATABASE_TABLE_NAME, 
						resultColumns, 
						null, null, null, null, null, null);
				
				String res = "All capital cities: ";
				Integer cindex = cursor.getColumnIndex("capital_city");
				if (cursor.moveToFirst()) {
					do {
						res += cursor.getString(cindex)+", ";
					} while (cursor.moveToNext());	
				}
				myDB.close();				
				Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG).show();
			}
        });
 

        // Event handler - when this button is clicked, delete rows
        buttonDeleteRows.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {			
				SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null);
				
				// Create whereClause
				String whereClause = "country_name=?";
				String[] whereArgs = new String[] {"U.S.A."};
				
				// Delete all rows whose country_name is "U.S.A."
				myDB.delete(DATABASE_TABLE_NAME, whereClause, whereArgs);
				
				myDB.close();				
				Toast.makeText(getApplicationContext(), "Rows are deleted", Toast.LENGTH_LONG).show();
			}
        });
        
    }
}