package com.javapassion;

import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

// ListActivity displays a list of items by binding to a data source such as an array 
// or Cursor, and exposes event handlers when the user selects an item. 
// ListActivity hosts a ListView object that can be bound to different data sources, 
// typically either an array or a Cursor holding query results. 
public class HelloListView extends ListActivity {

	private static final String TAG = "HelloListView";
	private static final String DATABASE_NAME = "myDB.db";
	private static final String DATABASE_TABLE_NAME = "COUNTRY";
	private static final String DATABASE_CREATE_TABLE = "create table if not exists "
	        + DATABASE_TABLE_NAME
	        + " (_id integer primary key autoincrement, "
	        + " country_name text not null, " + " capital_city text not null)";
	private static final String DATABASE_DELETE_TABLE = "drop table if exists "
	        + DATABASE_TABLE_NAME;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Open a new private SQLiteDatabase associated with this Context's
		// application package. Create database if it doesn't exist.
		SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME,
		        Context.MODE_PRIVATE, null);

		// Create database table called "COUNTRY"
		myDB.execSQL(DATABASE_DELETE_TABLE);
		myDB.execSQL(DATABASE_CREATE_TABLE);
		Log.v(TAG, DATABASE_TABLE_NAME
		        + " table is created if it does not exist");

		// Create new rows (hard-coded value for the simplicity of the exercise)
		// and insert it into the table.
		ContentValues newRow = new ContentValues();
		newRow.put("country_name", "U.S.A."); // hard-coded for simplicity
		newRow.put("capital_city", "Washington D.C."); // hard-coded for
													   // simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		newRow = new ContentValues();
		newRow.put("country_name", "Korea"); // hard-coded for simplicity
		newRow.put("capital_city", "Seoul"); // hard-coded for simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		newRow = new ContentValues();
		newRow.put("country_name", "Brazil"); // hard-coded for simplicity
		newRow.put("capital_city", "Brasilia"); // hard-coded for simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		// Select columns to retrieve in the form of String array
		String[] resultColumns = new String[] { "_id", "country_name",
		        "capital_city" };
		Cursor cursor = myDB.query(DATABASE_TABLE_NAME, resultColumns, null,
		        null, null, null, null, null);

		// Create ListAdapter object
		ListAdapter adapter = new SimpleCursorAdapter(this,
		        android.R.layout.simple_list_item_2, cursor, new String[] {
		                "country_name", "capital_city" }, new int[] {
		                android.R.id.text1, android.R.id.text2 });

		setListAdapter(adapter); // setListAdaptor(..) is a method of
								 // ListActivity

		// The setOnItemClickListener(OnItemClickListener) method defines the
		// on-click listener for each item. When an item in the ListView is clicked, the
		// onItemClick() method is called and a Toast message is displayed,
		// using the text from the clicked item.
		ListView lv = getListView();
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,
			        int position, long id) {

			    Cursor c = (Cursor) parent.getItemAtPosition(position);
                String country = c.getString(1); // Column index
				Toast.makeText(getApplicationContext(),
				        country + " is selected",
				        Toast.LENGTH_SHORT).show();
			}
		});

		// The setTextFilterEnabled(boolean) method turns on text filtering for
		// the ListView, so that when the user begins typing, the list will be
		// filtered.
		lv.setTextFilterEnabled(true);
	}
}