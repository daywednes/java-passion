package com.javapassion;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;


public class HelloSpinnerView extends Activity {

	private static final String TAG = "HelloSpinnerView";
	private static final String DATABASE_NAME = "myDB.db";
	private static final String DATABASE_TABLE_NAME = "COUNTRY";
	private static final String DATABASE_CREATE_TABLE = "create table if not exists "
	        + DATABASE_TABLE_NAME
	        + " (_id integer primary key autoincrement, "
	        + " country_name text not null, " + " capital_city text not null)";
	private static final String DATABASE_DELETE_TABLE = "drop table if exists "
	        + DATABASE_TABLE_NAME;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Open a new private SQLiteDatabase associated with this Context's
		// application package. Create database if it doesn't exist.
		SQLiteDatabase myDB = openOrCreateDatabase(DATABASE_NAME,
		        Context.MODE_PRIVATE, null);

		// Create database table called "COUNTRY"
		myDB.execSQL(DATABASE_DELETE_TABLE);
		myDB.execSQL(DATABASE_CREATE_TABLE);
		Log.v(TAG, DATABASE_TABLE_NAME
		        + " table is created if it does not exist");

		// Create new rows (hard-coded value for the simplicity of the exercise)
		// and insert it into the table.
		ContentValues newRow = new ContentValues();
		newRow.put("country_name", "U.S.A."); // hard-coded for simplicity
		newRow.put("capital_city", "Washington D.C."); // hard-coded for
													   // simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		newRow = new ContentValues();
		newRow.put("country_name", "Korea"); // hard-coded for simplicity
		newRow.put("capital_city", "Seoul"); // hard-coded for simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		newRow = new ContentValues();
		newRow.put("country_name", "Brazil"); // hard-coded for simplicity
		newRow.put("capital_city", "Brasilia"); // hard-coded for simplicity
		myDB.insert(DATABASE_TABLE_NAME, null, newRow);

		// Select columns to retrieve in the form of String array
		String[] resultColumns = new String[] { "_id", "country_name",
		        "capital_city" };
		Cursor cursor = myDB.query(DATABASE_TABLE_NAME, resultColumns, null,
		        null, null, null, null, null);
		
		// Create Spinner View object from layout resource
		Spinner spinner = (Spinner) findViewById(R.id.spinner);
		
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
			    android.R.layout.simple_spinner_item, // Use a template
			                                          // that displays a
			                                          // text view
			    cursor, // Give the cursor to the adapter
			    new String[] {"country_name"}, // Map the NAME column in the
			                                         // people database to...
			    new int[] {android.R.id.text1}); // The "text1" view defined in
			                                     // the XML template
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
	}
	
	// Create a nested class that implements AdapterView.OnItemSelectedListener.
    // This will provide a callback method that will notify your application when
    // an item has been selected from the Spinner.
    // The AdapterView.OnItemSelectedListener requires the onItemSelected() and
    // onNothingSelected() callback methods. The former is called when an item from
    // the AdapterView is selected, in which case, a short Toast message displays
    // the selected text; and the latter is called when a selection disappears from
    // the AdapterView, which doesn't happen in this case, so it's ignored.
	public class MyOnItemSelectedListener implements OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent,
            View view, int position, long id) {
		    Cursor c = (Cursor) parent.getItemAtPosition(position);
            String country = c.getString(1); // Column index
			Toast.makeText(getApplicationContext(),
			        country + " is selected",
			        Toast.LENGTH_SHORT).show();
        }

        public void onNothingSelected(AdapterView parent) {
          // Do nothing.
        }
    }
}