package com.javapassion;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;

public class ContactsViewActivity extends ListActivity {

	// Form an array specifying which columns to retrieve
	private static final String[] PROJECTION = new String[] {
			ContactsContract.Contacts._ID,
			ContactsContract.Contacts.DISPLAY_NAME };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_7);

		// Get a cursor with all people.
		// ContactsContract.Contacts.CONTENT_URI can be replaced with
		// Uri.parse("content://contacts/people/")
		Cursor mCursor = managedQuery(ContactsContract.Contacts.CONTENT_URI,
				PROJECTION, 	// Which columns to retrieve 
				null, 			// Which rows to return (all rows)
				null, 			// Selection arguments (none)
				null);			// Put the results in ascending order by name

		// Display people in a ListView
		ListAdapter adapter = new SimpleCursorAdapter(
				this,
				android.R.layout.simple_list_item_2, 
				mCursor, 
				new String[] {
						ContactsContract.Contacts._ID,
						ContactsContract.Contacts.DISPLAY_NAME },
				new int[] {
						android.R.id.text1, android.R.id.text2 });

		setListAdapter(adapter);
	}
}