package com.javapassion;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Contacts.People;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts.Data;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ContentProviderMain extends Activity {

	final String TAG = "ContentProviderActivity";

	Uri uriNewlyAdded;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Create Button objects from layout definition file.
		Button button1 = (Button) findViewById(R.id.button1);
		Button button2 = (Button) findViewById(R.id.button2);
		Button button3 = (Button) findViewById(R.id.button3);
		Button button4 = (Button) findViewById(R.id.button4);
		Button button5 = (Button) findViewById(R.id.button5);
		Button button6 = (Button) findViewById(R.id.button6);
		Button button7 = (Button) findViewById(R.id.button7);

		// Event handler - when this button is clicked, perform a query to the
		// Contacts content provider through ContactsViewActivity.
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        ContactsViewActivity.class);
				startActivity(intent);
			}
		});

		// (Using old API.)
		// Add a new record to the Contacts content provider
		// and then display through ContactsViewActivity.
		//
		// The values are hard-coded for the simplicity of the program.
		button2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Add a new record
				ContentValues values = new ContentValues();

				// Add new person to contacts and make him a favorite.
				values.put(People._ID, "11"); // Use hard-coded ID for testing
				values.put(People.NAME, "Mich�le Garoche"); // Old API
				// values.put(ContactsContract.Contacts.DISPLAY_NAME,
				// "Mich�le Garoche");
				// 1 = the new contact is added to favorites
				// 0 = the new contact is not added to favorites
				// values.put(People.STARRED, 1);
				values.put(ContactsContract.Contacts.STARRED, 1);

				uriNewlyAdded = getContentResolver().insert(People.CONTENT_URI,
				        values);

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        ContactsViewActivity.class);
				startActivity(intent);

			}
		});

		
		// (Using new API.)
		// Add a new record to the Contacts content provider
		// and then display through ContactsViewActivity.
		//
		// The values are hard-coded for the simplicity of the program.
		button3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				/*
				 * ContentValues values = new ContentValues();
				 * values.put(Data.RAW_CONTACT_ID, "122");
				 * values.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
				 * values.put(Phone.NUMBER, "1-800-GOOG-411");
				 * values.put(Phone.TYPE, Phone.TYPE_CUSTOM);
				 * values.put(Phone.LABEL, "free directory assistance");
				 * uriNewlyAdded =
				 * getContentResolver().insert(ContactsContract.Data
				 * .CONTENT_URI, values);
				 */

				ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();

				// Create RawContacts table
				ops.add(ContentProviderOperation
				        .newInsert(ContactsContract.RawContacts.CONTENT_URI)
				        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE,
				                "com.javapassion")
				        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME,
				                "gaga@javapassion.com").build());

				// Create entry in the Data table
				ops.add(ContentProviderOperation
				        .newInsert(ContactsContract.Data.CONTENT_URI)
				        .withValueBackReference(
				                ContactsContract.Data.RAW_CONTACT_ID, 0)
				        .withValue(
				                ContactsContract.Data.MIMETYPE,
				                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
				        .withValue(
				                ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
				                "Lady Gaga").build());

				// Perform batch operation
				try {
					getContentResolver().applyBatch(ContactsContract.AUTHORITY,
					        ops);
				} catch (Exception e) {
					// Log exception
					Log.e(TAG, "Exceptoin encoutered while inserting contact: "
					        + e);
				}

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        ContactsViewActivity.class);
				startActivity(intent);

			}
		});

		// Query a single record
		button4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Then query for this specific record:
				Cursor cursor = managedQuery(uriNewlyAdded, null, null, null,
				        null);
				if (cursor != null) {
					if (cursor.moveToFirst()) {
						int nameIndex = cursor
						        .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
						String personName = cursor.getString(nameIndex);
						Toast.makeText(getApplicationContext(),
						        "Person's name is " + personName,
						        Toast.LENGTH_LONG).show();
					}
					cursor.close();
				}

			}
		});

		// Add new values.
		button5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
				ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
				        .withValue(Data.RAW_CONTACT_ID, 0)
				        .withValue(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
				        .withValue(Phone.NUMBER, "1-800-GOOG-411")
				        .withValue(Phone.TYPE, Phone.TYPE_CUSTOM)
				        .withValue(Phone.LABEL, "free directory assistance")
				        .build());

				// Display the contacts
				Intent intent = new Intent(v.getContext(),
				        ContactsViewActivity.class);
				startActivity(intent);

			}

		});

		// Update rows
		button6.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				/*
				 * ContentValues newValues = new ContentValues();
				 * newValues.put("country_name", "U.S.A.");
				 * newValues.put("capital_city", "D.C.");
				 * 
				 * // Create whereClause String whereClause = "country_name=?";
				 * String[] whereArgs = new String[] { "U.S.A." };
				 * 
				 * int result = getContentResolver().update(uri, newValues,
				 * whereClause, whereArgs);
				 * 
				 * // Display all contacts Intent intent = new
				 * Intent(v.getContext(), ContactsViewActivity.class);
				 * startActivity(intent);
				 */

			}
		});

		// Event handler - when this button is clicked, delete the row
		// that has been newly added.
		button7.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Delete the record
				getContentResolver().delete(uriNewlyAdded, null, null);

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        ContactsViewActivity.class);
				startActivity(intent);

			}
		});

	}
}