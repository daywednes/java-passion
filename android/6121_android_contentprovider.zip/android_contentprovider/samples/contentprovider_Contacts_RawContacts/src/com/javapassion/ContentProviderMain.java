package com.javapassion;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.RawContacts;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ContentProviderMain extends Activity {

	final String TAG = "ContentProviderActivity";

	Uri uriNewlyAdded;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Create Button objects from layout definition file.
		Button button1 = (Button) findViewById(R.id.button1);
		Button button2 = (Button) findViewById(R.id.button2);
		Button button3 = (Button) findViewById(R.id.button3);
		Button button4 = (Button) findViewById(R.id.button4);

		// Event handler - when this button is clicked, perform a query to the
		// Contacts content provider through RawContactsViewActivity.
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        RawContactsViewActivity.class);
				startActivity(intent);
			}
		});

		// Add a new record to the RawContacts table
		// and then display through RawContactsViewActivity.
		//
		// The values are hard-coded for the simplicity of the program.
		button2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
				ops.add(ContentProviderOperation
				        .newInsert(ContactsContract.RawContacts.CONTENT_URI)
				        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE,
				                "com.google")
				        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME,
				                "xyz@gmail.com").build());
				ops.add(ContentProviderOperation
				        .newInsert(ContactsContract.RawContacts.CONTENT_URI)
				        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE,
				                "com.yahoo")
				        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME,
				                "xyz@yahoo.com").build());
				
				try {
					getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
				} catch (Exception e) {
					// Log exception
					Log.e(TAG, "Exceptoin encoutered while inserting contact: " + e);
				}
				 
				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        RawContactsViewActivity.class);
				startActivity(intent);

			}
		});
		
		// Query a single record
		button3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Use Uri method to produce the base URI.
				// It takes a string rather than an integer.
				Uri myPerson = Uri.withAppendedPath(
				        ContactsContract.Contacts.CONTENT_URI, "112");
				Log.v(TAG, myPerson.toString());

				// Then query for this specific record:
				Cursor cursor = managedQuery(uriNewlyAdded, null, null, null, null);
				if (cursor != null) {
					if (cursor.moveToFirst()) {
						int nameIndex = cursor
						        .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
						String personName = cursor.getString(nameIndex);
						Toast.makeText(getApplicationContext(),
						        "Person's name is " + personName,
						        Toast.LENGTH_LONG).show();
					}
					cursor.close();
				}

			}
		});


		// Delete a row
		button4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Uri myRow = Uri.withAppendedPath(
						RawContacts.CONTENT_URI, "14");

				// Delete the record
				getContentResolver().delete(myRow, null, null);

				// Display all contacts
				Intent intent = new Intent(v.getContext(),
				        RawContactsViewActivity.class);
				startActivity(intent);

			}
		});

	}
}