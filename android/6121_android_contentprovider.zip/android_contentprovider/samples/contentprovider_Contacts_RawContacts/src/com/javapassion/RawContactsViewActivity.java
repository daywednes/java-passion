package com.javapassion;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract.RawContacts;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;

public class RawContactsViewActivity extends ListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_7);

		Cursor mCursor = getContentResolver().query(
				RawContacts.CONTENT_URI,
				null, null, null, null);

		// Display people in a ListView
		ListAdapter adapter = new SimpleCursorAdapter(this,
		        android.R.layout.simple_list_item_2, mCursor, new String[] {
		                RawContacts.ACCOUNT_TYPE, RawContacts.ACCOUNT_NAME },
		        new int[] { android.R.id.text1, android.R.id.text2 });

		setListAdapter(adapter);
	}
}