package com.javapassion;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;

public class BooksViewActivity extends ListActivity {
	
	// Form an array specifying which columns to retrieve
	private static final String[] PROJECTION = new String[] {
			BooksProvider._ID,
			BooksProvider.TITLE };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_7);
		
		Cursor mCursor = managedQuery(BooksProvider.CONTENT_URI, 
				PROJECTION,			// Which columns to retrieve 
		        null, 			// Which rows to return (all rows)
		        null, 			// Selection arguments (none)
		        "_ID ASC");		// Put the results in ascending order by _ID

		// Display books in a ListView
		ListAdapter adapter = new SimpleCursorAdapter(
				this,
				android.R.layout.simple_list_item_2, 
				mCursor, 
				new String[] {
						BooksProvider._ID,
						BooksProvider.TITLE },
				new int[] {
						android.R.id.text1, android.R.id.text2 });

		setListAdapter(adapter);
		
		// Give a back button to a user
		Button button1 = (Button) findViewById(R.id.back_button);
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}
	
}