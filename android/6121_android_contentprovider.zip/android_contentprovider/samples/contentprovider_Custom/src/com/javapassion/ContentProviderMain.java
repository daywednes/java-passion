package com.javapassion;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ContentProviderMain extends Activity {

	Uri uriNewlyAdded;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Create Button objects from layout definition file.
		Button button1 = (Button) findViewById(R.id.button1);
		Button button2 = (Button) findViewById(R.id.button2);
		Button button3 = (Button) findViewById(R.id.button3);
		Button button4 = (Button) findViewById(R.id.button4);
		Button button5 = (Button) findViewById(R.id.button5);
		Button button6 = (Button) findViewById(R.id.button6);

		// Delete all books so that you can run the program in clean slate
		getContentResolver().delete(BooksProvider.CONTENT_URI, null, null);

		// Add new books
		// The values are hard-coded for the simplicity of the program.
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// ---add a book---
				ContentValues values = new ContentValues();
				//values.put(BooksProvider._ID, "1"); 
				values.put(BooksProvider.TITLE, "Android Programming");
				values.put(BooksProvider.ISBN, "1234567890");
				uriNewlyAdded = getContentResolver().insert(
				        BooksProvider.CONTENT_URI, values);

				// ---add another book---
				values.clear();
				//values.put(BooksProvider._ID, "2");
				values.put(BooksProvider.TITLE, "Java Programming");
				values.put(BooksProvider.ISBN, "2222233333");
				uriNewlyAdded = getContentResolver().insert(
				        BooksProvider.CONTENT_URI, values);

				// ---add another book---
				values.clear();
				//values.put(BooksProvider._ID, "3");
				values.put(BooksProvider.TITLE, "Scala Programming");
				values.put(BooksProvider.ISBN, "2222233333");
				uriNewlyAdded = getContentResolver().insert(
				        BooksProvider.CONTENT_URI, values);

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);
			}
		});

		// Display all books
		button2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);

			}
		});

		// Query a single record
		button3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// Use Uri method to produce the base URI.
				// It takes a string rather than an integer.
				Uri myBookUri = Uri.withAppendedPath(BooksProvider.CONTENT_URI,
				        "1");

				// Then query for this specific record.
                // Note that query returns a Cursor object.  Since we have only one item,
                // we will display the first item.
				Cursor cursor = managedQuery(myBookUri, null, null, null, null);
				if (cursor != null) {
					if (cursor.moveToFirst()) {
						int titleIndex = cursor
						        .getColumnIndex(BooksProvider.TITLE);
						String title = cursor.getString(titleIndex);
						Toast.makeText(getApplicationContext(),
						        "Book's title is " + title, Toast.LENGTH_LONG)
						        .show();
					}
					cursor.close();
				}

			}
		});

		// Update a row
		button4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ContentValues editedValues = new ContentValues();
				editedValues.put(BooksProvider.TITLE, "Ruby Programming");

				getContentResolver().update(uriNewlyAdded, editedValues, null,
				        null);

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);

			}
		});

		// Update rows (Bulk update)
		button5.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ContentValues editedValues = new ContentValues();
				editedValues.put(BooksProvider.TITLE, "Asian Cooking");

				getContentResolver().update(BooksProvider.CONTENT_URI,
				        editedValues, null, null);

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);

			}
		});

		// Delete all rows
		button6.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				getContentResolver().delete(BooksProvider.CONTENT_URI, null,
				        null);

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);

			}
		});

	}
}