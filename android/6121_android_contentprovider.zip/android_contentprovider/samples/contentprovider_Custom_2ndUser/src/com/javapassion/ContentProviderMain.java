package com.javapassion;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ContentProviderMain extends Activity {

	Uri uriNewlyAdded;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Create Button objects from layout definition file.
		Button button1 = (Button) findViewById(R.id.button1);
		Button button2 = (Button) findViewById(R.id.button2);

		// Add new books
		// The values are hard-coded for the simplicity of the program.
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// ---add a book---
				ContentValues values = new ContentValues();
				values.put(BooksProvider._ID, "4");
				values.put(BooksProvider.TITLE, "Groovy Programming");
				values.put(BooksProvider.ISBN, "5555567890");
				uriNewlyAdded = getContentResolver().insert(
				        BooksProvider.CONTENT_URI, values);

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);
			}
		});

		// Display all books
		button2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Display all books
				Intent intent = new Intent(v.getContext(),
				        BooksViewActivity.class);
				startActivity(intent);

			}
		});

	}
}