package com.javapassion;

import java.util.List;

import android.app.ListActivity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class ListCPs extends ListActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Get a list of Activities which can handle the intent
		Context context = ListCPs.this;
		PackageManager packageManager = context.getPackageManager();
		List pkgAppsList = packageManager.queryContentProviders(null, 0, 0);

		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
				this, // Context
		        R.layout.list_item, // layout description for each list item
		        pkgAppsList);

		// setListAdaptor(..) is a method of ListActivity.
		setListAdapter(arrayAdapter);

	}

}
