package com.javapassion;

import com.javapassion.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity1 extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Display the passed Action and Data
        TextView myMessage = (TextView) findViewById(R.id.mytextview1);
        myMessage.setText("Action of passed Intent -> " + getIntent().getAction() + "\n" +
        		          "Categories of passed Intent -> " + getIntent().getCategories());
        
        // When the button is clicked, launch Activity2
        Button button = (Button)findViewById(R.id.button1);   
        button.setOnClickListener(new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				// Launch Activity2 explicitly by specifying the target class
				Intent intent = new Intent(v.getContext(), Activity2.class);
                startActivity(intent);
			}
        });
    }
}