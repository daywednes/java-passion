package com.javapassion;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity1 extends Activity {
	
	private static final String TAG = "Activity1->";

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Web browsing
		Button button1 = (Button) findViewById(R.id.button1);
		Button.OnClickListener listener1 = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				// Browse a Web page
				Intent intent = new Intent(Intent.ACTION_VIEW);
				Uri uri = Uri.parse("http://javapassion.com");
				intent.setData(uri);
				startActivity(intent);
			}
		};
		button1.setOnClickListener(listener1);
		
	    // Send an email
	    Button button2 = (Button) findViewById(R.id.button2);
		Button.OnClickListener listener2 = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {				
				Intent intent = new Intent(Intent.ACTION_SEND);
				intent.putExtra(android.content.Intent.EXTRA_TEXT, "my message");
				intent.setType("text/plain");
				startActivity(intent);
			}
		};
		button2.setOnClickListener(listener2);
		
	    // Dial a number as specified by the data. This shows a UI with 
		// the number being dialed, allowing the user to explicitly 
		// initiate the call. 
	    Button button3 = (Button) findViewById(R.id.button3);
		Button.OnClickListener listener3 = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {		
				Intent intent = new Intent(Intent.ACTION_DIAL);
				Uri uri = Uri.parse("tel:123-567-1234");
				intent.setData(uri);
				startActivity(intent);
			}
		};
		button3.setOnClickListener(listener3);
		
	    // Do web search
	    Button button4 = (Button) findViewById(R.id.button4);
		Button.OnClickListener listener4 = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {		
				Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
				Uri uri = Uri.parse("http://google.com");
				intent.setData(uri);
				intent.putExtra(SearchManager.QUERY, "Android");
				startActivity(intent);
			}
		};
		button4.setOnClickListener(listener4);
		
	    // SMS message
	    Button button5 = (Button) findViewById(R.id.button5);
		Button.OnClickListener listener5 = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_SENDTO);
				Uri uri = Uri.parse("smsto://0800000123");
				intent.setData(uri);
				intent.putExtra("sms_body", "The SMS text");  
				startActivity(intent);
			}
		};
		button5.setOnClickListener(listener5);	

	}
}