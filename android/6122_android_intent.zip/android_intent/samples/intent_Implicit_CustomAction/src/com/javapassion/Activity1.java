package com.javapassion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity1 extends Activity {

	private static final String MY_OWN_ACTION_a = "com.javapassion.MY_OWN_ACTION_a";
	private static final String MY_OWN_ACTION_b = "com.javapassion.MY_OWN_ACTION_b";

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// When the button is clicked, launch an activity via intent resolution
		Button button1 = (Button) findViewById(R.id.button1);
		Button button2 = (Button) findViewById(R.id.button2);

		// Create event listener object
		Button.OnClickListener listener = new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				// Launch an activity implicitly
				String myAction;
				if (v.getId() == R.id.button1) {
					myAction = com.javapassion.Activity1.MY_OWN_ACTION_a;
				} else {
					myAction = com.javapassion.Activity1.MY_OWN_ACTION_b;
				}
				Intent intent = new Intent();
				intent.setAction(myAction);
				startActivity(intent);
			}
		};

		// Register event listeners to buttons
		button1.setOnClickListener(listener);
		button2.setOnClickListener(listener);
	}
}