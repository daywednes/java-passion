package com.javapassion;

import com.javapassion.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// This is the activity that gets called by Activity1
public class Activity2b extends Activity{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        
        // Display the passed Action 
        TextView myMessage = (TextView) findViewById(R.id.mytextview2);
        myMessage.setText("Activity2b: Action of passed Intent = " + getIntent().getAction());
        
        // When the button is clicked, finish the current Activity
        Button button = (Button)findViewById(R.id.button2);
        
        button.setOnClickListener(new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				  Intent intent = new Intent();
	              setResult(RESULT_OK, intent);
	              finish();	
			}   	
        });
    }	
}
