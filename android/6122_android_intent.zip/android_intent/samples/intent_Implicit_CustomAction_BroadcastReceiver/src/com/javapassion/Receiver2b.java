package com.javapassion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class Receiver2b extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// Display the passed Action
		Log.v("Receiver2b-->", "onReceive() method of Receiver2b gets called");
	}
}
