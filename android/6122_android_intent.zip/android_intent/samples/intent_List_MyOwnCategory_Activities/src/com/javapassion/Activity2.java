package com.javapassion;

import android.app.Activity;
import android.os.Bundle;

public class Activity2 extends Activity{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }	
}
