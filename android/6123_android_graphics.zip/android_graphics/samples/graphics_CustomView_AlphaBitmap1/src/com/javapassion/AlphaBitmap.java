/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import java.io.InputStream;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class AlphaBitmap extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Create a View object programmatically
		Log.i("AlphaBitmap:onCreate---->", "Before calling setContentView");
		setContentView(new SampleView(this));
		Log.i("AlphaBitmap:onCreate---->", "After calling setContentView");
	}

	private static class SampleView extends View {
		private Bitmap mBitmap;

		public SampleView(Context context) {
			super(context);
			setFocusable(true);

			InputStream is = context.getResources().openRawResource(
			        R.drawable.app_sample_code);

			// Decode an input stream into a bitmap. If the input stream is
			// null, or cannot be used to decode a bitmap, the function returns 
			// null. The stream's position will be where ever it was after the 
			// encoded data was read.
			mBitmap = BitmapFactory.decodeStream(is);

		}

		// To implement a custom view, you will usually begin 
		// by providing overrides for some of the standard 
		// methods that the framework calls on all views. You do 
		// not need to override all of these methods. In fact, 
		// you can start by just overriding onDraw(android.graphics.Canvas)
		@Override
		protected void onDraw(Canvas canvas) {
			Log.i("AlphaBitmap:SimpleView:onDraw---->", "Entering");

			// Fill the entire canvas' bitmap (restricted to the current clip) 
			// with the specified color, using srcover porterduff mode.
			canvas.drawColor(Color.GREEN);

			// The Paint class holds the style and color information about 
			// how to draw geometries, text and bitmaps. 
			Paint p = new Paint();
			float y = 10;

			canvas.drawBitmap(mBitmap, 10, y, p);
			Log.i("AlphaBitmap:SimpleView:onDraw---->", "Exiting");

		}
	}
}
