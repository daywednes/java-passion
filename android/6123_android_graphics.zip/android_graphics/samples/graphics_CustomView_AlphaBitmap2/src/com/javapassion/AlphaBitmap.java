/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import java.io.InputStream;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

public class AlphaBitmap extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Create a View object programmatically
		setContentView(new SampleView(this));
	}

	private static class SampleView extends View {
		private Bitmap mBitmap;
		private Bitmap mBitmap2;

		public SampleView(Context context) {
			super(context);
			setFocusable(true);

			InputStream is = context.getResources().openRawResource(
			        R.drawable.app_sample_code);

			// Decode an input stream into a bitmap. If the input stream is
			// null, or cannot be used to decode a bitmap, the function returns 
			// null. The stream's position will be where ever it was after the 
			// encoded data was read.
			mBitmap = BitmapFactory.decodeStream(is);

			// Returns a new bitmap that captures the alpha values of the
			// original
			mBitmap2 = mBitmap.extractAlpha();

		}

		@Override
		protected void onDraw(Canvas canvas) {
			canvas.drawColor(Color.GREEN);

			Paint p = new Paint();
			float y = 10;

			// Set the paint's color.
			p.setColor(Color.RED);

			y += mBitmap.getHeight() + 10;
			canvas.drawBitmap(mBitmap2, 10, y, p);

		}
	}
}
