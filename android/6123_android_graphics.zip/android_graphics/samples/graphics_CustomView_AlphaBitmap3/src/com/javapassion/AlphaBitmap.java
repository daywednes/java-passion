/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.View;

public class AlphaBitmap extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Create a View object programmatically
		setContentView(new SampleView(this));
	}

	private static class SampleView extends View {

		private Bitmap mBitmap3;
		private Shader mShader;

		public SampleView(Context context) {
			super(context);
			setFocusable(true);

			// Returns a mutable bitmap with the specified width and height. Its
			// initial density is as per getDensity().
			mBitmap3 = Bitmap.createBitmap(200, 200, Bitmap.Config.ALPHA_8);

			// drawIntoBitmap(..) is a method defined later in this file
			drawIntoBitmap(mBitmap3);

			mShader = new LinearGradient(0, 0, 100, 70, new int[] { Color.RED,
			        Color.GREEN, Color.BLUE }, null, Shader.TileMode.MIRROR);
		}

		private static void drawIntoBitmap(Bitmap bm) {
			float x = bm.getWidth();
			float y = bm.getHeight();

			// Construct a canvas with the specified bitmap to draw into.
			Canvas c = new Canvas(bm);
			
			// Create a new paint with default settings.
			Paint p = new Paint();
			p.setAntiAlias(true);
			p.setAlpha(0x80);
			
			// Draw the specified circle using the specified paint. If
			// radius is <= 0, then nothing will be drawn. The circle will
			// be filled or framed based on the Style in the paint.
			c.drawCircle(x / 2, y / 2, x / 2, p);

			p.setAlpha(0x30);
			p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
			p.setTextSize(60);
			p.setTextAlign(Paint.Align.CENTER);
			Paint.FontMetrics fm = p.getFontMetrics();
			
			// Draw the text, with origin at (x,y), using the specified
			// paint. The origin is interpreted based on the Align setting
			// in the paint.
			c.drawText("Alpha", x / 2, (y - fm.ascent) / 2, p);
		}

		@Override
		protected void onDraw(Canvas canvas) {
			canvas.drawColor(Color.WHITE);

			Paint p = new Paint();
			float y = 30;

			p.setShader(mShader);
			canvas.drawBitmap(mBitmap3, 10, y, p);

		}
	}
}
