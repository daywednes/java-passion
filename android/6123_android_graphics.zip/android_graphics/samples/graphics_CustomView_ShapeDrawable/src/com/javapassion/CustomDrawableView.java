package com.javapassion;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.view.View;

public class CustomDrawableView extends View {

	private ShapeDrawable mDrawable;

	public CustomDrawableView(Context context) {
		super(context);

		int x = 10;
		int y = 10;
		int width = 300;
		int height = 50;

		mDrawable = new ShapeDrawable(new OvalShape());
		mDrawable.getPaint().setColor(Color.GREEN);
		mDrawable.setBounds(x, y, x + width, y + height);
	}

	// To implement a custom view, you will usually begin 
	// by providing overrides for some of the standard 
	// methods that the framework calls on all views. You do 
	// not need to override all of these methods. In fact, 
	// you can start by just overriding onDraw(android.graphics.Canvas)
	protected void onDraw(Canvas canvas) {
		mDrawable.draw(canvas);
	}
}