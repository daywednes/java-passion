/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ComposePathEffect;
import android.graphics.CornerPathEffect;
import android.graphics.DiscretePathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.ArcShape;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.PathShape;
import android.graphics.drawable.shapes.RectShape;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;

public class ShapeDrawable1 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new SampleView(this));
    }
    
    private static class SampleView extends View {
        private ShapeDrawable[] mShapeDrawables;
        
        private static Shader makeSweep() {
            return new SweepGradient(150, 25,
                new int[] { 0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFF0000 },
                null);
        }
        
        private static Shader makeLinear() {
            return new LinearGradient(0, 0, 50, 50,
                              new int[] { 0xFFFF0000, 0xFF00FF00, 0xFF0000FF },
                              null, Shader.TileMode.MIRROR);
        }
        
        private static Shader makeTiling() {
            int[] pixels = new int[] { 0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0};
            Bitmap bm = Bitmap.createBitmap(pixels, 2, 2,
                                            Bitmap.Config.ARGB_8888);
            
            return new BitmapShader(bm, Shader.TileMode.REPEAT,
                                        Shader.TileMode.REPEAT);
        }
        
        private static class MyShapeDrawable extends ShapeDrawable {
            private Paint mStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            
            public MyShapeDrawable(Shape s) {
                super(s);
                mStrokePaint.setStyle(Paint.Style.STROKE);
            }
            
            public Paint getStrokePaint() {
                return mStrokePaint;
            }
            
            @Override protected void onDraw(Shape s, Canvas c, Paint p) {
                s.draw(c, p);
                s.draw(c, mStrokePaint);
            }
        }
        
        public SampleView(Context context) {
            super(context);
            setFocusable(true);

            float[] outerR = new float[] { 12, 12, 12, 12, 0, 0, 0, 0 };
            RectF   inset = new RectF(6, 6, 6, 6);
            float[] innerR = new float[] { 12, 12, 0, 0, 12, 12, 0, 0 };
            
            Path path = new Path();
            path.moveTo(50, 0);
            path.lineTo(0, 50);
            path.lineTo(50, 100);
            path.lineTo(100, 50);
            path.close();
            
            mShapeDrawables = new ShapeDrawable[7];
            mShapeDrawables[0] = new ShapeDrawable(new RectShape());
            mShapeDrawables[1] = new ShapeDrawable(new OvalShape());
            mShapeDrawables[2] = new ShapeDrawable(new RoundRectShape(outerR, null,
                                                                 null));
            mShapeDrawables[3] = new ShapeDrawable(new RoundRectShape(outerR, inset,
                                                                 null));
            mShapeDrawables[4] = new ShapeDrawable(new RoundRectShape(outerR, inset,
                                                                 innerR));
            mShapeDrawables[5] = new ShapeDrawable(new PathShape(path, 100, 100));
            mShapeDrawables[6] = new MyShapeDrawable(new ArcShape(45, -270));
            
            mShapeDrawables[0].getPaint().setColor(0xFFFF0000);
            mShapeDrawables[1].getPaint().setColor(0xFF00FF00);
            mShapeDrawables[2].getPaint().setColor(0xFF0000FF);
            mShapeDrawables[3].getPaint().setShader(makeSweep());
            mShapeDrawables[4].getPaint().setShader(makeLinear());
            mShapeDrawables[5].getPaint().setShader(makeTiling());
            mShapeDrawables[6].getPaint().setColor(0x88FF8844);
            
            PathEffect pe = new DiscretePathEffect(10, 4);
            PathEffect pe2 = new CornerPathEffect(4);
            mShapeDrawables[3].getPaint().setPathEffect(
                                                new ComposePathEffect(pe2, pe));
        
            MyShapeDrawable msd = (MyShapeDrawable)mShapeDrawables[6];
            msd.getStrokePaint().setStrokeWidth(4);
        }
        
        int x = 10;
        int y = 10;
        int width = 300;
        int height = 50;
        
        @Override protected void onDraw(Canvas canvas) {
        	
        	// Start from 300 and then decrease the width by 10
        	// each time onDraw() method gets called
        	if (y > 300) y = 10;
        	if (width > 50){
        		width -= 10;
        	}
        	else {
        		width = 300;
        	}
            
        	// Draw all ShapeDrawable's
            for (Drawable dr : mShapeDrawables) {
                dr.setBounds(x, y, x + width, y + height);
                dr.draw(canvas);                
                y += height + 5;
            }
            
            // Just to give some time before next onDraw() call
            SystemClock.sleep(500);
            // Invalidate the whole view. If the view is visible, 
            // onDraw(Canvas) will be called at some point in the future.
            invalidate();
        }
    }
}

