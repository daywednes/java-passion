package com.javapassion;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

class Pyramid {

	private FloatBuffer mVertexBuffer;
	private FloatBuffer mColorBuffer;
	private ByteBuffer mIndexBuffer;

	// Pyramid has 5 vertices
	private float[] vertices = { // 5 vertices of the pyramid in (x,y,z)
			-1.0f, -1.0f, -1.0f, // 0. left-bottom-back
	        1.0f, -1.0f, -1.0f, // 1. right-bottom-back
	        1.0f, -1.0f, 1.0f, // 2. right-bottom-front
	        -1.0f, -1.0f, 1.0f, // 3. left-bottom-front
	        0.0f, 1.0f, 0.0f // 4. top
	};

	private float[] colors = { // Colors of the 5 vertices in RGBA
			0.0f, 0.0f, 1.0f, 1.0f, // 0. blue
	        0.0f, 1.0f, 0.0f, 1.0f, // 1. green
	        0.0f, 0.0f, 1.0f, 1.0f, // 2. blue
	        0.0f, 1.0f, 0.0f, 1.0f, // 3. green
	        1.0f, 0.0f, 0.0f, 1.0f // 4. red
	};
	
    // 5 faces � made up with 6 triangles � bottom face, which is
	// a square is made of two triangles
	private byte[] indices = { 
			2, 4, 3, // front face (CCW) - same as 4,3,2 or 3,2,4
			4, 2, 1, // right face  - same as 2,1,4 or 1,4,2
	        0, 4, 1, // back face - same 4,1,0 or 1,0,4
	        4, 0, 3, // left face - same 0,3,4 or 3,4,2
	        2, 3, 0, // bottom half left - same 3,0,2 or 0,2,3
	        2, 0, 1  // bottom half right - same 0,1,2 or 1,2, 0
	};

	public Pyramid() {

		ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
		vbb.order(ByteOrder.nativeOrder());
		mVertexBuffer = vbb.asFloatBuffer();
		mVertexBuffer.put(vertices);
		mVertexBuffer.position(0);

		ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
		cbb.order(ByteOrder.nativeOrder());
		mColorBuffer = cbb.asFloatBuffer();
		mColorBuffer.put(colors);
		mColorBuffer.position(0);

		mIndexBuffer = ByteBuffer.allocateDirect(indices.length);
		mIndexBuffer.put(indices);
		mIndexBuffer.position(0);
	}

	public void draw(GL10 gl) {

		gl.glFrontFace(GL10.GL_CCW); // Front face in counter-clockwise
		                             // orientation

		// Enable arrays and define their buffers
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, mVertexBuffer);
		gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
		gl.glColorPointer(4, GL10.GL_FLOAT, 0, mColorBuffer);

		gl.glDrawElements(GL10.GL_TRIANGLES, indices.length,
		        GL10.GL_UNSIGNED_BYTE, mIndexBuffer);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_COLOR_ARRAY);

	}

}
