package com.javapassion;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import javax.microedition.khronos.opengles.GL10;

class Square {

	private FloatBuffer vertexBuffer; // Buffer for vertex-array
	private ByteBuffer indexBuffer; // Buffer for index-array
	private IntBuffer mColorBuffer;

	// Square has 4 vertices
	private float[] vertices = { // Vertices for the square
            -1.0f,  1.0f, -0.5f,  // 0, Top Left
            -1.0f, -1.0f, 0.5f,  // 1, Bottom Left
             1.0f, -1.0f, -0.5f,  // 2, Bottom Right
             1.0f,  1.0f, 0.5f,  // 3, Top Right
	};

	// Square is made of two triangles.
	private byte[] indices = { 0, 1, 2, // first triangle
			                   0, 2, 3  // second triangle
			                   };

	// Color array
	private int one = 0x10000;
	private int colors[] = { 0, 0, 0, one, one, 0, 0, one, one, one, 0, one, 0,
	        one, };

	public Square() {

		// Setup vertex-array buffer. Vertices in float. A float has 4 bytes.
		ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
		vbb.order(ByteOrder.nativeOrder()); // Use native byte order
		vertexBuffer = vbb.asFloatBuffer(); // Convert byte buffer to float
		vertexBuffer.put(vertices); // Copy data into buffer
		vertexBuffer.position(0); // Rewind

		// Setup index-array buffer. Indices in byte.
		indexBuffer = ByteBuffer.allocateDirect(indices.length);
		indexBuffer.put(indices);
		indexBuffer.position(0);

		// Color buffer
		ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
		cbb.order(ByteOrder.nativeOrder());
		mColorBuffer = cbb.asIntBuffer();
		mColorBuffer.put(colors);
		mColorBuffer.position(0);

	}

	// Render the shape
	public void draw(GL10 gl) {
		// Enable vertex-array and define the buffers
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);

		// Enable coloring
		gl.glColorPointer(4, GL10.GL_FIXED, 0, mColorBuffer);

		// Draw the primitives via index-array
		gl.glDrawElements(GL10.GL_TRIANGLE_STRIP, indices.length,
		        GL10.GL_UNSIGNED_BYTE, indexBuffer);
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);

	}

}
