/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.apis.graphics;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

class Triangle {
	
	// A unit-sided equalateral triangle centered on the origin.
	float[] vertices = {
	        // X, Y, Z
	        -1.0f, -0.5f, 0, // vertex 0
	        1.0f, -0.5f, 0,  // vertex 1
	        0.0f, 1.0f, 0 }; // vertex 2
	
	// We have 3 vertices
	int numberOfVertices = vertices.length/3;
	
	// The order the vertices to be connected
	byte indices[] = {0, 1, 2};
	
	private FloatBuffer mFVertexBuffer;
	private FloatBuffer mTexBuffer;
	private ByteBuffer mIndexBuffer;
	
	public Triangle() {

		// Buffers to be passed to gl*Pointer() functions
		// must be direct, i.e., they must be placed on the
		// native heap where the garbage collector cannot
		// move them.
		//
		// Buffers with multi-byte datatypes (e.g., short, int, float)
		// must have their byte order set to native order

		ByteBuffer vbb = ByteBuffer.allocateDirect(numberOfVertices * 3 * 4);
		vbb.order(ByteOrder.nativeOrder());
		mFVertexBuffer = vbb.asFloatBuffer();
		mFVertexBuffer.put(vertices);
		mFVertexBuffer.position(0);
		
        // Text buffer
        ByteBuffer tbb = ByteBuffer.allocateDirect(numberOfVertices * 2 * 4);
        tbb.order(ByteOrder.nativeOrder());
        mTexBuffer = tbb.asFloatBuffer();
        for (int i = 0; i < numberOfVertices; i++) {
            for(int j = 0; j < 2; j++) {
                mTexBuffer.put(vertices[i*3+j] * 2.0f + 0.5f);
            }
        }
        mTexBuffer.position(0);

		// Index buffer
		mIndexBuffer = ByteBuffer.allocateDirect(indices.length);
		mIndexBuffer.put(indices);
		mIndexBuffer.position(0);

	}

	// This method draws on Triangle on screen
	public void draw(GL10 gl) {
		gl.glFrontFace(GL10.GL_CCW);
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, mFVertexBuffer);
		gl.glEnable(GL10.GL_TEXTURE_2D);
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, mTexBuffer);
		gl.glDrawElements(GL10.GL_TRIANGLE_STRIP, indices.length,
		        GL10.GL_UNSIGNED_BYTE, mIndexBuffer);
	}

}
