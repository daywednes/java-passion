package com.javapassion;

import java.io.File;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class AudioRecorder extends Activity {

	private MediaPlayer mediaPlayer;
	private MediaRecorder mediaRecorder;
	private static final String OUTPUT_FILE = "/mnt/sdcard/Music/my_recording.3gpp";
	private String TAG = "AudioRecorder-->";

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		Button startBtn = (Button) findViewById(R.id.beginRecording);
		Button endBtn = (Button) findViewById(R.id.stopRecording);
		Button playRecordingBtn = (Button) findViewById(R.id.playRecording);
		Button stpPlayingRecordingBtn = (Button) findViewById(R.id.stopPlaying);

		startBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					Log.d(TAG, "Start recording");
					beginRecording();
				} catch (Exception ex) {
					Log.e(TAG, "Failed to start recording ", ex);
				}
			}
		});

		endBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				try {
					stopRecording();
				} catch (Exception ex) {
					Log.e(TAG, "Oh Oh Failed to stop recording. ", ex);
				}
			}
		});

		stpPlayingRecordingBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				try {
					stopPlayingRecording();
					Log.d(TAG, "Just stopped Recording");
				} catch (Exception ex) {
					Log.e(TAG,
					        "Not Good could not stop playing the recorded sound. ",
					        ex);
				}
			}
		});

		playRecordingBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					playRecording();
				} catch (Exception ex) {
					Log.e(TAG, "Application could play the recording", ex);
				}
			}
		});

		stpPlayingRecordingBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				try {
					playRecording();
				} catch (Exception ex) {
					Log.e(TAG, "Failed to Start Playing the record", ex);
				}
			}
		});
	}

	// Begin recording
	private void beginRecording() throws Exception {
		killMediaRecorder();

		File outFile = new File(OUTPUT_FILE);

		if (outFile.exists()) {
			Log.d(TAG, "The File exists. Deleted");
			outFile.delete();
		}

		mediaRecorder = new MediaRecorder();
		mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
		mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
		mediaRecorder.setOutputFile(OUTPUT_FILE);
		mediaRecorder.prepare();
		mediaRecorder.start();
	}

	// Stop recording
	private void stopRecording() {
		if (mediaRecorder != null) {
			mediaRecorder.stop();
		}
	}

	// Play recorded audio
	private void playRecording() throws Exception {
		killMediaplayer();
		mediaPlayer = new MediaPlayer();
		mediaPlayer.setDataSource(OUTPUT_FILE);
		mediaPlayer.prepare();
		mediaPlayer.start();
	}

	// Stop playing
	private void stopPlayingRecording() throws Exception {
		if (mediaPlayer != null) {
			mediaPlayer.stop();
		}
	}

	// Release the recorder
	private void killMediaRecorder() {
		if (mediaRecorder != null) {
			mediaRecorder.release();
		}
	}
	
	// Release the player
	private void killMediaplayer() {
		if (mediaPlayer != null) {
			try {
				mediaPlayer.release();
			} catch (Exception ex) {
				Log.e(TAG, "Failed to kill the media player.", ex);
			}
		}
	}
	
	// When the application is done, kill the player and recorder
	protected void onDestroy() {
		super.onDestroy();
		killMediaplayer();
		killMediaRecorder();
		Log.d(TAG, "Finished clearing all held resources");
	}
}
