/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import com.javapassion.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button mlocalvideo;
	private Button mstreamvideo;
	private Button mlocalaudio;
	private Button mresourcesaudio;
	private static final String MEDIA = "media";
	static final int LOCAL_AUDIO = 1;
	static final int RESOURCES_AUDIO = 2;
	static final int LOCAL_VIDEO = 3;
	static final int STREAM_VIDEO = 4;

	@Override
	protected void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.main);

		// Display buttons and register event listeners
		mresourcesaudio = (Button) findViewById(R.id.resourcesaudio);
		mresourcesaudio.setOnClickListener(mResourcesAudioListener);
				
		mlocalaudio = (Button) findViewById(R.id.localaudio);
		mlocalaudio.setOnClickListener(mLocalAudioListener);

		mlocalvideo = (Button) findViewById(R.id.localvideo);
		mlocalvideo.setOnClickListener(mLocalVideoListener);

		mstreamvideo = (Button) findViewById(R.id.streamvideo);
		mstreamvideo.setOnClickListener(mStreamVideoListener);
	}

	// Event listener for Resources audio
	private OnClickListener mResourcesAudioListener = new OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(MainActivity.this.getApplication(),
					MediaPlayerDemo_Audio.class);
			intent.putExtra(MEDIA, RESOURCES_AUDIO);
			startActivity(intent);

		}
	};
	
	// Event listener for Local audio button
	private OnClickListener mLocalAudioListener = new OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(MainActivity.this.getApplication(),
					MediaPlayerDemo_Audio.class);
			intent.putExtra(MEDIA, LOCAL_AUDIO);
			startActivity(intent);

		}
	};

	// Event listener for local video
	private OnClickListener mLocalVideoListener = new OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(MainActivity.this,
					MediaPlayerDemo_Video.class);
			intent.putExtra(MEDIA, LOCAL_VIDEO);
			startActivity(intent);

		}
	};
	
	// Event listener for streaming video
	private OnClickListener mStreamVideoListener = new OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(MainActivity.this,
					MediaPlayerDemo_Video.class);
			intent.putExtra(MEDIA, STREAM_VIDEO);
			startActivity(intent);

		}
	};

}
