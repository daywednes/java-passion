package com.javapassion;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;

public class PlayAudioFiles extends Activity {
	private MediaPlayer mMediaPlayer = new MediaPlayer();

	@Override
	public void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.song);

		mMediaPlayer = MediaPlayer.create(this, R.raw.happy_birthday_free);
		mMediaPlayer.start();

	}
}