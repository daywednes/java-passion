package com.javapassion;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

class Mp3Filter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		return (name.endsWith(".mp3"));
	}
}

public class PlayAudioFiles extends ListActivity {

	private List<String> songs = new ArrayList<String>();
	private MediaPlayer mMediaPlayer = new MediaPlayer();

	@Override
	public void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.songlist);

		// In case the directory has not been created, create it here.
		File directoryPath = Environment
		        .getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
		directoryPath.mkdirs();

		// Display the list of MP3 songs
		if (directoryPath.listFiles(new Mp3Filter()).length > 0) {
			for (File file : directoryPath.listFiles(new Mp3Filter())) {
				songs.add(file.getName());
			}

			ArrayAdapter<String> songList = new ArrayAdapter<String>(this,
			        R.layout.song_item, songs);
			setListAdapter(songList);
		}

	}

	// Play the selected song
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		try {
			File directoryPath = Environment
			        .getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);

			mMediaPlayer.reset();
			mMediaPlayer.setDataSource(directoryPath.getAbsolutePath() + "/"
			        + songs.get(position));
			mMediaPlayer.prepare();
			mMediaPlayer.start();
		} catch (IOException e) {
			Log.v(getString(R.string.app_name), e.getMessage());
		}
	}
}