package com.javapassion;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;

public class PlayAudioFiles extends Activity {
	private MediaPlayer mMediaPlayer = new MediaPlayer();

	@Override
	public void onCreate(Bundle icicle) {

		super.onCreate(icicle);
		setContentView(R.layout.songlist);

		try {
			mMediaPlayer.reset();
			String songPath = "http://www.javapassion.com/samplemedia/happy_birthday_free.mp3";
			mMediaPlayer.setDataSource(songPath);
			mMediaPlayer.prepare();
			mMediaPlayer.start();
		} catch (Exception e) {

		}

	}
}