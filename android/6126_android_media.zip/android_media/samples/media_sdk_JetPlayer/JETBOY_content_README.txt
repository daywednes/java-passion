JETBOY Content

The "JETBOY_content" folder contains the JET Creator file and assets used in "JETBOY", the Android demonstration game using SONiVOX' JET interactive music technology.

1. Open a command prompt and go to the directory where the JetCreator tool is located.

2. Launch JET Creator by typing "Python JetCreator.py" (be sure Python and WXWidgets are installed on your system)

3. Select the IMPORT command and import JETBOY.zip.

4. After importing the first time, you can use the OPEN command to open the .jtc file in the folder you selected as the target for import.


The "JETBOY_Music.logic" file is the Logic file used to create the JETBOY music composition. This file is provided for reference.