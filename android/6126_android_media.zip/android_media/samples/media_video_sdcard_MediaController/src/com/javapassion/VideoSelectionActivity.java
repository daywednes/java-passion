/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class VideoSelectionActivity extends ListActivity {

	private List<String> videos = new ArrayList<String>();

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.videolist);

		// In case the directory has not been created, create it here.
		File directoryPath = Environment
		        .getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
		directoryPath.mkdirs();

		// Display the list of MP3 songs
		if (directoryPath.listFiles().length > 0) {
			for (File file : directoryPath.listFiles()) {
				videos.add(file.getName());
			}

			ArrayAdapter<String> videoList = new ArrayAdapter<String>(this,
			        R.layout.video_item, videos);
			setListAdapter(videoList);
		}

	}

	// Play the selected song
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		File directoryPath = Environment
		        .getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);

		String videoPath = directoryPath.getAbsolutePath() + "/"
		        + videos.get(position);

		Intent intent = new Intent(getApplicationContext(),
		        VideoViewActivity.class);
		// Pass the video path as an Action as a convenience.
		intent.setAction(videoPath);
		startActivity(intent);

	}
}
