package com.javapassion;

import java.util.List;

import android.app.ListActivity;
import android.content.Context;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class GetProviders extends ListActivity {
	private LocationManager mLocationManager;

	private String TEST_GPS_PROVIDER = "My Test GPS provider";

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Use the LocationManager class to obtain GPS locations
		mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		// Add test GPS provider
		if (mLocationManager.getProvider(TEST_GPS_PROVIDER) == null) {
			mLocationManager.addTestProvider(TEST_GPS_PROVIDER, // name
			        false, // requiresNetwork
			        false, // requiresSatellite
			        false, // requiresCell
			        false, // hasMonetaryCost
			        false, // supportsAltitude
			        false, // supportsSpeed
			        false, // supportsBearing
			        1, // powerRequirement
			        1); // accuracy
		}

		// Get all GPS providers after adding the test GPS provider
		List<String> allProviders = mLocationManager.getAllProviders();

		ArrayAdapter<String> arrayAdapter = 
			new ArrayAdapter<String>(getApplicationContext(), 
		        R.layout.list_item, // layout description for each list item
		        allProviders);

		// setListAdaptor(..) is a method of ListActivity.
		setListAdapter(arrayAdapter);

	}

}
