package com.javapassion;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

public class LocationActivity extends Activity {
	private LocationManager mLocationManager;
	private LocationListener mLocationListener;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// LocationManager class provides access to the system location
		// services. These services allow applications to obtain periodic updates 
		// of the device's geographical location, or to fire an application-specified 
		// Intent when the device enters the proximity of a given geographical location.
		//
		// You do not instantiate this class directly; instead, retrieve it
		// through Context.getSystemService(Context.LOCATION_SERVICE).
		mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		// Create listener object when location is changed,
		// disabled, enabled, and status is changed.
		mLocationListener = new MyLocationListener();

		mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 
		        0, // minimum time interval for notifications, in milliseconds
		        0, // minimum distance interval for notifications, in meters
		        mLocationListener); // listener object
	}

	// LocationListener class
	private class MyLocationListener implements LocationListener {
		@Override
		public void onLocationChanged(Location loc) {
			if (loc != null) {
				Toast.makeText(
				        getBaseContext(),
				        "Location changed : Lat: " + loc.getLatitude()
				                + " Lng: " + loc.getLongitude(),
				        Toast.LENGTH_LONG).show();
				Intent mIntent = new Intent(getApplicationContext(),LocationChanged.class);
				startActivity(mIntent);
			}
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
		}
	}

}
