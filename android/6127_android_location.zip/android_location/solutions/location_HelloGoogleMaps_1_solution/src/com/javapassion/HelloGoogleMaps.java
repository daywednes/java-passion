package com.javapassion;

import android.os.Bundle;

import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

public class HelloGoogleMaps extends MapActivity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Add Zoom capability
        MapView mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        // Set the map mode to "satellite" mode
        mapView.setSatellite(true);
    }
    
    // This method is required for some accounting from the Maps service 
    // to see if you're currently displaying any route information. In 
    // this case, you're not, so return false.
    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
}