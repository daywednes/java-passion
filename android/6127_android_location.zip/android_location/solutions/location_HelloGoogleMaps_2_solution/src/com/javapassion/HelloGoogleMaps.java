package com.javapassion;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class HelloGoogleMaps extends MapActivity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Add Zoom capability
        MapView mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        
        // All overlay elements on a map are held by the MapView, so when you want to 
        // add some, you have to get a list from the getOverlays() method. Then 
        // instantiate the Drawable used for the map marker, which was saved in the 
        // res/drawable/ directory. The constructor for HelloItemizedOverlay 
        // (your custom ItemizedOverlay) takes the Drawable in order to set 
        // the default marker for all overlay items.
        List<Overlay> mapOverlays = mapView.getOverlays();
        Drawable drawable = this.getResources().getDrawable(R.drawable.androidmarker);
        HelloItemizedOverlay itemizedoverlay = new HelloItemizedOverlay(drawable, this);
    
        // Now create a GeoPoint that defines the map coordinates for the first overlay 
        // item, and pass it to a new OverlayItem.
        //
        // GeoPoint coordinates are specified in microdegrees (degrees * 1e6). The 
        // OverlayItem constructor accepts the GeoPoint location, a string for the 
        // item's title, and a string for the item's snippet text, respectively.
        GeoPoint point = new GeoPoint(19240000,-99120000);
        OverlayItem overlayitem = new OverlayItem(point, "Hola, Mundo!", "I'm in Mexico City!"); 
  
        // Add the OverlayItem to your collection in the HelloItemizedOverlay instance, 
        // then add the HelloItemizedOverlay to the MapView:
        itemizedoverlay.addOverlay(overlayitem);
        mapOverlays.add(itemizedoverlay);
        
        // Add another GeoPoint
        GeoPoint point2 = new GeoPoint(42358333, -71060278);
        OverlayItem overlayitem2 = new OverlayItem(point2, "Boston!", "I love Boston!");
        itemizedoverlay.addOverlay(overlayitem2);
        mapOverlays.add(itemizedoverlay);
    
    }
    
    // This method is required for some accounting from the Maps service 
    // to see if you're currently displaying any route information. In 
    // this case, you're not, so return false.
    @Override
    protected boolean isRouteDisplayed() {
        return false;
    }
}