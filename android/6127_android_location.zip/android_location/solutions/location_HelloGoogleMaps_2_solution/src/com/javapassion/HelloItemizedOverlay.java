package com.javapassion;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class HelloItemizedOverlay extends ItemizedOverlay {

	private static final String TAG = "HelloItemizedOverlay-->";

	// First, you need an OverlayItem ArrayList, in which you'll put
	// each of the OverlayItem objects you want on the map.
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	Context mContext;

	// The constructor must define the default marker for each of the 
	// OverlayItems. In order for the Drawable to actually get drawn, it 
	// must have its bounds defined. Most commonly, you want the center-point 
	// at the bottom of the image to be the point at which it's attached to 
	// the map coordinates. This is handled for you with the boundCenterBottom()  
	// method. Wrap this around our defaultMarker
	public HelloItemizedOverlay(Drawable defaultMarker) {
		super(boundCenterBottom(defaultMarker));
	}

	// Set up the ability to handle touch events on the overlay items. 
	// First, you're going to need a reference to the application Context as 
	// a member of this class. So add Context mContext as a class member, 
	// then initialize it with a new class constructor: 
	public HelloItemizedOverlay(Drawable defaultMarker, Context context) {
		//super(defaultMarker); Tutorial on Google site is incorrect.
		super(boundCenterBottom(defaultMarker));
		mContext = context;
	}

	// Each time you add a new OverlayItem to the ArrayList, you must call 
	// populate() for the ItemizedOverlay, which will read each of the 
	// OverlayItems and prepare them to be drawn.
	public void addOverlay(OverlayItem overlay) {
		mOverlays.add(overlay);
		populate();
	}

	// When the populate() method executes, it will call createItem(int) in 
	// the ItemizedOverlay to retrieve each OverlayItem. You must override 
	// this method to properly read from the ArrayList and return the 
	// OverlayItem from the position specified by the given integer. 
	@Override
	protected OverlayItem createItem(int i) {
		return mOverlays.get(i);
	}

	// Return the current number of items in the ArrayList: 
	@Override
	public int size() {
		return mOverlays.size();
	}
	
	// Override the onTap(int) callback method, which will handle the event 
	// when an item is tapped by the user.
	// This uses the member android.content.Context to create a new 
	// AlertDialog.Builder and uses the tapped OverlayItem's title and 
	// snippet for the dialog's title and message text. 
	@Override
	protected boolean onTap(int index) {
	  OverlayItem item = mOverlays.get(index);
	  AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
	  dialog.setTitle(item.getTitle());
	  dialog.setMessage(item.getSnippet());
	  dialog.show();
	  return true;
	}

}
