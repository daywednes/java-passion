package com.javapassion;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class HelloWorldWidget extends AppWidgetProvider {
	
	private static final String TAG ="HelloWorldWidget-->";

	// This is called to update the App Widget at intervals defined by the 
	// updatePeriodMillis  attribute in the AppWidgetProviderInfo. This 
	// method is also called when the user adds the App Widget, so it 
	// should perform the essential setup, such as define event handlers 
	// for Views and start a temporary Service, if necessary. However, if 
	// you have declared a configuration Activity, this method is not 
	// called when the user adds the App Widget, but is called for the 
	// subsequent updates. It is the responsibility of the configuration 
	// Activity to perform the first update when configuration is done.
	//
	// If your App Widget doesn't create temporary files or databases, or 
	// perform other work that requires clean-up, then onUpdated() may be 
	// the only callback method you need to define
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, 
			int[] appWidgetIds) {
		Log.v(TAG, "onUpdate() is called");
	}
	
	// This is called every time an App Widget is deleted from the App 
	// Widget host.
	//
	// "Note: In Android 1.5 and up to 2.2, there is a known issue in which 
	// the onDeleted() method will not be called when it should be. To work 
	// around this issue, you can implement onReceive() as described below
	// (http://developer.android.com/guide/topics/appwidgets/index.html)
	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		Log.v(TAG, "onDeleted() is called");	
	}
	
	// This is called when an instance the App Widget is created for the first 
	// time. For example, if the user adds two instances of your App Widget, 
	// this is only called the first time. If you need to open a new database 
	// or perform other setup that only needs to occur once for all App Widget 
	// instances, then this is a good place to do it.
	@Override
	public void onEnabled(Context context) {
		Log.v(TAG, "onEnabled() is called");	
	}
	
	// This is called when the last instance of your App Widget is deleted 
	// from the App Widget host. This is where you should clean up any work 
	// done in onEnabled(Context), such as delete a temporary database.
	@Override
	public void onDisabled(Context context) {
		Log.v(TAG, "onDisabled() is called");	
	}
	
	// This is called for every broadcast and before each of the above callback 
	// methods. You normally don't need to implement this method because the 
	// default AppWidgetProvider implementation filters all App Widget broadcasts 
	// and calls the above methods as appropriate.
//	@Override
//	public void onReceive(Context context, Intent intent) {
//		Log.v(TAG, "onReceive() is called");	
//	}
}
