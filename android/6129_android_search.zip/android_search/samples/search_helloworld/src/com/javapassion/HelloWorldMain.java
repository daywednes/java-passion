package com.javapassion;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class HelloWorldMain extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.v("HelloWorldMain--->", "onCreate() called");

        //  Get the Action value from the passed Intent object
        final Intent queryIntent = getIntent();
        final String queryAction = queryIntent.getAction();
       
        // Check if the Action value is Intent.ACTION_SEARCH
        if (Intent.ACTION_SEARCH.equals(queryAction)) {
            Log.v("HelloWorldMain--->", "Intent.ACTION_SEARCH received");
            // Extract the search query
            String query = queryIntent.getStringExtra(SearchManager.QUERY);
            Toast.makeText(
                    getApplicationContext(),       
                    "Search string is " + query, Toast.LENGTH_LONG).show();
            // Call a dummy search method
            dummyPerformSearchAndShowResults(query);
        }
    }
   
    void dummyPerformSearchAndShowResults(String query){
        Toast.makeText(
                getApplicationContext(),       
                "performSearchAndShowResults() method is called", Toast.LENGTH_LONG).show();
       
    }
}