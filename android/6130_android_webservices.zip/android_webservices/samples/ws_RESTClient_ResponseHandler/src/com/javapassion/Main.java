package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main extends Activity {

    String response;

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final EditText mEditText = (EditText) findViewById(R.id.edit_text);       
        final Button mButton = (Button) findViewById(R.id.button);
        final TextView mTextView = (TextView) findViewById(R.id.content);

        mButton.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                try {
                    response = RESTClient.callRESTService(mEditText.getText().toString());
                } catch (Exception e) {
                    response = getString(R.string.error_message);
                    e.printStackTrace();
                }
                mTextView.setText(response);
            }
        });
    }
}