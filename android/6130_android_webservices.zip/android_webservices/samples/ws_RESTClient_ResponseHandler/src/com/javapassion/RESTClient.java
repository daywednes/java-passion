package com.javapassion;

import java.io.IOException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

public class RESTClient {

	public static String callRESTService(String url) {

		String result = null;
		HttpClient httpclient = new DefaultHttpClient();

		// Prepare a request object
		HttpGet httpget = new HttpGet(url);

		try {
			
			ResponseHandler<String> mResponseHandler = new BasicResponseHandler();
			// Executes a request using the given context and processes 
			// the response using the given response handler.
			// Calling execute() with or without a ResponseHandler will block 
			// that thread until the HTTP request has been processed. 
			result = httpclient.execute(httpget, mResponseHandler);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result; 
	}

}
