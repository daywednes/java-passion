package org.developerworks.android;
import java.util.List;

public interface FeedParser {
	List<Message> parse();
}
