package org.developerworks.android;
/**
 * 
 */

public enum ParserType{
	SAX, DOM, ANDROID_SAX, XML_PULL;
}