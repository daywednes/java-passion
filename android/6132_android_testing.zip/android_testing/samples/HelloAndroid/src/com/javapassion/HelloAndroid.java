package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class HelloAndroid extends Activity {
	
	private static final String TAG = "HelloAndroid---->";
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		Log.v(TAG, "onCreate() is called");
		
		super.onCreate(savedInstanceState);
		// Create UI using Layout resource file
		setContentView(R.layout.main);
	}
	
//    public int add(int x, int y){
//        return x+y;
//    }
//   
//    public int multiply(int x, int y){
//        return x*y;
//    }
	
}