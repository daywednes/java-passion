package com.javapassion.test;

import android.test.ActivityInstrumentationTestCase2;
import android.widget.TextView;

//The test case class depends on the HelloAndroid class
import com.javapassion.HelloAndroid;

public class HelloAndroidTest extends
		ActivityInstrumentationTestCase2<HelloAndroid> {

	// These variables are used by the setUp() method below
	private HelloAndroid mActivity;
	private TextView mView;
	private String resourceString;
	private int num1, num2;

	// The test case class constructor is used by the Android testing framework
	// when you run the test. It calls the super constructor with parameters
	// that tell the framework what Android application should be tested.
	public HelloAndroidTest() {
		super("com.javapassion", HelloAndroid.class);
	}

	// The setUp() method overrides the JUnit setUp() method, which the Android
	// testing framework calls prior to running each test method. You use
	// setUp()
	// to initialize variables and prepare the test environment. For this test
	// case, the setUp() method starts the HelloAndroid application, retrieves
	// the text being displayed on the screen, and retrieves the text string in
	// the resource file.
	@Override
	protected void setUp() throws Exception {
		// Call the super constructor (required by JUnit)
		super.setUp();
		
		// Get test target activity
		mActivity = this.getActivity();
		
		// Get TextView object
		mView = (TextView) mActivity
				.findViewById(com.javapassion.R.id.textview);
		
		// Get resource string
		resourceString = mActivity.getString(com.javapassion.R.string.hello);
		
//		num1 = 4;
//		num2 = 3;

	}

	// Preconditions test
	//
	// A preconditions test checks the initial application conditions prior
	// to executing other tests. It's similar to setUp(), but with less
	// overhead, since it only runs once. You can consider this as a unit 
	// test of the application's onCreate() method.
	//
	// Although a preconditions test can check for a variety of different
	// conditions, in this application it only needs to check whether the
	// application under test is initialized properly and the target TextView
	// exists. To do this, it calls the inherited assertNotNull() method,
	// passing a reference to the TextView. The test succeeds only if the
	// object reference is not null.
	public void testPreconditions() {
		assertNotNull(mView);
	}

	// Unit test
	//
	// The method testText() will call a JUnit Assert method to check
	// whether the target TextView is displaying the expected text.
	//
	// For this example, the test expects that the TextView is displaying
	// the string resource that was originally declared for it in HelloAndroid's
	// main.xml file, referred to by the resource ID hello. The call to
	// assertEquals(String,String) compares the expected value, read directly
	// from the hellostring resource, to the text displayed by the TextView,
	// obtained from the TextView's getText() method. The test succeeds only
	// if the strings match.
	public void testText() {
		assertEquals(resourceString, (String) mView.getText());
	}

	// // Unit test the add() method of the HelloAndroid Activity class
	// public void testAdd(){
	// assertEquals(7, mActivity.add(num1, num2));
	// }
	//
	// // Unit test the multiply() method of the HelloAndroid Activity class
	// public void testMultiply(){
	// assertEquals(12, mActivity.multiply(num1, num2));
	// }

}
