Client library for the Android Market licensing server.

See the licensing documentation at http://developer.android.com/guide/publishing/licensing.html
