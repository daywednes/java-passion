package com.javapassion;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.android.vending.licensing.LicenseChecker;
import com.android.vending.licensing.LicenseCheckerCallback;
import com.android.vending.licensing.StrictPolicy;

/**
 * Wrapper activity demonstrating the use of {@link GLSurfaceView}, a view that
 * uses OpenGL drawing into a dedicated surface.
 */
public class MainActivity extends Activity {
	private static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgFn2vSg/zNdT65TA/WZoeHH9AWiJpauf3FMUU4CRAG5drGDZ99pwC/pjNYBiw5OqXLQRROMYYjPBSbId0d03YTlEyJ15+gI0nF7TtEGOgSdCUFfPNCgR8jEr+hIC/jVQuzX2SDgUTxnGpbWXxf6zLg7rHkSzubSGgnG8PEW8HshQ7xdyGWKV3980vGNG0h//KnGATYnDedaq3RHnLnpM06uA3kf5yEPYJM4IsrPP20yq4S+qjsgYb0PfQCvlWdySTfkbRaQLEWwk2ZKz1npu12dhFWzNGMdcyN5ogKkbczk3J3mOnnRuTTJXMCqkejfrmHAG+2fMWRhiDC+nLvhWwwIDAQAB";

	private TextView mStatusText;

	private LicenseCheckerCallback mLicenseCheckerCallback;
	private LicenseChecker mChecker;
	// A handler on the UI thread.
	private Handler mHandler;

	private GLSurfaceView mGLSurfaceView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// 3D graphics related code
		mGLSurfaceView = new GLSurfaceView(this);
		
		// Licensing related code
		setContentView(R.layout.main);

		mStatusText = (TextView) findViewById(R.id.status_text);

		mHandler = new Handler();

		// Library calls this when it's done.
		mLicenseCheckerCallback = new MyLicenseCheckerCallback();
		// Construct the LicenseChecker with a policy.
		mChecker = new LicenseChecker(this, new StrictPolicy(),
				BASE64_PUBLIC_KEY);
		doCheck();
	}

	protected Dialog onCreateDialog(int id) {
		// We have only one dialog.
		return new AlertDialog.Builder(this)
				.setTitle(R.string.unlicensed_dialog_title)
				.setMessage(R.string.unlicensed_dialog_body)
				.setPositiveButton(R.string.buy_button,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent marketIntent = new Intent(
										Intent.ACTION_VIEW,
										Uri.parse("http://market.android.com/details?id="
												+ getPackageName()));
								startActivity(marketIntent);
							}
						})
				.setNegativeButton(R.string.quit_button,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								finish();
							}
						}).create();
	}

	private void doCheck() {
		mStatusText.setText(R.string.checking_license);
		mChecker.checkAccess(mLicenseCheckerCallback);
	}

	// Called within the allow() and dontAllow() methods of
	// MyLicenseCheckerCallback to display license checking
	// result.
	private void displayResult(final String result) {
		mHandler.post(new Runnable() {
			public void run() {
				mStatusText.setText(result);
				
				// Create GLSurfaceView object and set custom renderer
				mGLSurfaceView.setRenderer(new PyramidRenderer(false));
				setContentView(mGLSurfaceView);
			}
		});
	}

	// Implement LicenseCheckerCallback as a private inner class
	private class MyLicenseCheckerCallback implements LicenseCheckerCallback {
		public void allow() {
			if (isFinishing()) {
				// Don't update UI if Activity is finishing.
				return;
			}

			// Should allow user access.
			displayResult(getString(R.string.allow));
		}

		public void dontAllow() {
			if (isFinishing()) {
				// Don't update UI if Activity is finishing.
				return;
			}
			
			// Should not allow access. In most cases, the app should assume
			// the user has access unless it encounters this. If it does,
			// the app should inform the user of their unlicensed ways
			// and then either shut down the app or limit the user to a
			// restricted set of features.
			// In this example, we show a dialog that takes the user to Market.
			showDialog(0);
		}

		public void applicationError(ApplicationErrorCode errorCode) {
			if (isFinishing()) {
				// Don't update UI if Activity is finishing.
				return;
			}
			// This is a polite way of saying the developer made a mistake
			// while setting up or calling the license checker library.
			// Please examine the error code and fix the error.
			String result = String.format(
					getString(R.string.application_error), errorCode);
			displayResult(result);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		mChecker.onDestroy();
	}

}
