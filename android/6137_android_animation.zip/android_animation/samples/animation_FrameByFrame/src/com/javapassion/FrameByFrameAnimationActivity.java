package com.javapassion;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;

public class FrameByFrameAnimationActivity extends Activity {

	AnimationDrawable frameAnimation;
	Boolean animationStarted = false;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.framebyframe);

		// Load the ImageView that will host the animation and
		// set its background to the AnimationDrawable XML resource.
		ImageView img = (ImageView) findViewById(R.id.my_image_view);
		img.setBackgroundResource(R.anim.simple_animation);

		// Get the background, which has been compiled to an
		// AnimationDrawable object.
		frameAnimation = (AnimationDrawable) img.getBackground();

	}

	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			if (animationStarted){
				frameAnimation.stop();
				animationStarted = false;
			}
			else{
				frameAnimation.start();
				animationStarted = true;
			}
			return true;
		}

		return super.onTouchEvent(event);
	}

}
