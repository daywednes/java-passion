/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class SetAnimationActivity extends Activity implements View.OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setanimation_layout);

        Button button1 = (Button) findViewById(R.id.mybutton);
        button1.setOnClickListener(this);
    }

    public void onClick(View v) {
    	AnimationSet mAnimationSet = new AnimationSet(true);
    	Animation rotate = AnimationUtils.loadAnimation(this, R.anim.rotate);
    	mAnimationSet.addAnimation(rotate);
        Animation scale = AnimationUtils.loadAnimation(this, R.anim.scale);
        mAnimationSet.addAnimation(scale);
        Animation translate = AnimationUtils.loadAnimation(this, R.anim.translate);
        mAnimationSet.addAnimation(translate);
        
        findViewById(R.id.myimage).startAnimation(mAnimationSet);
    }

}
