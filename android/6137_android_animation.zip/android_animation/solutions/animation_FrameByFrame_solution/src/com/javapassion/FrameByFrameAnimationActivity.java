package com.javapassion;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

public class FrameByFrameAnimationActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.framebyframe);

		// Get ImageView object
		ImageView img = (ImageView) findViewById(R.id.my_image_view);
		// Set the background to a given resource. The resource should refer to a 
		// Drawable object or 0 to remove the background.
		img.setBackgroundResource(R.anim.simple_animation);

		// Create timer based animation 
		MyAnimationStartClass mMyAnimationStart = new MyAnimationStartClass();
		MyAnimationStopClass mMyAnimationStop = new MyAnimationStopClass();

		Timer t = new Timer(false);
		t.schedule(mMyAnimationStart, 100);
		Timer t2 = new Timer(false);
		t2.schedule(mMyAnimationStop, 5000);

	}

	// Class to be used to start the animation
	class MyAnimationStartClass extends TimerTask {

		public void run() {
			ImageView img = (ImageView) findViewById(R.id.my_image_view);
			// Get the background, which has been compiled to an
			// AnimationDrawable object.
			AnimationDrawable frameAnimation = (AnimationDrawable) img
			        .getBackground();

			// Start the animation (looped playback by default).
			frameAnimation.start();
		}
	}

	// Class to be used to stop the animation
	class MyAnimationStopClass extends TimerTask {

		public void run() {
			ImageView img = (ImageView) findViewById(R.id.my_image_view);
			// Get the background, which has been compiled to an
			// AnimationDrawable object.
			AnimationDrawable frameAnimation = (AnimationDrawable) img
			        .getBackground();

			// stop the animation (looped playback by default).
			frameAnimation.stop();
		}
	}
}
