package com.javapassion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public  class ServiceLauncher extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.service_start_arguments_controller);

        // Watch for button clicks.
        Button button = (Button)findViewById(R.id.start1);
        button.setOnClickListener(mStart1Listener);
        button = (Button)findViewById(R.id.start2);
        button.setOnClickListener(mStart2Listener);
        button = (Button)findViewById(R.id.start3);
        button.setOnClickListener(mStart3Listener);
        button = (Button)findViewById(R.id.startfail);
        button.setOnClickListener(mStartFailListener);
        button = (Button)findViewById(R.id.kill);
        button.setOnClickListener(mKillListener);
    }

    private OnClickListener mStart1Listener = new OnClickListener() {
        public void onClick(View v) {
            startService(new Intent(ServiceLauncher.this,
                    ServiceWithArguments.class)
                            .putExtra("name", "One"));
        }
    };

    private OnClickListener mStart2Listener = new OnClickListener() {
        public void onClick(View v) {
            startService(new Intent(ServiceLauncher.this,
                    ServiceWithArguments.class)
                            .putExtra("name", "Two"));
        }
    };

    private OnClickListener mStart3Listener = new OnClickListener() {
        public void onClick(View v) {
            startService(new Intent(ServiceLauncher.this,
                    ServiceWithArguments.class)
                            .putExtra("name", "Three")
                            .putExtra("redeliver", true));
        }
    };

    private OnClickListener mStartFailListener = new OnClickListener() {
        public void onClick(View v) {
            startService(new Intent(ServiceLauncher.this,
                    ServiceWithArguments.class)
                            .putExtra("name", "Failure")
                            .putExtra("fail", true));
        }
    };

    private OnClickListener mKillListener = new OnClickListener() {
        public void onClick(View v) {
            // This is to simulate the service being killed while it is
            // running in the background.
            Process.killProcess(Process.myPid());
        }
    };
}
