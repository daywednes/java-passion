package com.javapassion;

import com.javapassion.R;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.widget.Toast;

public class MusicPlayerService extends Service {

	MediaPlayer player;
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	// Called by the system when the service is first created. 
	@Override
	public void onCreate() {
		Toast.makeText(this, "MusicPlayerService Created", Toast.LENGTH_LONG).show();
		player = MediaPlayer.create(this, R.raw.happy_birthday_free);
		player.setLooping(true);
	}
	
	// Called by the system every time a client explicitly starts the service 
	// by calling startService(Intent), providing the arguments it supplied and a 
	// unique integer token representing the start request. 
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)  {
		Toast.makeText(this, "MusicPlayerService Started", Toast.LENGTH_LONG).show();
		player.start();
	    // We want this service to continue running until it is explicitly
	    // stopped, so return sticky.
	    return START_STICKY;
	}
	
	// Called by the system to notify a Service that it is no longer used and is being 
	// removed. The service should clean up an resources it holds (threads, registered 
	// receivers, etc) at this point. Upon return, there will be no more calls in to 
	// this Service object and it is effectively dead. 
	@Override
	public void onDestroy() {
		Toast.makeText(this, "MusicPlayerService Stopped", Toast.LENGTH_SHORT).show();
		player.stop();
	}
	
}
