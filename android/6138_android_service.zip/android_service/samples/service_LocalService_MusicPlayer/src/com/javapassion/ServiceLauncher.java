package com.javapassion;

import com.javapassion.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ServiceLauncher extends Activity {

	// Context class is a super class of Activity class.
	Context myContext = this;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Button startButton = (Button) findViewById(R.id.startButton);
		Button stopButton = (Button) findViewById(R.id.stopButton);

		// Start Music Player service.
		startButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// startService(..) method is from Context class, which is
				// a superclass of Activity class
				startService(new Intent(myContext, MusicPlayerService.class));
			}
		});

		// Stop Music Player service.
		stopButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// stopService(..) method is from Context class, which is
				// a superclass of Activity class
				stopService(new Intent(myContext, MusicPlayerService.class));
			}
		});

	}
}