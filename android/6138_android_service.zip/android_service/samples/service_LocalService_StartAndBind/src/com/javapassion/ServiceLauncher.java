package com.javapassion;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/**
 * <p>
 * Example of explicitly starting and stopping the local service. This
 * demonstrates the implementation of a service that runs in the same process as
 * the rest of the application, which is explicitly started and stopped as
 * desired.
 * </p>
 */
public class ServiceLauncher extends Activity {



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.local_service_controller);

		// Watch for button clicks.
		Button button1 = (Button) findViewById(R.id.start);
		button1.setOnClickListener(mStartListener);
		Button button2 = (Button) findViewById(R.id.stop);
		button2.setOnClickListener(mStopListener);
		Button button3 = (Button) findViewById(R.id.bind);
		button3.setOnClickListener(mBindListener);
		Button button4 = (Button) findViewById(R.id.unbind);
		button4.setOnClickListener(mUnbindListener);
		Button button5 = (Button) findViewById(R.id.call1);
		button5.setOnClickListener(mCall1Listener);
		Button button6 = (Button) findViewById(R.id.call2);
		button6.setOnClickListener(mCall2Listener);
	}

	// Handle start a service button
	private OnClickListener mStartListener = new OnClickListener() {
		public void onClick(View v) {
			// Make sure the service is started. It will continue running
			// until someone calls stopService(). The Intent we use to find
			// the service explicitly specifies our service component, because
			// we want it running in our own process and don't want other
			// applications to replace it.
			startService(new Intent(getApplicationContext(), LocalService.class));
		}
	};

	// Handle stop a service button
	private OnClickListener mStopListener = new OnClickListener() {
		public void onClick(View v) {
			// Cancel a previous call to startService(). Note that the
			// service will not actually stop at this point if there are
			// still bound clients.
			boolean result = stopService(new Intent(getApplicationContext(), LocalService.class));
			String result_string = result? "Service is stopped":"Service is not stopped";
			Toast.makeText(getApplicationContext(),
					result_string,
					Toast.LENGTH_LONG).show();
		}
	};
	
	private boolean mIsBound;
	private LocalService mBoundService;

	// The ServiceConnection is Interface for monitoring the state of a
	// service.
	private ServiceConnection mConnection = new ServiceConnection() {

		// This is called when the connection with the service has been
		// established, giving us the service object we can use to
		// interact with the service. Because we have bound to a explicit
		// service that we know is running in our own process, we can
		// cast its IBinder to a concrete class and directly access it.
		public void onServiceConnected(ComponentName className, IBinder service) {

			mBoundService = ((LocalService.LocalBinder) service).getService();
			Toast.makeText(getApplicationContext(),
					R.string.local_service_connected, Toast.LENGTH_LONG)
					.show();
		}

		// This is called when the connection with the service has been
		// unexpectedly disconnected -- that is, its process crashed.
		// Because it is running in our same process, we should never
		// see this happen.
		public void onServiceDisconnected(ComponentName className) {

			mBoundService = null;
			Toast.makeText(getApplicationContext(),
					R.string.local_service_unexpectedly_disconnected, Toast.LENGTH_LONG)
					.show();
		}
	};

	// Handle the binding
	private OnClickListener mBindListener = new OnClickListener() {
		public void onClick(View v) {
			// Establish a connection with the service. We use an explicit
			// service class name because we want a specific service 
			// implementation that we know will be running in our own 
			// process (and thus won't be supporting component replacement 
			// by other applications).
			bindService(
					new Intent(getApplicationContext(), LocalService.class),
					mConnection, Context.BIND_AUTO_CREATE);
			mIsBound = true;
		}
	};

	// Handle the unbinding
	private OnClickListener mUnbindListener = new OnClickListener() {
		public void onClick(View v) {
			if (mIsBound) {
				// Disconnect from an application service. You will no longer
				// receive calls as the service is restarted, and the service is
				// now allowed to stop at any time.
				unbindService(mConnection);
				mIsBound = false;
			}
		}
	};

	// Handle the calling service - Get counter value
	private OnClickListener mCall1Listener = new OnClickListener() {
		public void onClick(View v) {
			if (mIsBound) {
				long counter = mBoundService.getCounter();
				Toast.makeText(getApplicationContext(),
						"Counter value: " + counter, Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(getApplicationContext(),
						"You have to bind to the service first",
						Toast.LENGTH_LONG).show();
			}
		}
	};

	// Handle the calling service - Reset counter value
	private OnClickListener mCall2Listener = new OnClickListener() {
		public void onClick(View v) {
			if (mIsBound) {
				mBoundService.resetCounter();
				Toast.makeText(getApplicationContext(),
						"Counter value is reset to 0", Toast.LENGTH_LONG)
						.show();
			} else {
				Toast.makeText(getApplicationContext(),
						"You have to bind to the service first",
						Toast.LENGTH_LONG).show();
			}
		}
	};

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mIsBound) {
			// Disconnect from an application service. You will no longer
			// receive calls as the service is restarted, and the service is
			// now allowed to stop at any time.
			unbindService(mConnection);
			mIsBound = false;
		}
	}

}