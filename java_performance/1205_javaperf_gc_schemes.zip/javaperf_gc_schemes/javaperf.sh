#!/bin/bash
# javaperf.sh v1.2
# 
# The javaperf GUI and ancillary scripts ("Software") for 
# LAB-1205 Java Application Performance Analysis are
# 
# Copyright (c) 2006 Sun Microsystems
# 
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated files (the "Software"), to deal
# in the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

name="javaperf"  # application name
jar=lib/$name.jar     # Application jar file relative to CS_HOME
java=java             # name of the Java launcher

# get_dir sets the dir to the directory of this script
get_dir() {
  # echo "0 = $0"
  dir=`/usr/bin/dirname $0`
  cd $dir
  dir=`pwd`
}

# which_program will return the full path of the program given as $1
# if it is not found a blank line is returned
which_program() {
  program=$1
  for component in ${PATH//':'/' '}; do
    if [ -x $component/$program ]; then
      echo "$component/$program"
      break
    fi
  done
  echo ""
}

# set_java_home will set JAVA_HOME if it is not set
# and validate the setting of JAVA_HOME
set_java_home() {
  if [ -z "$JAVA_HOME" ]; then  # is JAVA_HOME not set?
    javadir=`which_program $java`   # see if java is in the PATH
    if [ -n "$javadir" ]; then  # yes it is
      javadir=`/usr/bin/dirname $javadir`
      export JAVA_HOME=`/usr/bin/dirname $javadir`
    else
      echo "Sorry, JAVA_HOME not set and java is not in the PATH"
      exit 1
    fi
  fi
  if [ ! -r $JAVA_HOME/lib/tools.jar ]; then
    echo "Sorry, the setting of JAVA_HOME does not seem to be valid"
    echo "JAVA_HOME=$JAVA_HOME"
    exit 1
  fi
}

set_javaperf_home() {
  if [ -z "$JAVAPERF_HOME" ]; then  # is JAVAPERF_HOME not set?
    get_dir
    export JAVAPERF_HOME=$dir
  fi
  if [ ! -r "$JAVAPERF_HOME/$jar" ]; then
    echo "Sorry, the setting of JAVAPERF_HOME does not seem to be valid"
    echo "JAVAPERF_HOME=$JAVAPERF_HOME"
    exit 1
  fi  
}

set_jvmstat_home() {
  if [ -z "$JVMSTAT_HOME" ]; then  # is JVMSTAT_HOME not set?
    get_dir
    export JVMSTAT_HOME=$dir/jvmstat
  fi
  if [ ! -r "$JVMSTAT_HOME/jars/visualgc.jar" ]; then
    echo "Sorry, the setting of JVMSTAT_HOME does not seem to be valid"
    echo "JVMSTAT_HOME=$JVMSTAT_HOME"
    exit 1
  fi  
}

set_java_home
set_javaperf_home
set_jvmstat_home
# check_demo_home
# check_javaperf_home

echo " "
echo "Environment for $name"
echo " "
echo JAVAPERF_HOME=$JAVAPERF_HOME
echo JAVA_HOME=$JAVA_HOME
echo DEMO_HOME=$DEMO_HOME
echo JVMSTAT_HOME=$JVMSTAT_HOME
echo " "
if [ "X$DISPLAY" = "X" ]; then
  # now go back to the lab directory
  echo "the DISPLAY variable is not set.... you must be logging"
  echo "into this machine from a terminal window.  Please start"
  echo "the windowing session and try again."
else
  echo Launching $name ...
  $JAVA_HOME/bin/$java -jar $JAVAPERF_HOME/$jar &
fi



