/*
 * DeadlockThreads.java
 * 
 * Created on 2007-10-1, 12:35:48
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package deadlock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author root
 */
public class DeadlockThreads {

    public static void main(String[] args) {
        final Friend alphonse = new Friend("Alphonse");
        final Friend gaston = new Friend("Gaston");

        ExecutorService es = Executors.newFixedThreadPool(2);
        es.execute(new Runnable() {

            public void run() {
                alphonse.bow(gaston);
            }
        });

        es.execute(new Runnable() {

            public void run() {
                gaston.bow(alphonse);
            }
        });
    }
}

class Friend {
    private final String name;

    public Friend(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public synchronized void bow(Friend bower) {
        try {
            System.out.printf("%s: %s has bowed to me!%n",
                    name, bower.getName());
            Thread.sleep(1000);
            bower.bowBack(this);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public synchronized void bowBack(Friend bower) {
        System.out.printf("%s: %s has bowed back to me!%n",
                this.name, bower.getName());
    }
}