/* Copyright 2005 Sun Microsystems, Inc. All rights reserved. You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: http://developer.sun.com/berkeley_license.html
$Id: ValidationServlet.java,v 1.2 2005/04/06 19:40:34 gmurray71 Exp $ */
package ajaxbasics;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {
    
    public  void doGet(HttpServletRequest request, HttpServletResponse  response)
    throws IOException, ServletException {
        
        String text = request.getParameter("text");
        int count = (text == null) ? 0 : text.length();
        
        doXmlResponse(response, "number", String.valueOf(count));
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse  response)
    throws IOException, ServletException {
        throw new ServletException("Unexpected post.");
    }
    
    private void doXmlResponse(HttpServletResponse response, String key, String value) throws IOException {
        response.setContentType("text/xml");
        response.setHeader("Cache-Control", "no-cache");
        response.getWriter().write("<"+key+">"+value+"</"+key+">");
    }
}


