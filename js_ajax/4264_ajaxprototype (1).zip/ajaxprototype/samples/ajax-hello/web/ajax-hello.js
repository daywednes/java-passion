// XXX problem with concurrent, out of order requests
// -> serialize requests or use class as listener

var COUNTER = "counter";
var req; // XXX last request sent

function countUserInput() {
    var url = "count?text=" + getElementText("myinputid");
    requestUsingGet(url, processRequest);
}

// XXX process only last sent request
function processRequest() {
    if (req.readyState == 4) {
        if (req.status == 200) {
            var message = getFromResponse(req, "number") + " characters are typed!";
            // setElementTextUsingDOM(COUNTER, message);
            setElementTextUsingInline(COUNTER, "<div>" + message + "</div>");
        }
    }
}

//////////
function getElement(elementId) {
    // TODO must use Map<elementId, element> as element cache
    return document.getElementById(elementId);
}

function getElementText(elementId) {
    return escape(getElement(elementId).value);    
}

function setElementTextUsingInline(elementId, text) {
    document.getElementById(elementId).innerHTML = text;
}

function setElementTextUsingDOM(elementId, text) {
    var element = getElement(elementId);
    var textNode = document.createTextNode(text);    
    // if element has text simple replace it otherwise
    // append the new element
    if (element.childNodes[0]) {
        element.replaceChild(textNode, element.childNodes[0]);
    } else {
        element.appendChild(textNode);
    }
}

function requestUsingGet(url, listener) {
    req = createRequest();
    req.onreadystatechange = listener;
    req.open("GET", url, true); 
    req.send(null);
}

function getFromResponse(request, name) {
    return request.responseXML.getElementsByTagName(name)[0].childNodes[0].nodeValue;
}

function createRequest() {
    if (window.XMLHttpRequest) {
        return new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        return new ActiveXObject("Microsoft.XMLHTTP");
    }
}
