function update() {
  var name = dwr.util.getValue("demoName");
  Demo.sayHello(name, function(data) {
    dwr.util.setValue("demoReply", data);
  });
  // Get the number of hello messages sent
  Demo.getnumberOfHellosSent(function(data) {
    dwr.util.setValue("counterReply", data);
  });
}

