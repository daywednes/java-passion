/* Use DISTINCT */
SELECT DISTINCT salary FROM employees;

