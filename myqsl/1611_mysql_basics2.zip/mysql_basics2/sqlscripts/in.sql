/* Use IN */
SELECT * FROM employees 
WHERE name IN ('nichole', 'jack');

