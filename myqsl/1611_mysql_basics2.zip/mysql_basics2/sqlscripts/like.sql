/* Use LIKE */
SELECT * FROM employees 
WHERE name LIKE '%n%';

SELECT * FROM employees 
WHERE name LIKE '%e';


