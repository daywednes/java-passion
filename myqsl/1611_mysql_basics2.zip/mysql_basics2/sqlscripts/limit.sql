/* Use LIMIT */
SELECT * FROM employees 
LIMIT 3;