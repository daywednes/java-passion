/* Self Join involves joining a table to itself */

/* Self Join */
SELECT 'Self Join', e1.ename, e2.salary
FROM employees AS e1, employees AS e2

