/* Retrieve cities customers are currently living and starts with B */
SELECT city.city AS 'Cities customers are currently living and starts with B'
FROM customer, address, city
WHERE customer.address_id = address.address_id 
    AND address.city_id = city.city_id
    AND city.city REGEXP '^B'
LIMIT 20;



 

 

