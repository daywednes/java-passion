/* Retrieve all customers who are living in Malaysia */
SELECT customer.first_name, customer.last_name, 'lives in Malaysia' 
FROM customer, address, city, country
WHERE customer.address_id = address.address_id 
    AND address.city_id = city.city_id
    AND city.country_id = country.country_id
    AND country.country = 'Malaysia';

/* Retrieve number of customers living in each country */
SELECT country.country, COUNT(country.country) AS 'number of customers'
FROM customer, address, city, country
WHERE customer.address_id = address.address_id 
    AND address.city_id = city.city_id
    AND city.country_id = country.country_id
    AND country.country LIKE '%M%'
    GROUP BY (country.country);

/* Retrieve phone numbers of the customers who are living in Germany */
SELECT customer.first_name, customer.last_name, 'lives in Germany, phone number is ', address.phone 
FROM customer, address, city, country
WHERE customer.address_id = address.address_id 
    AND address.city_id = city.city_id
    AND city.country_id = country.country_id
    AND country.country = 'Germany';


 

 

