/* Display all actors in the film "WORDS HUNTER" */
SELECT actor.first_name, actor.last_name, 'acted in film WORDS HUNDER' 
FROM actor, film, film_actor
WHERE film.film_id = film_actor.film_id AND
      actor.actor_id = film_actor.actor_id AND
      film.title = 'WORDS HUNTER';

/* Display all actors in films released in 2006 */
SELECT actor.first_name, actor.last_name, 'acted in films released in 2006' 
FROM actor, film, film_actor
WHERE film.film_id = film_actor.film_id AND
      actor.actor_id = film_actor.actor_id AND
      film.release_year = 2006
LIMIT 50;


 

