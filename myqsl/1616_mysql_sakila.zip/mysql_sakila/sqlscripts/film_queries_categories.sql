/* Display number of films in each film category */
SELECT category.name AS 'File category', COUNT(category.name) AS 'number of films'
FROM film, category, film_category
WHERE film.film_id = film_category.film_id AND
      category.category_id = film_category.category_id
GROUP BY category.name;
    
/* Display number of films in each film category and the number is over 70 */ 
SELECT category.name AS 'File category', COUNT(category.name) AS 'number of films over 70'
FROM film, category, film_category
WHERE film.film_id = film_category.film_id AND
      category.category_id = film_category.category_id
GROUP BY category.name
HAVING COUNT(category.name) > 70;    

 

