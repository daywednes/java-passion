/* Find all films whose language is English */
SELECT film.title AS 'films whose language is English'
FROM film, language
WHERE film.language_id = language.language_id AND
      language.name='English'
LIMIT 20;

/* Find all films in which SUSAN DAVIS acted */
SELECT film.title AS 'films in which SUSAN DAVIS acted'
FROM film, actor, film_actor
WHERE film.film_id = film_actor.film_id AND
      actor.actor_id = film_actor.actor_id AND
      actor.first_name = 'SUSAN' AND
      actor.last_name = 'DAVIS';

/* Compute number of films in which SUSAN DAVIS acted */
SELECT COUNT(film.title) AS 'number of films SUSAN DAVIS acted'
FROM film, actor, film_actor
WHERE film.film_id = film_actor.film_id AND 
      actor.actor_id = film_actor.actor_id AND
      actor.first_name = 'SUSAN' AND
      actor.last_name = 'DAVIS';


 

