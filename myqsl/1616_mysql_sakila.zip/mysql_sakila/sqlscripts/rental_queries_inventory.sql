/* Find inventory items that have been rented by customer CHARLOTTE HUNTER */
SELECT inventory.inventory_id AS 'inventory items rented by CHARLOTTE HUNTER'
FROM rental, customer, inventory
WHERE rental.customer_id = customer.customer_id AND
      customer.first_name = 'CHARLOTTE' AND
      customer.last_name = 'HUNTER' AND
      rental.inventory_id = inventory.inventory_id
LIMIT 20;

/* Find film titles that have been rented by customer CHARLOTTE HUNTER */
SELECT inventory.inventory_id, film.title AS 'film titles rented by CHARLOTTE HUNTER'
FROM rental, customer, inventory, film
WHERE rental.customer_id = customer.customer_id AND
      customer.first_name = 'CHARLOTTE' AND
      customer.last_name = 'HUNTER' AND
      rental.inventory_id = inventory.inventory_id AND
      inventory.film_id = film.film_id
LIMIT 20;

/* Find film titles that have been rented by customer CHARLOTTE HUNTER 
 * during the month of May 2005 */
SELECT inventory.inventory_id, film.title AS 'film titles rented by CHARLOTTE HUNTER in May 2005'
FROM rental, customer, inventory, film
WHERE rental.customer_id = customer.customer_id AND
      customer.first_name = 'CHARLOTTE' AND
      customer.last_name = 'HUNTER' AND
      rental.inventory_id = inventory.inventory_id AND
      inventory.film_id = film.film_id AND
      rental.rental_date > '2005-05-01 00:00:00' AND
      rental.rental_date < '2005-06-01 00:00:00'
LIMIT 20;

/* Display number of times each DVD is rented during the year of 2005 */ 
SELECT film.title AS 'film title', COUNT(film.title) AS 'number of times rented during 2005'
FROM rental, inventory, film
WHERE rental.inventory_id = inventory.inventory_id AND
      inventory.film_id = film.film_id AND
      rental.rental_date > '2005-01-01 00:00:00' AND
      rental.rental_date < '2006-01-01 00:00:00' 
GROUP BY (film.title)
ORDER BY COUNT(film.title) DESC
LIMIT 20;

      

 
 
 
    
 

