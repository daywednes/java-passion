/* Compute the total rental income during the month of
 * May 2005 */
SELECT SUM(payment.amount) AS 'rental income during May 2005'
FROM payment
WHERE payment.payment_date > '2005-05-01 00:00:00' AND
      payment.payment_date < '2005-06-01 00:00:00';
      
/* Compute the total rental income during the month of
 * May 2005 in store 1 */
SELECT SUM(payment.amount) AS 'rental income during May 2005 in store 1'
FROM payment, store, inventory, rental
WHERE payment.payment_date > '2005-05-01 00:00:00' AND
      payment.payment_date < '2005-06-01 00:00:00' AND
      payment.rental_id = rental.rental_id AND
      rental.inventory_id = inventory.inventory_id AND
      inventory.store_id = store.store_id AND
      store.store_id = 1;      
      
/* Compute the total rental payment by CHARLOTTE HUNTER
 * during the month of May 2005 */
SELECT SUM(payment.amount) AS 'rental payment by CHARLOTTE HUNTER during May 2005'
FROM payment, customer
WHERE payment.payment_date > '2005-05-01 00:00:00' AND
      payment.payment_date < '2005-06-01 00:00:00' AND
      payment.customer_id = customer.customer_id AND
      customer.first_name = 'CHARLOTTE' AND
      customer.last_name = 'HUNTER';

      

 
 
 
    
 

