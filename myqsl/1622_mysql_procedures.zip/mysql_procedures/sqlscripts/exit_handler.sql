DELIMITER $$

CREATE PROCEDURE check_age_with_cursor_exit_handler()
BEGIN
   DECLARE f VARCHAR(255);
   DECLARE a INT;
   
   DECLARE c CURSOR FOR
      SELECT first_name, age FROM person;
      
   /* Declare error handler for no more records error condition */
   /* This should be declared after CURSOR declarion above */
   DECLARE EXIT HANDLER FOR 1329
   BEGIN
      SELECT 'We reached the end of the table!' AS message;
   END;


   OPEN c;
   total: LOOP

      FETCH c INTO f, a;
      IF a > 60 THEN
         SELECT f AS FirstName, a AS Age, 'is Old' AS AgeCategory;
      ELSE
         SELECT f AS FirstName, a AS Age, 'is Young' AS AgeCategory;
      END IF;
    
   END LOOP total;
   CLOSE c;

END $$     

DELIMITER ;
