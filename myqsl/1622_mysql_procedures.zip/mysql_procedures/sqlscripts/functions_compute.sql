DELIMITER $$

CREATE FUNCTION compute_square_function(number INT)
RETURNS INT
BEGIN
   RETURN number * number;
END $$

CREATE FUNCTION compute_circle_area(radius INT)
RETURNS FLOAT
BEGIN
   RETURN PI() * radius * radius;
END $$

DELIMITER ;


