DELIMITER $$

CREATE PROCEDURE compute_square(INOUT number INT)
BEGIN
   SELECT number * number INTO number;
END $$

DELIMITER ;

