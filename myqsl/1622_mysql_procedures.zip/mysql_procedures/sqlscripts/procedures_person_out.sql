DELIMITER $$

CREATE PROCEDURE get_person_name(IN p_id SMALLINT, OUT f_name VARCHAR(45))
BEGIN
   SELECT first_name INTO f_name FROM person 
   WHERE person_id = p_id;
END $$

DELIMITER ;

