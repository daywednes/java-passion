/* Delimiter is set to $$ so that you can use ; 
 * inside body of the procedure.
 */
DELIMITER $$

/* Create a procedure */
CREATE PROCEDURE create_school_table()
BEGIN
   CREATE TABLE school_table (
           school_id INT NOT NULL,
           school_name VARCHAR(45) NOT NULL,
           PRIMARY KEY  (school_id)
   );
END $$

/* Create a procedure */
CREATE PROCEDURE drop_school_table()
BEGIN
   DROP TABLE school_table;
END $$ 

/* Change the delimiter back to ; */
DELIMITER ;    