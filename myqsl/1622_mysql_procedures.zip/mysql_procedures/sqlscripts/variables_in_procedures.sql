DELIMITER $$

CREATE PROCEDURE declare_variables()
BEGIN
   DECLARE counter, return_value INT;
END $$


CREATE PROCEDURE compute_something_with_variables (IN number INT)
BEGIN
   DECLARE my_value INT DEFAULT 9;

   SET @counter = number;
   SELECT @counter * my_value;
END $$

DELIMITER ;

