/* Start from scratch */
DROP TABLE IF EXISTS person_log3;
DROP EVENT IF EXISTS myevent_per_minute;
DROP EVENT IF EXISTS myevent_per_hour;
DROP EVENT IF EXISTS myevent_onetime;

/* Create "person_log3" table. */
CREATE TABLE person_log3 (
 log_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
 user VARCHAR(100) NOT NULL,
 message VARCHAR(100) NOT NULL,
 time TIME,
 PRIMARY KEY  (log_id)
 ) ENGINE=InnoDB;

/* Activate event scheduling */
SET GLOBAL event_scheduler = ON;

/* Create an event handler for every minute */
CREATE EVENT myevent_per_minute
ON SCHEDULE EVERY 1 MINUTE
STARTS CURRENT_TIMESTAMP 
ENDS '2020-05-03 10:00:00'
ENABLE
DO
   INSERT INTO person_log3 (user, message, time)
   VALUES (CURRENT_USER(), 'Useless message', NOW());

/* Create an event handler for every hour */
CREATE EVENT myevent_per_hour
ON SCHEDULE EVERY 1 HOUR
STARTS CURRENT_TIMESTAMP 
ENABLE
DO
   TRUNCATE person_log3;
   
/* Create onetime event handler */
CREATE EVENT myevent_onetime
ON SCHEDULE AT '2010-04-08 12:36' 
ENABLE
DO
   INSERT INTO person_log3 (user, message, time)
   VALUES (CURRENT_USER(), 'Onetime useless message', NOW());   

