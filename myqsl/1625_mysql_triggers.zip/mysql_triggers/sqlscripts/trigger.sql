/* Start from scratch */
DROP TABLE IF EXISTS person_log;
DROP TRIGGER IF EXISTS person_bi;
DROP TRIGGER IF EXISTS person_ai;
DROP TRIGGER IF EXISTS person_bu;
DROP TRIGGER IF EXISTS person_au;
DROP TRIGGER IF EXISTS person_bd;
DROP TRIGGER IF EXISTS person_ad;

/* Create "person_log" table. */
CREATE TABLE person_log (
 log_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
 user VARCHAR(100) NOT NULL,
 message VARCHAR(100) NOT NULL,
 time DATE,
 PRIMARY KEY  (log_id)
 ) ENGINE=InnoDB;


/* Create a trigger - before INSERT */
CREATE TRIGGER person_bi
  BEFORE INSERT ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'New record is about to be added to person table', NOW());

/* Create a trigger - after INSERT */
CREATE TRIGGER person_ai
  AFTER INSERT ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'New record has been added to person table', NOW());

/* Create a trigger - before UPDATE */
CREATE TRIGGER person_bu
  BEFORE UPDATE ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'A record is about to be updated in person table', NOW());

/* Create a trigger - after UPDATE */
CREATE TRIGGER person_au
  AFTER UPDATE ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'A record has been updated in person table', NOW());

/* Create a trigger - before DELETE */
CREATE TRIGGER person_bd
  BEFORE DELETE ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'A record is about to be deleted from person table', NOW());

/* Create a trigger - after DELETE */
CREATE TRIGGER person_ad
  AFTER DELETE ON person
  FOR EACH ROW
     INSERT INTO person_log (user, message, time)
     VALUES (CURRENT_USER(), 'A record has been deleted from person table', NOW());



     