/* Start from scratch */
DROP TABLE IF EXISTS person_log2;
DROP TRIGGER IF EXISTS person_bu;
DROP TRIGGER IF EXISTS person_au;

/* Create "person_log" table. */
CREATE TABLE person_log2 (
 log_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
 user VARCHAR(100) NOT NULL,
 old_value VARCHAR(45) NOT NULL,
 new_value VARCHAR(45) NOT NULL,
 time DATE,
 PRIMARY KEY  (log_id)
 ) ENGINE=InnoDB;


/* Create a trigger - before UPDATE */
CREATE TRIGGER person_bu
  BEFORE UPDATE ON person
  FOR EACH ROW
     INSERT INTO person_log2 (user, old_value, new_value, time)
     VALUES (CURRENT_USER(), OLD.first_name, NEW.first_name, NOW());

/* Create a trigger - after UPDATE */
CREATE TRIGGER person_au
  AFTER UPDATE ON person
  FOR EACH ROW
     INSERT INTO person_log2 (user, old_value, new_value, time)
     VALUES (CURRENT_USER(), OLD.first_name, NEW.first_name, NOW());




     