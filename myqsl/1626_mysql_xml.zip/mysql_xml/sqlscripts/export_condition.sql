SELECT age, first_name FROM person
WHERE age > 30
INTO OUTFILE '/tmp/person_condition.txt'
FIELDS TERMINATED BY ':'
LINES TERMINATED BY '\r\n';