SELECT age, first_name FROM person
INTO OUTFILE '/tmp/person_fields.txt'
FIELDS TERMINATED BY ':'
LINES TERMINATED BY '\n';