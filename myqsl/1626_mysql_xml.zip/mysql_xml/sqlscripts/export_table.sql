CREATE TABLE new_person_table (
   FirstName VARCHAR(255),
   LastName VARCHAR(255)
);

INSERT INTO new_person_table (FirstName, LastName)
SELECT first_name, last_name
FROM person;
