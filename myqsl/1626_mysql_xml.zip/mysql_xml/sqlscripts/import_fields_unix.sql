TRUNCATE newperson;

LOAD DATA INFILE '/tmp/person.txt'
INTO TABLE newperson
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
(person_id, first_name, last_name, age);