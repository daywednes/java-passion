
SET @xml = LOAD_FILE('/tmp/people.xml');

SELECT ExtractValue(@xml,
          '/people/person'
) AS value\G

