
USE sakila;
      
/* Compute the total rental income during the month of
 * May 2005 in store 1 */
EXPLAIN SELECT SUM(payment.amount) AS 'rental income during May 2005 in store 1'
FROM payment, store, inventory, rental
WHERE payment.payment_date > '2005-05-01 00:00:00' AND
      payment.payment_date < '2005-06-01 00:00:00' AND
      payment.rental_id = rental.rental_id AND
      rental.inventory_id = inventory.inventory_id AND
      inventory.store_id = store.store_id AND
      store.store_id = 1\G
      
      

 
 
 
    
 

