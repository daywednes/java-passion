SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

DROP SCHEMA IF EXISTS informatix;
CREATE SCHEMA informatix DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE informatix;

CREATE TABLE Capita (
  capita_id INT NOT NULL AUTO_INCREMENT,
  capita_last_name VARCHAR(45) NOT NULL,
  capita_first_name VARCHAR(45) NOT NULL,
  capita_birth_date date DEFAULT NULL,
  House_house_id INT NOT NULL,
  Quality_quality_id INT NOT NULL,
  PRIMARY KEY (capita_id),
  KEY fk_Capita_House (House_house_id),
  KEY fk_Capita_Quality (Quality_quality_id),
	CONSTRAINT fk_Capita_House FOREIGN KEY (House_house_id) REFERENCES House (house_id) ON DELETE RESTRICT ON UPDATE CASCADE,
	CONSTRAINT fk_Capita_Quality FOREIGN KEY (Quality_quality_id) REFERENCES Quality (quality_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Dialect (
  dialect_id INT NOT NULL AUTO_INCREMENT,
  dialect_name VARCHAR(45) NOT NULL,
  PRIMARY KEY (dialect_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE House (
  house_id INT NOT NULL AUTO_INCREMENT,
  house_name VARCHAR(45) NOT NULL,
  Village_village_id INT NOT NULL,
  PRIMARY KEY (house_id,Village_village_id),
  KEY fk_House_Village (Village_village_id),
	CONSTRAINT fk_House_Village FOREIGN KEY (Village_village_id) REFERENCES Village (village_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Meeting (
  meeting_id INT NOT NULL AUTO_INCREMENT,
  meeting_name VARCHAR(45) NOT NULL,
  Meeting_Type_meeting_type_id INT NOT NULL,
  Village_village_id INT NOT NULL,
  PRIMARY KEY (meeting_id),
  KEY fk_Meeting_Meeting_Type (Meeting_Type_meeting_type_id),
  KEY fk_Meeting_Village (Village_village_id),
	CONSTRAINT fk_Meeting_Meeting_Type FOREIGN KEY (Meeting_Type_meeting_type_id) REFERENCES Meeting_Type (meeting_type_id) ON DELETE RESTRICT ON UPDATE CASCADE,
	CONSTRAINT fk_Meeting_Village FOREIGN KEY (Village_village_id) REFERENCES Village (village_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Meeting_Type (
  meeting_type_id INT NOT NULL AUTO_INCREMENT,
  meeting_type_name VARCHAR(45) NOT NULL,
  PRIMARY KEY (meeting_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Province (
  province_id INT NOT NULL AUTO_INCREMENT,
  province_name VARCHAR(45) NOT NULL,
  Province_province_id INT NOT NULL,
  Dialect_dialect_id INT NOT NULL,
  PRIMARY KEY (province_id),
  KEY fk_Province_Dialect (Dialect_dialect_id),
	CONSTRAINT fk_Province_Dialect FOREIGN KEY (Dialect_dialect_id) REFERENCES Dialect (dialect_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Quality (
  quality_id INT NOT NULL AUTO_INCREMENT,
  quality_name VARCHAR(45) NOT NULL,
  PRIMARY KEY (quality_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Quality_has_Meeting (
  Quality_quality_id INT NOT NULL,
  Meeting_meeting_id INT NOT NULL,
  PRIMARY KEY (Quality_quality_id,Meeting_meeting_id),
	CONSTRAINT fk_Quality_has_Meeting_Quality FOREIGN KEY (Quality_quality_id) REFERENCES Quality (quality_id) ON DELETE RESTRICT ON UPDATE CASCADE,
	CONSTRAINT fk_Quality_has_Meeting_Meeting FOREIGN KEY (Meeting_meeting_id) REFERENCES Meeting (meeting_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE Village (
  village_id INT NOT NULL AUTO_INCREMENT,
  village_name VARCHAR(45) NOT NULL,
  Province_province_id INT NOT NULL,
  PRIMARY KEY (village_id,Province_province_id),
  KEY fk_Village_Province (Province_province_id),
	CONSTRAINT fk_Village_Province FOREIGN KEY (Province_province_id) REFERENCES Province (province_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
