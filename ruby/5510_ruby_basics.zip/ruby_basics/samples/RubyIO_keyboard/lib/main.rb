
puts "----Type something in the Output window and press Enter key." 
puts "    Make sure you click in the Output window first."
what_you_typed_in = gets

puts "----Display what has been typed in."
puts "What you have typed in: " + what_you_typed_in