array = [3, 2, 6, 7, 5]

puts "----Display array in sorted order - array is not changed, however"
print array.sort, "\n"
print array, "\n"

puts "----Display array in sorted order with ! - array is changed"
print array.sort!, "\n"
print array, "\n"
