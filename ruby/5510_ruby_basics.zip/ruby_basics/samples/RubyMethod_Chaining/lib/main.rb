array = [3, 2, 2, 3, 7, 5]

puts "----Example of method chaining: array.uniq"
puts array.uniq
puts "----Example of method chaining: array.uniq.sort"
puts array.uniq.sort
puts "----Example of method chaining: array.uniq.sort.reverse"
puts array.uniq.sort.reverse
puts "----Example of method chaining: array.sort.reverse"
puts array.sort.reverse
