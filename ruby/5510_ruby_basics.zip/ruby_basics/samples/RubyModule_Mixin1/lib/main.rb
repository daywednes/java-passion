puts "----Create Aeronautics module with launch method"
module Aeronautics
  def launch()
    "3, 2, 1 Blastoff!"
  end  
end 

puts "----Create RocketShip class which includes Aeronautics module"
class RocketShip
  include Aeronautics
end

puts "----Create RocketShip object and call launch method from the Aeronautics module"
r = RocketShip.new
puts r.launch	