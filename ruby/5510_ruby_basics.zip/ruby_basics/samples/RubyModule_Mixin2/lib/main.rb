puts "----Create Stringify module with stringify method"
module Stringify
  def stringify
    if @value == 1
      "One"
    elsif @value == 2
      "Two"
    elsif @value == 3
      "Three"
    end
  end
end

puts "----Create MyNumber class which includes Stringify module"
class MyNumber 
  include Stringify
  def initialize(value)
    @value = value
  end
end

puts "----Create MyNumber object and call stringify method from the Stringify module"
my_number = MyNumber.new(2)
puts my_number.stringify  # Should print Two
