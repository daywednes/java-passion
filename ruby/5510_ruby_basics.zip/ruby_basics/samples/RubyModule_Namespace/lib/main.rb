# This code shows that the Module is used to provide
# namespace.

puts "----Define People module with Stalk class"
module People
  class Stalk  
    def about
      "I am a person."
    end
  end
end

puts "----Define Plants module with Stalk class"
module Plants
  class Stalk
    def about
      "I am a plant."
    end
  end 
end

puts "----Create an instance of Stalk class of People Module"
a = People::Stalk.new

puts "----Call about method of the Stalk class of People Module"
puts a.about

puts "----Create an instance of Stalk class of Plants Module"
b = Plants::Stalk.new

puts "----Call about method of the Stalk class of Plants Module"
puts b.about




