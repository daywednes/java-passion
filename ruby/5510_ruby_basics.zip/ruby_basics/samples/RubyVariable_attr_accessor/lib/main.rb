# Quoted from http://railstips.org/2006/11/18/class-and-instance-variables-in-ruby
# 

