
a = 1
puts a.class

a = "hello"
puts a.class

a = /^Hello.*/
puts a.class

a = {1 => "foo", 2 => "bar"}
puts a.class

a = [1, "ein", a]
puts a.class
