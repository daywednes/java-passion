puts 10
puts 10.class       #=> Fixnum

puts 0.5
puts 0.5.class      #=> Float

puts 2e-4
puts 2e-4.class     #=> Float

puts 0xEFEF
puts 0xEFEF.class   #=> Fixnum

puts 010
puts 010.class      #=> Fixnum