
%w(Live your life with passion!).each do |name|
  puts name
end

%q(Live your life with passion!).each do |name|
  puts name
end

