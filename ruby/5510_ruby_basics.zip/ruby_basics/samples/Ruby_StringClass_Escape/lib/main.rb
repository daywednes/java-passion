puts "Hello\t\tworld"
 
puts "Hello\b\b\b\b\bGoodbye world"
 
puts "Hello\rStart over world"
 
puts "1. Hello\n2. World"
