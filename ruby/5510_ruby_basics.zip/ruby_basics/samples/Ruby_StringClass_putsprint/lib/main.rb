puts "Say", "hello", "to", "the", "world"

print "Say", "hello", "to", "the", "world", "\n"

print "Say"
print "hello"
print "to"
print "the"
print "world"
print "\n"

