class Logger
  if ENV['DEBUG']
    def log(msg)
      STDERR.puts "LOG: " + msg
    end
  else
    def log(msg)
    end
  end
end