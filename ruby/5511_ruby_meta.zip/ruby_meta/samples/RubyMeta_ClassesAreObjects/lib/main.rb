class Person
 
  puts self
  
  def self.my_class_method
    puts "This is my own class method"
  end
 
end