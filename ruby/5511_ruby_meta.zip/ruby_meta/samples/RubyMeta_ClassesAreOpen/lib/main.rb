class String
  def encrypt
    tr "a-z","b-za"
  end
end

puts "cat"
puts "cat".encrypt