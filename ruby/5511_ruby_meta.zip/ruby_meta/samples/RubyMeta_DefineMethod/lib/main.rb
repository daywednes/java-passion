class Love
  define_method(:my_hello) do |arg1, arg2|
    puts "#{arg1} loves #{arg2}"
  end
end

love = Love.new

puts "----Call a method that is defined via define_method"
love.my_hello("Sang Shin", "Young Shin")
