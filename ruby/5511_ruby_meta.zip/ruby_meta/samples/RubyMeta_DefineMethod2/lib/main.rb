
puts "----Get a method name from a user.  Type something in the Output window and press Enter."
$my_method = gets

puts "----Define Love class which has define_method"
class Love
  define_method $my_method.intern do |arg1, arg2|
    puts "#{$my_method} method is being invoked"
    puts "#{arg1} loves #{arg2}"
  end
end

puts "----Create an instance of Love class"
love = Love.new

puts "----Invoke a method that was dynamically defined"
love.send($my_method, "Daniel", "Yina")