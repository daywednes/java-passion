
# The Duck class
class Duck
  def quack
    puts "Duck is quacking!"
  end 
end

# The Mallard class
class Mallard
  def quack
    puts "Mallard is quacking!"
  end 
end

# If it quacks like a duck, it must be duck
def quack_em(ducks)
  ducks.each do |duck|
    if duck.respond_to? :quack
       duck.quack
    end
  end
end 

birds = [Duck.new, Mallard.new, Object.new]

puts "----Call quack method for each item of the birds array. Only Duck and Mallard should be quacking."
quack_em(birds)
