class A
end

class B < A
end

a = A.new
b = B.new

puts "----Exercise instance_of? and kind_of? methods among object instances"
puts a.instance_of?(A)
puts b.instance_of?(A)
puts b.kind_of?(A)

puts "----Exercise instance_of? and kind_of? methods for a class"
puts A.instance_of?(Class)
puts A.kind_of?(Class)

puts "----Display class information"
puts a.class
puts a.class.class