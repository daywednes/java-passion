some_string = 'http://google.com'

puts "----Print the object's class, methods, superclass and ancestors (mixins and superclasses)"
p some_string.class
p some_string.methods
p some_string.class.superclass
p some_string.class.ancestors

puts "----Print the methods of the String class"
p String.private_instance_methods(false)
p String.public_instance_methods(false)

puts "----Pass true to recurse into parent classes"
p String.public_instance_methods(true)

puts "----Call instance methods with send()"
p "Random text".send(:length) # 11
p -23.send(:succ) # -22

puts "----Use Method objects and call()"
length_method = "Random text".method(:length)
p length_method.call # 11

puts "----Another way, using eval()"
length_method = %q{"Random text".length}
p eval length_method