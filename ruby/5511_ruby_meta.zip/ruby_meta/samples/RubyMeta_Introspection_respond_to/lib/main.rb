# Introspection example

puts "----Display all the methods of Object class"
puts Object.methods.sort

puts "----Check if Object class has name method"
puts Object.respond_to?(:name)             #=> true

puts "----Check if Object class has send method"
puts Object.respond_to?(:send)             #=> true

puts "----Check if Object class has does_not_exist method"
puts Object.respond_to?(:does_not_exist)   #=> false
