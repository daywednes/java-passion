# Introspection example

puts "----Define Hello class"
class Hello
  
  def myhellomethod(name)
  end
  
end

puts "----Check if Hello object has a method called myhellomethod"
hello_instance = Hello.new
puts hello_instance.respond_to?(:myhellomethod) 

puts "----Check if Hello object has a method called xyz"
puts hello_instance.respond_to?(:xyz)





