
class Dummy  
  def method_missing(m, *args)  
    puts "There's no method called #{m} here -- so method_missing method is called." 
    puts "   with arguments #{args}"    
  end  
end  

puts "----Call a method that does not exist in the Dummy class and observe that the method_missing is called."
dummy = Dummy.new
dummy.a_method_that_does_not_exist
dummy.a_method_that_does_not_exist(3)
dummy.a_method_that_does_not_exist(3, " Sang Shin ", Time.now)