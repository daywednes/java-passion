# When you send a message to an object, the object executes the first method 
# it finds on its method lookup path with the same name as the message. If it 
# fails to find any such method, it raises a NoMethodError exception - unless 
# you have provided the object with a method called method_missing. The 
# method_missing method is passed the symbol of the nonexistent method, and 
# any arguments that were passed in.

class Dummy 
end  

puts "----Call a method that does not exist in the Dummy class and expect NoMethodError exception."
dummy = Dummy.new
dummy.a_method_that_does_not_exist