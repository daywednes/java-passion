class Finder  
  def find(name)  
    puts "find(#{name}) is called"
  end  
  
  def method_missing(name, *args)
    if /^find_(.*)/ =~ name.to_s
      return find($1)
    end
    super
  end
end

puts "----Call a method that does not exist in the Finder class and observe that the method_missing is called."
f = Finder.new
f.find("Something")
f.find_by_last_name("Shin")
f.find_by_title("Technology Architect")
