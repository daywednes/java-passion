# Define Proxy class
class Proxy
  def initialize(object)
    @object = object
  end
  
  def method_missing(symbol, *args)
    # Call a method whose name is the value of symbol parameter
    @object.send(symbol, *args)
  end
end

puts "----Create an array object."
object = ["a", "b", "c"]

puts "----Create a Proxy object with instance variable @object is set with array object"
proxy = Proxy.new(object)

puts "----Call first method of the Proxy object, which has not been defined before. So the
          method_missing(..) method is called with the symbol set with first. Within the
          method_missing(..) method, the @object is set to the array object and the symbol 
          is set to first.  So it is the same thing as calling first method of the array
          object.  So you will see a as a result."
puts proxy.first

puts "----Call last method, which has not been defined before"
puts proxy.last

puts "----Create a String object"
object2 = String.new("Ruby on Rails Programming with Passion!")

puts "----Create a Proxy object with instance variable @object is set with array object"
proxy2 = Proxy.new(object2)

puts "----Call upcase method of String class"
puts proxy2.upcase

puts "----Call swapcase method of String class"
puts proxy2.swapcase




