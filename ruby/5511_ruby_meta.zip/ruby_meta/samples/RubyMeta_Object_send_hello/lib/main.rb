class Klass
  def hello(*args)
    "Hello " + args.join(' ')
  end
end

k = Klass.new

# The following four statements are equivalent
puts k.hello("gentle", "readers")         #=> "Hello gentle readers"
puts k.hello "gentle", "readers"          #=> "Hello gentle readers"
puts k.send(:hello, "gentle", "readers")  #=> "Hello gentle readers"
puts k.send :hello, "gentle", "readers"   #=> "Hello gentle readers"