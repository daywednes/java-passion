class Hello

  # Constructor - invoked by Hello.new
  def initialize(greeting)
    # Instance variables start with @
    @greeting = greeting
  end
  
  def my_hello(name)
    @completegreeting = "#{@greeting} #{name}"
  end
  
end

hello_instance = Hello.new("Hello")

# The following statements are equivalent
puts hello_instance.my_hello("Boston!")
puts hello_instance.my_hello "Boston!"
puts hello_instance.send(:my_hello, "Boston!")
puts hello_instance.send :my_hello, "Boston!"
