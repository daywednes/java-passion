puts "----Define Hello class"
class Hello

  # Constructor - invoked by Hello.new
  def initialize(greeting)
    # Instance variables start with @
    @greeting = greeting
  end
  
  def my_hello_method1(name)
    @completegreeting = "#{@greeting}1 #{name}"
  end
  
  def my_hello_method2(name)
    @completegreeting = "#{@greeting}2 #{name}"
  end
  
  def my_hello_method3(name)
    @completegreeting = "#{@greeting}3 #{name}"
  end
  
end

puts "----Create an object instance of Hello class"
hello_instance = Hello.new("Hello")

# Simulate the set of methods you want to call during runtime
methods_array = ["my_hello_method1", "my_hello_method2", "my_hello_method3"]

puts "----Call a method using send passing name of a method as a parameter"
methods_array.each do |x|
  puts hello_instance.send(x, "Boston")
end
