# The following statements are equivalent
puts 2+3
puts 2+(3)
puts 2.send(:+, 3)
puts 2.send :+, 3

# The following statements are equivalent
puts 2*3
puts 2*(3)
puts 2.send(:*, 3)
puts 2.send :*, 3