class Klass
  def hello(*args)
    "Hello " + args.join(' ')
  end
end

k = Klass.new

puts "----Check if Klass method responds to hello method"
puts k.respond_to?(:hello)               #=> true

puts "----Check if Klass method responds to non_existent method"
puts k.respond_to?(:non_existent)        #=> false

