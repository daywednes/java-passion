puts "----Define a method that returns Proc object as a return value"
def gen_times(factor)     
  Proc.new {|n| n*factor }   
end

puts "----Assign Proc object to local variables"
times3 = gen_times(3)               # Block has factor variable set to 3
times5 = gen_times(5)               # Block has factor variable set to 5

puts "----Execute the code block passing a parameter"
puts times3.call(12)                     #=> 36 because 12 * 3 (factor) = 36
puts times5.call(5)                      #=> 25 because 5 * 5 (factor) = 25
puts times3.call(times5.call(4))         #=> 60 because (4 * 5  )  * 3 (factor) = 60
