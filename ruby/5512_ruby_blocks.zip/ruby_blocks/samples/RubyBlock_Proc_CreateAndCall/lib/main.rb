# Proc objects are blocks of code that have been converted 
# to callable objects.

puts "----Create a Proc object and call it"
say_hi = Proc.new { puts "Hello Sydney" }
say_hi.call

puts "----Display the class of Proc object"
puts say_hi.class

puts "----Create another Proc object and call it"
Proc.new { puts "Hello Boston"}.call
