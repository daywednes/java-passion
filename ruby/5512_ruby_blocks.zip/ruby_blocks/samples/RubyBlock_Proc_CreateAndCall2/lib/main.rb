puts "----Define a method that returns a Proc object"
def my_hello
  return proc { |x, y| puts "Hello #{x} #{y}" }
end

puts "----Execute the block"
my_variable = my_hello
my_variable.call("Young Shin", Time.now)