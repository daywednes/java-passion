# 
# Block can be represented in two different formats
#
 
puts "----First format of code block containing code fragment between { and }"
[1, 2, 3].each { |n| puts "Number #{n}" }

puts "----Second format of code block containing code fragment between do and end"
[1, 2, 3].each do |n|
  puts "Number #{n}"
end