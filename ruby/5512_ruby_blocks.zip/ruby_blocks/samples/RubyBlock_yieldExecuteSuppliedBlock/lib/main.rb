# 
# The goal of this exercise is to see how
# a supplied block is executed through "yield"
# keyword.
#
 
puts "----Define MyClass which invokes yield"
class MyClass
  def command()
    puts "This is a message from the command method of MyClass "
    
    # yield will execute the attached block to the method
    yield()	
  end        
end

puts "----Create object instance of MyClass"
m = MyClass.new

puts "----Call command method of the MyClass passing a block"
m.command {puts "Hello World!"}

puts "----Call command method of the MyClass passing a block"
m.command {puts "Life is good!"}

puts "----Call command method of the MyClass passing a block"
# Sometimes you will see blocks that seem 'nested', for example, here
# the 'command' yields to a block, who calls method 'each', who yields
# (again!) to an inner block"
m.command do
  [1, 2, 3].each do |n|
    puts "Number #{n}"
  end
end

puts "----Call command method of the MyClass passing a block"
m.command { [1, 2, 3].each { |n| puts "Number #{n}" } }
