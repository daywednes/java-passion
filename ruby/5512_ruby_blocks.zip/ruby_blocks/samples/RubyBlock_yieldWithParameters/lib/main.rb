puts "----Define MyClass that yields the passed code block"
class MyClass
  
  def command1()
    # yield will execute the supplied block
    yield(Time.now)	
  end        
  
  def command2(my_parameter)
    puts "**Star command says: "
    
    # yield will execute the supplied block
    yield(my_parameter)	
  end        
end

puts "----Create an object instance of MyClass"
m = MyClass.new

puts "----Call command1 method of the MyClass"
m.command1() {|x| puts "Current time is #{x}"}

puts "----Call command2 method of the MyClass"
m.command2(1) {|x| puts "Hello World! is called with number #{x}" }
m.command2(2) {|i| puts "Number #{i} is passed."}
m.command2(3) {|i| puts "Number #{i} is passed."}
m.command2("something") {|x| puts x}
m.command2("something") {|t| puts t}



