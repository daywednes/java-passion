puts "---Define a method called testyield"
def testyield
  yield(1000, "Sang Shin")
  yield("Current time is", Time.now)
end

puts "----Call testyield method"
testyield { |arg1, arg2| puts "#{arg1} #{arg2}" }

