# Quoted from "Programming Ruby: The Pragmatic Programmer's Guide"
# http://www.ruby-doc.org/docs/ProgrammingRuby/html/tut_containers.html
# 
# The interesting thing about Proc object is that it's more than just a 
# chunk of code. 
# 
# Associated with a block (and hence a Proc object) is all the context 
# in which the block was defined: the value of self, and the methods, 
# variables, and constants in scope. Part of the magic of Ruby is 
# that the block can still use all this original scope information 
# even if the environment in which it was defined would otherwise 
# have disappeared. In other languages, this facility is called a 
# closure.

# Let's look at a contrived example. This example uses the method proc, 
# which converts a block to a Proc object.

# Define a method that returns a Proc object
def ntimes(a_thing)
  return proc { |n| a_thing * n }
end

puts "----Create a Proc object by calling ntimes method. "
# The a_thing is set to value 23 in a block.  
p1 = ntimes(23)

# Note that ntimes() method has returned.  The block still
# has access to a_thing variable.

puts "----Execute the block"
# Now execute the block.  Note that the a_thing is still set to
# 23 and the code in the block can access it, so the results is set 69 and 92
puts p1.call(3) 	# 	69
puts p1.call(4) 	# 	92

puts "----Create a Proc object by calling ntimes method. "
# The a_thing is now set to value "Hello " in a block.  Even if ntimes method is
# finished, the a_thing variable in the block still contains "Hello ".
p2 = ntimes("Hello ")

puts "----Execute the block"
# Now execute the block.  Note that the a_thing is still set to
# "Hello " and the code in the block can access it, so the results is 
# "Hello Hello Hello "
puts p2.call(3) 	# 	"Hello Hello Hello "