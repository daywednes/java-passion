# Blocks are like closures, because they can refer to variables from 
# their defining context, for example, the block can access x.

def thrice
    yield
    yield
    yield
end

puts "---- x variable is part of defining context, it is set to 5"
x = 5

puts "---- Call a method with a block, the block has access to x variable of defining context"
thrice {x += 1}

puts "value of outer x after: #{x}" #=> 8

