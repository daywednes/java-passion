# A block only refers to *existing* variables in the outer context; if 
# they don't exist in the outer, a block won't create them there:

def thrice
    yield
    yield
    yield
end

thrice do # note that {...} and do...end are completely equivalent
    y = 10
    puts "Is y defined inside the block where it is first set?"
    puts "Yes." if defined? y
end

puts "Is y defined in the outer context after being set in the block?"
puts "No!" unless defined? y