# OK, so blocks seem to be like closures: they are closed with respect to 
# variables defined in the context where they were created, regardless of 
# the context in which they're called.
# 
# But they're not quite closures as we've been using them, because we have 
# no way to pass them around: "yield" can *only* refer to the block passed 
# to the method it's in.
#
# We can pass a block on down the chain, however, using &:

def thrice
    yield
    yield
    yield
end

def six_times(&block)
    thrice(&block)
    thrice(&block)
end

x = 4
six_times { x += 10 }
puts "value of x after: #{x}"