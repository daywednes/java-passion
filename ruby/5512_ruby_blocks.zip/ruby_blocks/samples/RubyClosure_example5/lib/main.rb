# So do we have closures? Not quite! We can't hold on to a &block and call 
# it later at an arbitrary time; it doesn't work. This, for example, will 
# not compile:
#
# def save_block_for_later(&block)
#     saved = &block;
# end
#
# But we *can* pass it around if we use drop the &, and use 
# block.call(...) instead of yield:

def save_for_later(&b)
    @saved = b  # Note: no ampersand! This turns a block into a closure of sorts.
end

save_for_later { puts "Hello!" }
puts "Deferred execution of a block:"
@saved.call
@saved.call