# A proc_object in Ruby is a chunk of code that can be called like 
# a function. The proc_object automatically carries with it the 
# bindings (context or scope information) from the code location 
# where it was created. 
# 
# In the example below, the proc_object returns the value of a in the 
# binding where the proc_object was defined (a == 33), NOT the binding 
# where the proc_object was called (a == 44).

# This combination of code proc_object and binding is called a 
# closure. 

a = 33
proc_object = lambda { a }

def redefine_a(proc_object_arg)
  a = 44
  proc_object_arg.call
end

puts redefine_a(proc_object)      # => 33