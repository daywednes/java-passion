def paragraph
  topic =  "A good paragraph should have a topic sentence, a body, and a conclusion. "
  conclusion = "This generic paragraph has all three parts."

  puts topic 
  yield(topic, conclusion) 
  puts conclusion
end


t = ""
c = ""
paragraph do |topic, conclusion| 
  puts "This is the body of the paragraph. "
  t = topic
  c = conclusion
end

puts "The topic sentence was: '#{t}'"
puts "The conclusion was: '#{c}'"