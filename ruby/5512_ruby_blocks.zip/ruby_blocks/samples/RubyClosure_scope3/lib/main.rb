def paragraph
  topic =  "A good paragraph should have a topic sentence."      
  conclusion = "This generic paragraph has a topic, body, and conclusion."

  puts topic 
  yield(topic, conclusion) 
  puts conclusion
end


t = ""
c = ""
paragraph do |topic, conclusion|     # these are local in scope
  puts "This is the body of the paragraph. "
  t = topic
  c = conclusion
end

puts "----Compile error expected since topic is not accessible -------" 
puts "The topic sentence was: '#{topic}'"
puts "The conclusion was: '#{conclusion}'"