# From http://www.rubyist.net/~slagell/ruby/singletonmethods.html

# In this example, test1 and test2 belong to same class, but
# test2 has been given a redefined size method and so they behave
# differently. A method given only to a single object is called
# a singleton method.

class SingletonTest
  def size
    25
  end
end

test1 = SingletonTest.new
test2 = SingletonTest.new

def test2.size
  10
end

puts "----test1.size = #{test1.size}"  # 25
puts "----test2.size = #{test2.size}"  # 10




