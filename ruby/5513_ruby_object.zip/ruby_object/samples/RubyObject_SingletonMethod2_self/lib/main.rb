class C 
end

# Create a new object foo
foo = C.new

# Singleton methods are defined for a particular object. They can be called 
# by only the object. When a singleton method is executed, self is the 
# object that owns the method.
def foo.bar
  puts self
end

foo.bar

# This should display the same object displayed above
puts foo



