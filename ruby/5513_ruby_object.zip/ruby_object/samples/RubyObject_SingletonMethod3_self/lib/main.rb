foo = Object.new

# Singleton methods are defined for a particular object. They can be called 
# by only the object . When a singleton method is executed, self is the 
# object that owns the method.
def foo.bar
  puts self
end

# This is another way a singleton method can be defined
class << foo
  def bar2
    puts self
  end
end

foo.bar         #<Object:0x10ffb38>
foo.bar2        #<Object:0x10ffb38>



