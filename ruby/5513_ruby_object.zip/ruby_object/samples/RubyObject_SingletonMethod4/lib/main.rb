class C 
end

foo = C.new

# Singleton methods are defined for a particular object. They can be called 
# by only the object . When a singleton method is executed, self is the 
# object that owns the method.
def foo.bar
  puts "from foo.bar"
end

# This is another way a singleton method can be defined
class << foo
  def bar2
    puts "from foo.bar2"
  end
end

foo.bar         #<Object:0x15356d5>
foo.bar2        #<Object:0x15356d5>

foo2 = C.new
#foo2.bar        # Compile error - undefined method - expected
#foo2.bar2       # Compile error - undefined method - expected



