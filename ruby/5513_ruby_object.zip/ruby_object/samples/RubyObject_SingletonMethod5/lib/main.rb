# Based on Ola Bini's blog on Singleton class
# http://ola-bini.blogspot.com/2006/09/ruby-singleton-class.html

def String.hello1
  puts "hello1"
end

String.hello1  # hello1

class String
  def self.hello2
    puts "hello2"
  end
end

String.hello2  # hello2

# This is the preferred idiom in Ruby, and it also makes explicit the 
# singleton class. What happens is that, since the code inside the "class 
# String"-declaration is executed in the scope of the String instance 
# of Class, we can get at the singleton class with the same syntax we 
# used to define foo.bar earlier. So, the definition of hello will happen 
# inside the singleton class for String. 
class String
  class << self
    def hello3
      puts "hello3"
    end
  end
end

String.hello3  # hello3

# This also explain the common idiom for getting the singleton class:
# There is no other good way to get it, so we extract the self from 
# inside a singleton class definition.
 class << self
   self
 end
 
