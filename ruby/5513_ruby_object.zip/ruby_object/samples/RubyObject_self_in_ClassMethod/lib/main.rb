class MyClass

  puts "---- Define a class method"
  def self.my_class_method

    puts "---- What is the object instance receiving this class method?"
    puts self             # MyClass

    puts "---- Verify that MyClass class is an object instance of Class class."
    puts self.class       # Class

    puts "---- What is the parent class of MyClass class?"
    puts self.superclass  # Object

    puts "---- What is the parent class of Class class?"
    puts self.class.superclass  # Module

    puts "---- What is the parent class of Module class?"
    puts self.class.superclass.superclass  # Object
    
  end

end

MyClass.my_class_method  


