class MyClass
  def my_instance_method

    puts "---- What is the object instance invoking (or receiving) this instance method?"
    puts self                         # <MyClass:0x1758500>
    
    puts "---- What is the class of this object instance?"
    puts self.class                   # MyClass
    
    puts "---- What is the parent class of the class of this object instance?"
    puts self.class.superclass        # Object
    
    puts "---- What is the class of the Object class?"
    puts self.class.superclass.class  # Class

  end
end

my_class = MyClass.new
my_class.my_instance_method    #<MyClass:0xae3364>


