puts "---- What is the object instance receiving this puts method?"
puts self               # main

puts "---- What is the class of this object instance?"
puts self.class

# Top level methods are 'private instance methods of the Object class.
# Because top-level methods are private, you cannot call the with an 
# explicit receiver; you can only call them with the default receiver, 
# self. 
def my_top_level_instance_method
  puts "---- What is the object receiving this instance method?"
  puts self
end

my_top_level_instance_method

def self.my_top_level_class_method
  puts "---- What is the object receiving this class method?"
  puts self
end

my_top_level_class_method

