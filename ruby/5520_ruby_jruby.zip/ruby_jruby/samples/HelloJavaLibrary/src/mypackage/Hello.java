package mypackage;

public class Hello {
    
    public String sayHello(String name){
        return "Hello " + name + "!";
    }

}
