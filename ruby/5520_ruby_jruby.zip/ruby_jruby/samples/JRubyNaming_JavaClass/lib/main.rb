# This is the 'magical Java include line'.
include Java
   
# Java class naming convention in JRuby
#   Java: org.foo.department.Widget
#   Ruby: Java::OrgFooDepartment::Widget
#   
#frame = javax.swing.JFrame.new("Passion!")           # Creating a Java JFrame.
frame = Java::JavaxSwing::JFrame.new("Passion!")      # Same as above
#label = javax.swing.JLabel.new("Hello World!")       # Creating a Java JLabel
label = Java::JavaxSwing::JLabel.new("Hello World!")  # Same as above
   
# We can transparently call Java methods on Java objects, just as if they were 
# defined in Ruby.
frame.getContentPane.add(label)  # Invoking the Java method 'getContentPane'.
frame.setDefaultCloseOperation(javax.swing.JFrame::EXIT_ON_CLOSE)
frame.pack
frame.setVisible(true)
