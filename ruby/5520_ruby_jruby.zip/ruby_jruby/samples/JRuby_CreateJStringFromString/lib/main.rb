include Java

puts "----Expose Java's String class as JString"
include_class("java.lang.String"){|pkg, name| "J" + name}

puts "----Create object instance from JString"
s = JString.new("This is JString from Java's String class")
puts s

