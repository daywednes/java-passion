include Java

puts "----Create a module from Java package"
module JavaLang
  include_package "java.lang"
end

puts "----Create a string"
s = JavaLang::String.new("This is my string from java.lang package")
puts s