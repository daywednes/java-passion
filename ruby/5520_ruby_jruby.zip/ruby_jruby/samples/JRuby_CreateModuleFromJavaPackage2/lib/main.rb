include Java

puts "----Create a Ruby Module from Java package"
module JavaLang
    include_package "java.lang"
end

puts "----Get Java version information"
version = JavaLang::System.getProperties["java.runtime.version"]
puts version