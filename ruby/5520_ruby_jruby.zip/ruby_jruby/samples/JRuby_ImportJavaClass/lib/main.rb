# You have to include Java if you are using Java class
include Java

puts "----Import a Java class, java.lang.System"
import java.lang.System

puts "----Display Java version using java.lang.System Java class"
version = System.getProperties["java.runtime.version"]
puts "Java verion used is #{version}"


