require "java"

puts "----Create Java bytes from a Ruby string"
bytes = 'a string'.to_java_bytes

puts "----Create Java String from Java bytes"
string = String.from_java_bytes bytes
puts string