include Java

import java.util.ArrayList
import javax.swing.JFrame

list = ArrayList.new
frame = javax.swing.JFrame.new("Passion1!") 
list << frame
list << javax.swing.JFrame.new("Passion2!") 

list.each do |f| 
  f.set_size(200,200) 
  label = javax.swing.JLabel.new("My own label")
  f.getContentPane.add(label)  # Invoking the Java method 'getContentPane'.
  f.setDefaultCloseOperation(javax.swing.JFrame::EXIT_ON_CLOSE)
  f.pack
  f.setVisible(true)
end