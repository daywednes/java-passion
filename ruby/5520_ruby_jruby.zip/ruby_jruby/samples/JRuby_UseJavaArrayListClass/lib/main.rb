include Java

# If the class you are including is from
# com, org, java, or javax package,
# you don't need quotes.
include_class java.util.ArrayList

puts "----Create an object from ArrayList Java class"
list = ArrayList.new

puts "----Add entries to the ArrayList"
list.add "foo"
list.add "Bar"
list.add "baz"

puts "----Add an entry using an index"
list.add(2, "Sang Shin")

puts "----Display ArrayList"
list.each do |v|
  puts "value: #{v}"
end

puts "----Display an entry using an index"
puts list.get(2)

