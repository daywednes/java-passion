# This is the 'magical Java include line'.
include Java
   
# With the 'include Java' above, we can now refer to things that are part of the
# standard Java platform via their full paths.
frame = javax.swing.JFrame.new("Passion!") # Creating a Java JFrame.
label = javax.swing.JLabel.new("Hello World!")
   
# We can transparently call Java methods on Java objects, just as if they were 
# defined in Ruby.
frame.getContentPane.add(label)  # Invoking the Java method 'getContentPane'.
frame.setDefaultCloseOperation(javax.swing.JFrame::EXIT_ON_CLOSE)
frame.pack
frame.setVisible(true)
