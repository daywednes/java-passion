# Code is orginally written by Daniel Spiewak
# http://www.codecommit.com/blog/java/rapid-prototyping-with-jruby

include Java
 
JFrame = javax.swing.JFrame
JComponent = javax.swing.JComponent
GradientPaint = java.awt.GradientPaint
Color = java.awt.Color
 
class CustomComponent < JComponent
  
  def initialize
    @paint = GradientPaint.new(0, 0, Color::RED, 0, 200, Color::WHITE)
  end
 
  def paintComponent(g)
    g.setPaint @paint
    g.fillRect(0, 0, 200, 200)
  end
  
end

# Create JFrame
frame = JFrame.new 'Test Frame'
frame.setSize(200, 200)

# Create CustomComponent
@comp = CustomComponent.new

# Add custom component to the frame
frame.add @comp
frame.defaultCloseOperation = JFrame::EXIT_ON_CLOSE
frame.visible = true