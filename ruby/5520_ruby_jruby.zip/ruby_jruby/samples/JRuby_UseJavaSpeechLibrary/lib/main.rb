include Java

# If the class you are including is from
# com, org, java, or javax package,
# you don't need quotes.
import com.sun.speech.freetts.Voice
import com.sun.speech.freetts.VoiceManager

puts "----Allocate a voice"
voice = VoiceManager.getInstance.getVoice('kevin')
voice.allocate    
  
puts "----Speak out"
speech1 = "I love you!"
voice.speak(speech1)
voice.speak "Life is worth living with Passion!"

