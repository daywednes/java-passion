include Java

include_class 'java.util.TreeSet'

puts "----Create an object from TreeSet Java class"
set = TreeSet.new

puts "----Add entries to the TreeSet"
set.add "foo"
set.add "Bar"
set.add "baz"

puts "----Display TreeSet"
set.each do |v|
  puts "value: #{v}"
end

