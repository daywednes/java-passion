# 
# To change this template, choose Tools | Templates
# and open the template in the editor.
 

include Java

include_class 'mypackage.Hello'

puts "----Create an object from Hello Java class"
h = Hello.new

puts "----Invoke a method of from Hello object"
s = h.sayHello("Message from Hello Java Class!")
puts s
