SomeObject = Java::mypackage.SomeObject
object = SomeObject.new
object.numbers = [1,2,3]