include Java

my_java_string = ["a","b","c","d"].to_java(:string)
puts my_java_string
