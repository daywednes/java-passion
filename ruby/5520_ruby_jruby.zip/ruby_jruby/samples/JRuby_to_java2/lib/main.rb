include Java

class Example
end

a = [Example.new]

example = a[0]
p example.kind_of?(Example)     #=> true
p example.class     #=> Example

example = a.to_java[0]
p example.kind_of?(Example)     #=> false
p example.class     #=> Java::OrgJruby::RubyObject 