class HelloController < ApplicationController
  def index
    say_hello  # Call say_hello action method
    render :action=>'say_hello'  # Render a template from the say_hello action method
  end
  def say_hello
    @hello = Message.new(:greeting => "Hello World!")
  end
end
