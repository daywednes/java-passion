require 'test_helper'

class HelloHelperTest < ActionView::TestCase
end
