# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_helloname_session',
  :secret      => 'dea4de977403ab86b7c3fb3f5c2f87f2b87b75fc8d8f1ba1794d4f56a3667e526f5c1cb452013baa2dfacb72a06ac87774649d031fb1c778c91279946fa47839'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
