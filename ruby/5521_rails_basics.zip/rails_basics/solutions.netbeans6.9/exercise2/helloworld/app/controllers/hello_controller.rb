class HelloController < ApplicationController
  def index
    say_hello  # Call say_hello action method
    render :action=>'say_hello'  # Render a template from the say_hello action method
  end
  def say_hello
    @hello = Message.new(:greeting => "Hello World!")
    @hello.name = "Sang Shin"

    # As of Rails 2.3.2 logging the params to hello
    logger.debug("PARAMS: #{@hello.inspect}")
    logger.debug(params.inspect)
  end
end
