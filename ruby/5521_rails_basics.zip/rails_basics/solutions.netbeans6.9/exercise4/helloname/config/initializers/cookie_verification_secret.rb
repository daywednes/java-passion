# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '43a6d8bd081971599391ce6f5ba766aa648555f2580c207a7a273fd0b9f9f9611935457520dddd0d8da278d23e23d1fa442cafa6721376975465d412f3ba10f3';
