# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_ActiveRecord_Creation_session',
  :secret      => '67fb8bdb21a4a9f7f1027f0a4d6613ad323ba29ea341fad4eef593c527eb823af043935699f03857fe5be86ae2dedc0696a65e4d5de153331727684b6e924aca'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
