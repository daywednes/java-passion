class User < ActiveRecord::Base

  # Validations on name field
  validates_uniqueness_of :name,
    :message=>"The name is not unique"

  # Validateions on hobby field
  validates_inclusion_of  :hobby,
    :in=>%w{swimming ballet tennis walking golf running},
    :message=>"This sport is not allowed!"

  # Validations on age field
  validates_numericality_of :age,
    :only_integer=>true,
    :message=>"is not a number"

  # Validation on the email field
  validates_format_of :email,
    :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/i,
    :on => :create,
    :message=>"Invalid email format"

end
