class RenameEmailField < ActiveRecord::Migration
  def self.up
    rename_column :users, :email, :email_addr
  end

  def self.down
    rename_column :users, :email_addr, :email
  end
end
