# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'c15e95d42d1c507ab6e8a9fd2e8dd5e2af57f0fcdf395f26ff2f8b5c75760b08181f951d4c834fed0d04870b0deb83d6188007858d3a269201e064d7c33f9a51';
