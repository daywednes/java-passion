class AddMoreData < ActiveRecord::Migration
  def self.up

    user = User.new(:name => "Tom", :hobby => "swimming", :age => 20)
    user.save

    user = User.new(:name => "Mary", :hobby => "golf", :age => 70)
    user.save

    user = User.new do |u|
      u.name = "YoungAh"
      u.hobby = "walking"
      u.age = 23
    end
    user.save

    user = User.new
    user.name = "Chul-Soo"
    user.hobby = "running"
    user.age = 67
    user.save

  end

  def self.down
    User.delete_all
  end
end
