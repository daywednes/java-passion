class CreateTestData < ActiveRecord::Migration
  def self.up
    down  # Delete all rows from the posts and comments tables

    post1 = Post.create(:id => 1, :title=> "First title", :body=> "This is the body of the first posting")

    comment = Comment.create(:id => 1, :comment=>"What a boring posting. Can you do better next time? - Sang Shin")
    post1.comments << comment
    comment = Comment.create(:id => 2, :comment=>"This is the 2nd comment to the first posting.")
    post1.comments << comment

    post2 = Post.create(:id => 2, :title=> "The 2nd posting", :body=> "Life is good!")
    comment = Comment.create(:id => 3, :comment=>"The 1st comment to the 2nd posting")
    post2.comments << comment
    comment = Comment.create(:id => 4, :comment=>"The 2nd comment to the 2nd posting")
    post2.comments << comment

    comment = Comment.create(:id => 5, :comment=>"My new comment to the first posting")
    post1.comments << comment
    comment = Comment.create(:id => 6, :comment=>"Another comment to the first posting")
    post1.comments << comment
  end

  def self.down
    Post.delete_all
    Comment.delete_all
  end
end
