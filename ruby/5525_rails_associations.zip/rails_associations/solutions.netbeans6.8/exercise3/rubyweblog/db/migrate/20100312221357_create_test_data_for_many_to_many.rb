class CreateTestDataForManyToMany < ActiveRecord::Migration
  def self.up
    down

    category1 = Category.create(:name => "art")
    category2 = Category.create(:name => "sport")
    category3 = Category.create(:name => "politics")

    post1 = Post.create(:title => "I like art and sport", :body => "some message")
    post2 = Post.create(:title => "I like sport", :body => "some message")
    post3 = Post.create(:title => "Politics sucks", :body => "some message")
    post4 = Post.create(:title => "George Bush sucks", :body => "some message")

    post1.categories << category1
    post1.categories << category2

    category3.posts << post3
    category3.posts << post4
  end

  def self.down
    Post.delete_all
    Category.delete_all
  end
end
