class Post < ActiveRecord::Base
  validates_presence_of :title, :body
  has_many :comments, :order => "comment DESC, created_at ASC",
    :dependent => :destroy
  #has_and_belongs_to_many :categories # foreign keys in the join table
  has_many :joins
  has_many :categories, :through => :joins
end
