# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_helloname_session',
  :secret      => 'c04502ee12cf31ba434e7200995e13c8b841002725b0ed9eb4deea19db6ee8e1bd0e0a974f3928b891255583c5c626efdb015c054fe83f4fac8492b5c996d2fe'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
