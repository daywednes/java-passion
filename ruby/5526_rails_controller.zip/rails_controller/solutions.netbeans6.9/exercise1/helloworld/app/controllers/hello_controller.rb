class HelloController < ApplicationController
  def index
    say_hello  # Call say_hello action method
    render :action=>'say_hello'  # Render a template from the say_hello action method
  end
  def say_hello
    #@hello = Message.new(:greeting => "Hello World!") # Comment this line out
    #@hello.name = "Sang Shin"                                           # Comment this line out
    @hello = Message.new(:greeting => params[:mygreeting])
    @hello.name = params[:myname]
    @my_controller_name = params[:controller]
    @my_action_name = params[:action]

    # As of Rails 2.3.2 logging the params to hello
    logger.debug("PARAMS: #{@hello.inspect}")
    logger.debug(params.inspect)
  end
  def say_goodbye
    @goodbye = Message.new(:greeting=>"Goodbye")
  end
end
