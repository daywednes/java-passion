class AddHobbyToUser < ActiveRecord::Migration
  def self.up
    add_column :users, :hobby, :string
  end

  def self.down
    remove_column :users, :hobby
  end
end
