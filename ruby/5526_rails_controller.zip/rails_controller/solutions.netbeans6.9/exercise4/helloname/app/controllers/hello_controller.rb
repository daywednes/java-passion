class HelloController < ApplicationController
  def respond
    @user = User.new(params[:user])
    #@user.save

    session[:age_added] ||= 0
    session[:age_added] += @user.age
    @total_age = session[:age_added]

    flash[:age_added] ||= 0
    flash[:age_added] = @user.age
    @flash_age = flash[:age_added]
  end

  def render_text
    respond
    render :text=>"The user's age is #{@user.age}"
  end

  def render_action1
    respond
    render :action=>:respond
  end

  def render_action2
    respond
    render :action=>'respond'
  end

  def render_template
    respond
    render :template=>'hello/respond.html.erb'
  end
end
