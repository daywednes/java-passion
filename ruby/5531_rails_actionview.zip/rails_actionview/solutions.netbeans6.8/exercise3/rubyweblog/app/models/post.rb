class Post < ActiveRecord::Base
  validates_presence_of :title, :body
  TITLE_SIZE = 30
  TITLE_MAX_LENGTH = 60
  BODY_ROWS = 5
  BODY_COLS = 40
end
