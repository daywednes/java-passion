# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'f1b2b9a9e8d23507d291186ce592e005bf168dc7550c3ecfaca9f6c7f0d60465af8f66e56a6bc16fb30390e3c4e4b691bb09b19589630b7b7a5d8c1d45f5537e';
