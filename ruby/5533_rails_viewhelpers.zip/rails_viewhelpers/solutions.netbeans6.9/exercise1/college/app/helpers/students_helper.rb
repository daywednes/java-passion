module StudentsHelper

  # builds nested array of country names and ids, for select box
  #
  def select_country_choices
    @countries.map { |country_row| [ country_row.name, country_row.id ] }
  end
end
