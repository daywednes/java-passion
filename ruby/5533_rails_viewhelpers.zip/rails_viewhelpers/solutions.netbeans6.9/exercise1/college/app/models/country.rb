class Country < ActiveRecord::Base
  has_many :students

  validates_presence_of :name

  # retrieve countries in alphabetical order
  def self.list_countries
    countries = Country.find(:all, :order => 'name ASC')
  end

end
