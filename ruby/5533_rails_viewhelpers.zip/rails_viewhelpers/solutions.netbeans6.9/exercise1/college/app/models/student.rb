class Student < ActiveRecord::Base
  belongs_to :country

    # validate name
  validates_presence_of   :name
  validates_uniqueness_of :name

  # validate age
  validates_presence_of     :age
  validates_numericality_of :age

  # validate country_id
  validates_presence_of     :country_id
  validates_numericality_of :country_id

  NAME_SIZE       = 20
  NAME_MAX_LENGTH = 40

  AGE_SIZE        = 3
  AGE_MAX_LENGTH  = 3

end
