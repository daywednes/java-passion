# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'eb14e5c9bf38b906b71228ec2a404ede3899eb2bbf3ff90353c9ce6b5ba71348992ca9223eb14f809aef2a03426c76640d315ecd4d7d312c145408d61a8650b7';
