# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_college_session',
  :secret      => '1397fa4f2fb4e2de72d22946fa6d38ea0cbd6c677cd85005cfac5fa6889d9806f19f4178111332936eb182439b9db6b2acf71635a2de17530ad2a54b2d610e4a'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
