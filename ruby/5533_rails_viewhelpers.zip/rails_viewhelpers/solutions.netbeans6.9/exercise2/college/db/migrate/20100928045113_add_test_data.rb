class AddTestData < ActiveRecord::Migration

  COUNTRIES = %w(Argentina Brazil Chile Uruguay Mexico Usa
               Spain Denmark France Italy Poland Sweden
               Israel Lebanon Turkey Russia
               India China Taiwan Korea Japan
               South\ Africa Australia)

  STUDENTS_PER_COUNTRY =
    {
    :Argentina => { 'Victoria' => 27, 'Martin'    => 28              },
    :Denmark   => { 'Erik'     => 24, 'Inge'      => 21              },
    :India     => { 'Kala'     => 31, 'Sanjeev'   => 49              },
    :Israel    => { 'Levy'     => 32, 'Murad'     => 44              },
    :Italy     => { 'Pietro'   => 37                                 },
    :France    => { 'Lea'      => 25                                 },
    :Lebanon   => { 'Hakim'    => 39                                 },
    :Poland    => { 'Pawell'   => 25                                 },
    :Russia    => { 'Anna'     => 26, 'Andre'   => 21, 'Yakov' => 38 },
    :Sweden    => { 'Ingrid'   => 33, 'Lennart' => 42                },
    :Taiwan    => { 'Audrey'   => 15 },  # Audrey Tang, started Perl at 12!
    :Usa       => { 'Gabriel'  => 31, 'Barbara' => 42, 'Rick'  => 55 },
  }

  # a bit more weight to *nix systems (in dynamic languages)
  PLATFORMS = [ "Mac", "Linux", "Windows", "Mac"  ]

  def self.up
    Country.delete_all
    Student.delete_all

    COUNTRIES.each do |country|
      Country.create!(:name => country)
    end

    STUDENTS_PER_COUNTRY.each do |country_name, students|
      country = Country.find_by_name(country_name.to_s)
      students.each_pair do |name, age|
        Student.create!(:country_id => country.id, :name => name.to_s,
          :age => age,
          :platform => PLATFORMS[rand PLATFORMS.size])
      end
    end # students_per_country

  end # up

  def self.down
    Country.delete_all
    Student.delete_all
  end # down

end
