# To change this template, choose Tools | Templates
# and open the template in the editor.

require 'rest_client'

# Modify the port number to the port number your scaffold_rest application is running.
html_result = RestClient.get 'http://localhost:8081/users', :accept => 'text/html'
puts html_result
