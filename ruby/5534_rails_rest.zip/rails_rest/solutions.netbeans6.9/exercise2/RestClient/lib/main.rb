require 'rest_client'

# Modify the port number to the port number your scaffold_rest application is running.
html_result = RestClient.get 'http://localhost:3000/users', :accept => 'text/html'
puts html_result

# Modify the port number to the port number your scaffold_rest application is running.
html_result = RestClient.get 'http://localhost:3000/users/1', :accept => 'text/html'
puts html_result

# Modify the port number to the port number your scaffold_rest application is running.
#html_result = RestClient.get 'http://localhost:3000/users/new', :accept => 'text/html'
#puts html_result

# Modify the port number to the port number your scaffold_rest application is running.
#html_result = RestClient.post 'http://localhost:3000/users', :user => {:name => 'Sang Shin', :age => '100'}
#puts html_result

# Modify the port number to the port number your scaffold_rest application is running.
#html_result = RestClient.put 'http://localhost:3000/users/3', :user => {:name => 'Sang Chul Shin', :age => '77'}
#puts html_result

# Modify the port number to the port number your scaffold_rest application is running.
html_result = RestClient.delete 'http://localhost:3000/users/3'
puts html_result