require 'test_helper'

class PostTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  #def test_truth
  #  assert true
  #end

  # Create test
  def test_should_create_post
    post = Post.new(:title=>"test title", :body=>"test body")
    assert post.save
  end

  # Find test
  def test_should_find_post
    # Get the id of the test data named as one
    post_id = posts(:one).id
    assert_nothing_raised {Post.find(post_id)}
  end

  # Update test
  def test_should_update_post
    post = posts(:two)
    assert post.update_attributes(:title => 'new title')
  end

  # Destroy test
  def test_should_destroy_post
    post = posts(:three)
    post.destroy
    assert_raise(ActiveRecord::RecordNotFound) {
      Post.find(post.id)
    }
  end

  # Validation test
  def test_should_not_create_invalid_post
    post = Post.new()
    assert !post.valid?
    assert_equal "can't be blank", post.errors.on(:title)
    assert !post.save
  end

  # Association test
  def test_should_find_two_comments
    post = posts(:one)
    assert_equal post.comments.find(:all).size, 2
    assert_equal post.comment_ids, [31, 32]
    assert_equal post.comments.find(:first).id, 31
  end
end
