require 'test_helper'

class CreateNewPostAndCommentTest < ActionController::IntegrationTest
  fixtures :all

  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
  
  def test_should_create_1_post_and_2_comments
    post '/posts/create', :post => {:title=>"Rails", :body=>"I love Rails"}
    assert assigns(:post).valid?
    assert_redirected_to post_path(assigns(:post))

    post '/posts/post_comment', :comment => {:post_id=>(:post).id, :comment=>"my comment"}
    assert assigns(:comment).valid?
    assert_redirected_to :action => 'show'

    post '/posts/post_comment', :comment => {:post_id=>(:post).id, :comment=>"my comment 2"}
    assert assigns(:comment).valid?
    assert_redirected_to :action => 'show'
  end
end
