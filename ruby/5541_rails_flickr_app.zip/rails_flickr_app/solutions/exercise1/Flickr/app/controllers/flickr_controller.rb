class FlickrController < ApplicationController
  def index
  end

  def search
    flickr = Flickr.new

    if params[:tags].empty?
      render :text => '<h2>Please enter a search string</h2>'
    else
      begin
        photos = flickr.photos(:tags => params[:tags], :per_page => '24')
        render :partial => 'photo', :collection => photos
      rescue NoMethodError
        render :text => '<h2>No matching photos found</h2>'
      end
    end
  end

end
