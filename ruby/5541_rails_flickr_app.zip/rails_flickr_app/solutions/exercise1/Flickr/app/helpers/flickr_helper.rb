module FlickrHelper
end
