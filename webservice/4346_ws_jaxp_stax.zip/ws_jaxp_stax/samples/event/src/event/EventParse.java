/*
 * Copyright 2007 Sun Microsystems, Inc.
 * All rights reserved.  You may not modify, use,
 * reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * http://developer.sun.com/berkeley_license.html
 */
package event;

import java.io.FileInputStream;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

/**
 * EventParse sample is used to demonstrate the use
 * of Event APIs.
 *
 * @author <a href="neeraj.bajaj@sun.com">Neeraj Bajaj</a> Sun Microsystems,inc.
 */
public class EventParse {

    private static void printUsage() {
        System.out.println("usage: java -classpath EventParse <xmlfile>");
    }

    public static void main(String[] args) throws Exception {
        String filename = null;

        try {
            filename = args[0];
        } catch (ArrayIndexOutOfBoundsException aioobe) {
            printUsage();
            System.exit(0);
        }

        //Get the factory instance first.
        XMLInputFactory factory = XMLInputFactory.newInstance();
        System.out.println("FACTORY: " + factory);

        //create the XMLEventReader, pass the filename for any relative resolution 
        XMLEventReader r = factory.createXMLEventReader(
                filename,
                new FileInputStream(filename));

        // Programmer asks for events when s/he wants it (as opposed to
        // given by parser as in the case of SAX)
        while (r.hasNext()) {
            XMLEvent e = r.nextEvent();
            System.out.println("Event -> " + e.toString());
        }
    }
}
