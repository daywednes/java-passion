/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage3;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.LogicalMessage;
import javax.xml.ws.handler.LogicalHandler;
import javax.xml.ws.handler.LogicalMessageContext;
import javax.xml.ws.handler.MessageContext;

/**
 *
 * @author michgan
 */
public class MyLogicalHandler implements LogicalHandler<LogicalMessageContext> {

  private String handlerName = "MyLogicalHandler";

  @PostConstruct
  public void myInit() {
    System.out.println("----in " + handlerName + ":myInit");
    System.out.println("----exiting " + handlerName + ":myInit");
  }

  @PreDestroy
  public void myDestroy() {
    System.out.println("----in " + handlerName + ":myDestroy");
    System.out.println("----exiting " + handlerName + ":myDestroy");
  }

  public boolean handleMessage(LogicalMessageContext messageContext) {
    // LogicalMessage msg = messageContext.getMessage();
    boolean direction = ((Boolean) messageContext.get(
        LogicalMessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue();
    if (direction) {
      System.out.println("----direction = outbound");
    } else {
      System.out.println("----direction = inbound");
    }

    dumpMsg(messageContext);

    System.out.println("----exiting " + handlerName + ":handleMessage");
    return true;
  }

  public boolean handleFault(LogicalMessageContext messageContext) {
    return true;
  }

  public void close(MessageContext context) {
  }

  public void dumpMsg(MessageContext context) {
    System.out.println("----in " + handlerName + ":dumpMsg");

    try {
      LogicalMessage lm = ((LogicalMessageContext) context).getMessage();
      if (lm != null) {
        Source source = lm.getPayload();
        if (source != null) {
          System.out.println("----MSG=" + getSourceAsString(source));
        } else {
          System.out.println("----No message payload was present");
        }
      } else {
        System.out.println("----No message was present");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    System.out.println("----exiting " + handlerName + ":dumpMsg");


    return;
  }

  public String getSourceAsString(Source s) throws Exception {
    System.out.println("----in " + handlerName + ":getSourceAsString");

    Transformer transformer = TransformerFactory.newInstance().newTransformer();
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
    OutputStream out = new ByteArrayOutputStream();
    StreamResult streamResult = new StreamResult();
    streamResult.setOutputStream(out);
    transformer.transform(s, streamResult);

    System.out.println("----exiting " + handlerName + ":getSourceAsString");
    return streamResult.getOutputStream().toString();
  }
}
