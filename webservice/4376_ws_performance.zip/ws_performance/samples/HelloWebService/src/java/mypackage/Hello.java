/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage;

import javax.jws.WebService;

/**
 *
 * @author sang
 */
@WebService()
public class Hello {
    // Business method we want to expose as
    // Web service operation
    public String sayHello(String name) {
        return "Hello " + name + "!";
    }
}
