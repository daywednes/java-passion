/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hellowebserviceclient;

import javax.xml.ws.BindingProvider;

/**
 *
 * @author sang
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        try { // Call Web Service Operation
            mypackage.HelloService service = new mypackage.HelloService();
            mypackage.Hello port = service.getHelloPort();

            // Change the destination port to 4040
            BindingProvider bp = (BindingProvider) port;
            String address = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
            address = address.replaceFirst("8080", "4040");
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, address);
            //
            // TODO initialize WS operation arguments here
            java.lang.String arg0 = "Sang Shin";
            // TODO process result here
            java.lang.String result = port.sayHello(arg0);
            System.out.println("Result = " + result);
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }

    }
}
